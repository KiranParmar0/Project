import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import 'chartjs-plugin-datalabels';

function DoughnutChart() {
    const data = {
        labels: ['Mon', 'Tue', 'Wed', 'Thurs', 'Fri'],
        datasets: [
            {
                label: 'Attendance for Week 1',
                data: [25, 24, 25, 25, 23],
                borderColor: ['rgba(255,206,86,0.2)'],
                backgroundColor: [
                    'rgba(232,99,132,1)',
                    'rgba(232,211,6,1)',
                    'rgba(54,162,235,1)',
                    'rgba(255,159,64,1)',
                    'rgba(153,102,255,1)'
                ],
                pointBackgroundColor: 'rgba(255,206,86,0.2)',
                backgroundImage: 'lightblue url("https://www.chartjs.org/img/chartjs-logo.svgf") no-repeat fixed center'
            }

        ]
    }

    const urls = [
        'https://www.google.com',
        'https://www.microsoft.com',
        'https://www.apple.com',
        'https://www.amazon.com',
        'https://www.facebook.com'
    ];

    const options = {
        plugins: {
            title: {
                display: true,
                text: 'Doughnut Chart',
                color: 'blue',
                font: {
                    size: 34
                },
                padding: {
                    top: 30,
                    bottom: 30
                }
            },
            datalabels: {
                color: 'red', // Color of the labels
                display: true,
                formatter: (value, context) => { // Custom formatter function
                    return value + '%'; // You can customize the formatting as needed
                }
            }
        },
        onClick: (event, elements) => {
            if (elements.length > 0) {
                const index = elements[0].index;
                if (index >= 0 && index < urls.length) {
                    // Open the corresponding URL in a new tab
                    window.open(urls[index], '_blank');
                }
            }
        }
    }

    return (
        <div>
            <Doughnut data={data} options={options} />
        </div>
    )
}

export default DoughnutChart;
