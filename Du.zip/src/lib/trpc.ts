/**
 * This file re-exports the tRPC client from trpc-provider
 * Use this import for convenience: import { trpc } from '@/lib/trpc'
 */
export { trpc } from './trpc-provider';
