import { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import { DrizzleAdapter } from '@auth/drizzle-adapter'
import { db } from './drizzle'
import { user_master } from '@/db/schema'
import { eq } from 'drizzle-orm'
import bcrypt from 'bcryptjs'
import { collegeLoginConfig } from '@/config/auth/collegeAuthConfig'

// Export a factory that returns NextAuth options. The Drizzle adapter is
// created lazily only when `DATABASE_URL` exists so that the module can be
// imported during build without requiring a DB connection.
export function createAuthOptions(): NextAuthOptions {
  const adapter = process.env.DATABASE_URL ? (DrizzleAdapter(db) as any) : undefined

  return {
    adapter,
    providers: [
      CredentialsProvider({
        name: 'Credentials',
        credentials: {
          email: { label: 'Email', type: 'email' },
          password: { label: 'Password', type: 'password' }
        },
        async authorize(credentials) {
          if (!credentials?.email || !credentials?.password) {
            throw new Error('Email/identifier and password required')
          }

          // Test-only college credentials support: allow college test login to create a session
          const { testCredentials } = collegeLoginConfig;
          if (
            testCredentials?.email &&
            credentials.email.toString().toLowerCase() === testCredentials.email.toLowerCase() &&
            credentials.password === testCredentials.password
          ) {
            return {
              id: 'college-test-user',
              email: credentials.email.toString(),
              name: 'College Test User',
              role: 'college'
            }
          }

          const [user] = await db.select()
            .from(user_master)
            .where(eq(user_master.UserEmailID, credentials.email))
            .limit(1)

          if (!user || !user.UserPassword) {
            throw new Error('Invalid credentials')
          }

          if (!user.IsActive) {
            throw new Error('Email not verified. Please verify your email before logging in.')
          }

          const isValid = await bcrypt.compare(credentials.password, user.UserPassword)

          if (!isValid) {
            throw new Error('Invalid credentials')
          }

          // Update last login
          await db.update(user_master)
            .set({
              LastLoginDateTime: new Date()
            })
            .where(eq(user_master.UserID, user.UserID))

          return {
            id: user.UserID.toString(),
            email: user.UserEmailID || '',
            name: user.UserName || '',
            role: user.UserTypeID?.toString() || null
          }
        }
      })
    ],
    callbacks: {
      async jwt({ token, user }) {
        if (user) {
          token.role = (user as any).role
          token.id = user.id
        }
        return token
      },
      async session({ session, token }) {
        if (session.user) {
          (session.user as any).role = token.role as string
          (session.user as any).id = token.id as string
        }
        return session
      }
    },
    pages: {
      signIn: '/auth/signin',
      error: '/auth/error'
    },
    session: {
      strategy: 'jwt'
    },
    secret: process.env.NEXTAUTH_SECRET
  }
}
