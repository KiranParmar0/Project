import { signIn } from "next-auth/react";

export async function collegeSignIn(identifier: string, password: string) {
  const res = await fetch(`/api/auth/college-login`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ identifier, password }),
  });

  const data = await res.json();

  if (data?.success) {
    // Try to create a NextAuth session via credentials provider so session.role is set
    try {
      await signIn("credentials", { email: identifier, password, redirect: false });
    } catch (err) {
      // ignore signIn errors; API already returned success for test flow
    }
  }

  return data;
}
