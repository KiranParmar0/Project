import { BlobServiceClient } from "@azure/storage-blob";

const connectionString = process.env.AZURE_STORAGE_CONNECTION_STRING;

if (!connectionString) {
  throw new Error("AZURE_STORAGE_CONNECTION_STRING environment variable is not set");
}

export const blobServiceClient = BlobServiceClient.fromConnectionString(connectionString);

export async function uploadFileToAzure(
  file: Buffer,
  fileName: string,
  containerName: string
): Promise<string> {
  try {
    const containerClient = blobServiceClient.getContainerClient(containerName);

    // Create container if it doesn't exist
    try {
      await containerClient.create({ access: "blob" });
    } catch (error: any) {
      // Container already exists, that's fine
      if (error.code !== "ContainerAlreadyExists") {
        throw error;
      }
    }

    // Generate unique blob name with timestamp
    const timestamp = Date.now();
    const blobName = `${timestamp}-${fileName}`;
    const blockBlobClient = containerClient.getBlockBlobClient(blobName);

    // Upload file
    await blockBlobClient.upload(file, file.length);

    // Return the URL
    return blockBlobClient.url;
  } catch (error) {
    console.error("Azure Storage upload error:", error);
    throw new Error(`Failed to upload file to Azure Storage: ${error}`);
  }
}

export async function deleteFileFromAzure(
  blobUrl: string,
  containerName: string
): Promise<void> {
  try {
    const containerClient = blobServiceClient.getContainerClient(containerName);

    // Extract blob name from URL
    const blobName = blobUrl.split("/").pop();
    if (!blobName) {
      throw new Error("Invalid blob URL");
    }

    const blockBlobClient = containerClient.getBlockBlobClient(blobName);
    await blockBlobClient.delete();
  } catch (error) {
    console.error("Azure Storage delete error:", error);
    throw new Error(`Failed to delete file from Azure Storage: ${error}`);
  }
}
