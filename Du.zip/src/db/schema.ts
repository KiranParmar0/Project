import { pgTable, bigserial, timestamp, varchar, integer, char, date, decimal, index, boolean, smallint, bit, bigint, numeric } from 'drizzle-orm/pg-core'

// ============ Registration Details ============
export const registration_details = pgTable('Registration_Details', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey(),
  CandidateName: varchar('CandidateName', { length: 150 }).notNull(),
  CandidateEmailID: varchar('CandidateEmailID', { length: 100 }).notNull(),
  CandidateMobileNo: varchar('CandidateMobileNo', { length: 50 }).notNull(),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate').defaultNow(),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 })
})

// ============ Personal Details ============
export const personal_details = pgTable('Personal_Details', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  FirstName: varchar('FirstName', { length: 50 }),
  MiddleName: varchar('MiddleName', { length: 50 }),
  LastName: varchar('LastName', { length: 50 }),
  FullName: varchar('FullName', { length: 150 }),
  CandidateNameInDevanagri: varchar('CandidateNameInDevanagri', { length: 150 }),
  FatherName: varchar('FatherName', { length: 100 }),
  FatherOccupation: varchar('FatherOccupation', { length: 50 }),
  MotherName: varchar('MotherName', { length: 100 }),
  MotherOccupation: varchar('MotherOccupation', { length: 50 }),
  Gender: char('Gender', { length: 1 }), // M, F, T
  DOB: date('DOB'),
  IsChangeName: char('IsChangeName', { length: 1 }), // Y/N
  ChangeNameReason: varchar('ChangeNameReason', { length: 255 }),
  ChristName: varchar('ChristName', { length: 50 }),
  CMiddleName: varchar('CMiddleName', { length: 50 }),
  CLastName: varchar('CLastName', { length: 50 }),
  CFullName: varchar('CFullName', { length: 150 }),
  AnnualIncome: varchar('AnnualIncome', { length: 20 }),
  MaritalStatus: char('MaritalStatus', { length: 1 }), // S/M
  BloodGroup: varchar('BloodGroup', { length: 20 }),
  MotherTongue: varchar('MotherTongue', { length: 20 }),
  AadharNo: varchar('AadharNo', { length: 50 }),
  IdentificationOfMarksOnBody: varchar('IdentificationOfMarksOnBody', { length: 50 }),
  PRNNo: varchar('PRNNo', { length: 50 }),
  ABCID: varchar('ABCID', { length: 50 }),
  EmailID: varchar('EmailID', { length: 100 }),
  MobileNo: varchar('MobileNo', { length: 10 }),
  WhatappMobileNo: varchar('WhatappMobileNo', { length: 10 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ Address Details ============
export const address_details = pgTable('Address_Details', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  Nationality: char('Nationality', { length: 1 }), // I/O
  Country: varchar('Country', { length: 10 }),
  StateID: integer('StateID').references(() => master_state.StateID),
  DistrictID: integer('DistrictID').references(() => master_district.DistrictID),
  TalukaID: varchar('TalukaID'),
  VillageCity: varchar('VillageCity', { length: 50 }),
  Address1: varchar('Address1', { length: 250 }),
  Address2: varchar('Address2', { length: 250 }),
  PinCode: varchar('PinCode', { length: 6 }),
  IsSameAsAddress: boolean('IsSameAsAddress'),
  PSCountry: varchar('PSCountry', { length: 10 }),
  PSStateID: integer('PSStateID').references(() => master_state.StateID),
  PSDistrictID: integer('PSDistrictID').references(() => master_district.DistrictID),
  PSTalukaID: varchar('PSTalukaID'),
  PSVillage: varchar('PSVillage', { length: 50 }),
  PAddress1: varchar('PAddress1', { length: 100 }),
  PAddress2: varchar('PAddress2', { length: 100 }),
  PPinCode: varchar('PPinCode', { length: 8 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ Reservation And Other Details ============
export const reservation_and_other_details = pgTable('Reservation_And_Other_Details', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  DomicileStateID: integer('DomicileStateID').references(() => master_state.StateID),
  DomicileType: char('DomicileType', { length: 1 }),
  CategoryID: smallint('CategoryID').references(() => master_category.CategoryID),
  FinalCategoryID: smallint('FinalCategoryID').references(() => master_category.CategoryID),
  ReligionID: smallint('ReligionID').references(() => master_religion.ReligionID),
  Caste: varchar('Caste', { length: 20 }),
  HasCasteCertificate: boolean('HasCasteCertificate'),
  HasNCLCertificate: boolean('HasNCLCertificate'),
  HasEWSCertificate: boolean('HasEWSCertificate'),
  HasCasteValidity: boolean('HasCasteValidity'),
  HasCasteValidityReceipt: boolean('HasCasteValidityReceipt'),
  IsOrphan: boolean('IsOrphan'),
  isPH: boolean('isPH'),
  PHDetails: varchar('PHDetails', { length: 50 }),
  IsExServiceman: boolean('IsExServiceman'),
  IsFreedomFighter: boolean('IsFreedomFighter'),
  IsProjectAffected: boolean('IsProjectAffected'),
  IsTransgender: boolean('IsTransgender'),
  SportDetails: varchar('SportDetails', { length: 50 }),
  IsNCC: boolean('IsNCC'),
  IsNSS: boolean('IsNSS'),
  IsAgriculture: boolean('IsAgriculture'),
  IsMinority: boolean('IsMinority'),
  ReligiousMinorityID: smallint('ReligiousMinorityID').references(() => master_minority.MinorityID),
  LinguisticMinorityID: smallint('LinguisticMinorityID').references(() => master_minority.MinorityID),
  OwnedByID: varchar('OwnedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ Qualification Details ============
export const qualification_details = pgTable('Qualification_Details', {
  CandidateID: bigint('CandidateID', { mode: 'bigint' }).references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  QualificationID: smallint('QualificationID').references(() => master_qualification.QualificationID),
  ProgramID: smallint('ProgramID'),
  StreamID: smallint('StreamID').references(() => master_stream.StreamID),
  FacultyID: smallint('FacultyID'),
  UniversityBoardID: smallint('UniversityBoardID'),
  SeatNo: varchar('SeatNo', { length: 20 }),
  CollegeName: varchar('CollegeName', { length: 100 }),
  CollegeStateID: integer('CollegeStateID'),
  CollegeDistrictID: integer('CollegeDistrictID').references(() => master_district.DistrictID),
  CollegeTalukaID: integer('CollegeTalukaID').references(() => master_taluka.TalukaID),
  CollegeCity: varchar('CollegeCity', { length: 50 }),
  CollegePinCode: varchar('CollegePinCode', { length: 6 }),
  PassingMonth: smallint('PassingMonth'),
  PassingYear: integer('PassingYear'),
  MarksType: char('MarksType', { length: 1 }),
  MarksObtained: integer('MarksObtained'),
  MarksOutOf: integer('MarksOutOf'),
  CGPA: numeric('CGPA', { precision: 5, scale: 2 }),
  CGPAOutOf: numeric('CGPAOutOf', { precision: 5, scale: 2 }),
  MarkPercentage: numeric('MarkPercentage', { precision: 6, scale: 2 }),
  PassingClassID: smallint('PassingClassID'),
  NoOfAttempts: smallint('NoOfAttempts'),
  IsGapInEducation: boolean('IsGapInEducation'),
  EducationGapYear: integer('EducationGapYear'),
  GapReason: varchar('GapReason', { length: 50 }),
  ResultStatus: varchar('ResultStatus', { length: 20 }),
  Grade: varchar('Grade', { length: 10 }),
  PRNNo: varchar('PRNNo', { length: 50 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ Work Experience ============
export const work_experience = pgTable('Work_Experience', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  CompanyName: varchar('CompanyName', { length: 100 }),
  TypeOfCompany: smallint('TypeOfCompany'),
  Designation: varchar('Designation', { length: 100 }),
  FromDate: date('FromDate'),
  ToDate: date('ToDate'),
  TotalExperience: decimal('TotalExperience', { precision: 5, scale: 2 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ PhotoSign ============
export const photo_sign = pgTable('Photo_Sign', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  PhotoURL: varchar('PhotoURL', { length: 100 }),
  SignURL: varchar('SignURL', { length: 100 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ Required Document ============
export const required_document = pgTable('Required_Document', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  DocumentID: integer('DocumentID').references(() => master_document.DocumentID),
  IsDocumentUpload: boolean('IsDocumentUpload'),
  DocumentUploadURL: varchar('DocumentUploadURL', { length: 100 }),
  UploadedByID: varchar('UploadedByID', { length: 100 }),
  UploadedOnDate: timestamp('UploadedOnDate'),
  UploadedIPAddress: varchar('UploadedIPAddress', { length: 100 }),
  IsVerified: boolean('IsVerified'),
  EVerificationStatus: char('EVerificationStatus', { length: 1 }),
  EVerificationComments: varchar('EVerificationComments', { length: 100 }),
  EVerifiedByID: varchar('EVerifiedByID', { length: 100 }),
  EVerifiedOnDate: timestamp('EVerifiedOnDate'),
  EVerifiedIPAddress: varchar('EVerifiedIPAddress', { length: 100 })
}, (table) => {
  return {
    pk: { columns: [table.CandidateID, table.DocumentID] }, // Composite key seems appropriate if one doc per type per candidate, but original had CandidateID as PK which works for 1-1 mapping if CandidateID is serial? 
    // Wait, original: CandidateID: bigserial... primaryKey(). 
    // If it's 1-to-many (one candidate, many documents), CandidateID cannot be PK alone.
    // The previous schema had CandidateID as PK which implies one row per candidate? 
    // But table name is Required_Document (singular). The screenshot shows `RequiredDocument` table with `CandidateID` and `DocumentID`. 
    // If CandidateID is FK, and DocumentID is just an int (dropdown), then a candidate can have multiple documents.
    // So PK should be composite (CandidateID, DocumentID) or a separate ID. 
    // The previous schema was:
    // CandidateID: bigserial... primaryKey()...
    // DocumentID: integer...
    // This implies only ONE document per candidate?? That seems wrong for "Document Details" page with multiple docs.
    // I will change it to ensure it supports multiple documents.
    // Screenshot: "CandidateID bigint", "DocumentID int".
    // I will use composite PK or just no PK if not strict, but composite (CandidateID, DocumentID) is best.
  }
})

// ============ Profile Status ============
export const profile_status = pgTable('Profile_Status', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  FormStatus: char('FormStatus', { length: 1 }),
  ProfileStatus: char('ProfileStatus', { length: 1 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============ Candidate Bank Details ============
export const candidate_bank_details = pgTable('Candidate_Bank_Details', {
  CandidateID: bigserial('CandidateID', { mode: 'bigint' }).primaryKey().references(() => registration_details.CandidateID, { onDelete: 'cascade' }),
  AccountNo: varchar('AccountNo', { length: 25 }),
  IFSCCode: varchar('IFSCCode', { length: 50 }),
  BankName: varchar('BankName', { length: 100 }),
  BranchName: varchar('BranchName', { length: 100 }),
  HolderName: varchar('HolderName', { length: 100 }),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 }),
  ModifiedByID: varchar('ModifiedByID', { length: 100 }),
  ModifiedOnDate: timestamp('ModifiedOnDate'),
  ModifiedIPAddress: varchar('ModifiedIPAddress', { length: 100 })
})

// ============================================
// MASTER TABLES (Pre-existing in database)
// ============================================

// ============ Master_Category ============
export const master_category = pgTable('Master_Category', {
  CategoryID: integer('CategoryID').primaryKey(),
  CategoryName: varchar('CategoryName', { length: 50 }),
  CategoryShortName: varchar('CategoryShortName', { length: 50 }),
  IsActive: boolean('IsActive')
})

// ============ Master_State ============
export const master_state = pgTable('Master_State', {
  StateID: integer('StateID').primaryKey(),
  StateName: varchar('StateName', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_District ============
export const master_district = pgTable('Master_District', {
  DistrictID: integer('DistrictID').primaryKey(),
  DistrictName: varchar('DistrictName', { length: 100 }),
  StateID: integer('StateID').references(() => master_state.StateID),
  IsActive: boolean('IsActive')
})

// ============ Master_Taluka ============
export const master_taluka = pgTable('Master_Taluka', {
  TalukaID: integer('TalukaID').primaryKey(),
  TalukaName: varchar('TalukaName', { length: 100 }),
  DistrictID: integer('DistrictID').references(() => master_district.DistrictID),
  IsActive: boolean('IsActive')
})

// ============ Master_Course ============
export const master_course = pgTable('Master_Course', {
  CourseID: integer('CourseID').primaryKey(),
  CourseName: varchar('CourseName', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Religion ============
export const master_religion = pgTable('Master_Religion', {
  ReligionID: integer('ReligionID').primaryKey(),
  ReligionName: varchar('ReligionName', { length: 50 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Minority ============
export const master_minority = pgTable('Master_Minority', {
  MinorityID: integer('MinorityID').primaryKey(),
  MinorityCategory: varchar('MinorityCategory', { length: 50 }),
  Minority: varchar('Minority', { length: 50 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Qualification ============
export const master_qualification = pgTable('Master_Qualification', {
  QualificationID: integer('QualificationID').primaryKey(),
  Qualification: varchar('Qualification', { length: 100 }),
  IsUniversityBoard: char('IsUniversityBoard'),
  IsActive: boolean('IsActive'),
  SeqNo: smallint('SeqNo')
})

// ============ Master_Branch ============
export const master_branch = pgTable('Master_Branch', {
  BranchID: integer('BranchID').primaryKey(),
  Branch: varchar('Branch', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_DegreeLevel ============
export const master_degree_level = pgTable('Master_DegreeLevel', {
  DegreeLevalID: integer('DegreeLevalID').primaryKey(),
  DegreeLevalName: varchar('DegreeLevalName', { length: 100 }),
  DegreeLevelType: varchar('DegreeLevelType', { length: 1 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Program ============
export const master_program = pgTable('Master_Program', {
  ProgramID: integer('ProgramID').primaryKey(),
  ProgramName: varchar('ProgramName', { length: 100 }),
  ProgramShotName: varchar('ProgramShotName', { length: 50 }),
  BranchID: integer('BranchID').references(() => master_branch.BranchID),
  DurationInYear: smallint('DurationInYear'),
  DegreeLevalID: smallint('DegreeLevalID').references(() => master_degree_level.DegreeLevalID),
  QualificationID: smallint('QualificationID').references(() => master_qualification.QualificationID),
  IsActive: boolean('IsActive')
})

// ============ Master_University ============
export const master_university = pgTable('Master_University', {
  UniversityID: integer('UniversityID').primaryKey(),
  UniversityName: varchar('UniversityName', { length: 150 }),
  UniversityCity: varchar('UniversityCity', { length: 50 }),
  UniversityStateID: integer('UniversityStateID').references(() => master_state.StateID),
  UniversityCode: varchar('UniversityCode', { length: 50 }),
  DistrictID: integer('DistrictID').references(() => master_district.DistrictID),
  IsActive: boolean('IsActive')
})

// ============ Master_Board ============
export const master_board = pgTable('Master_Board', {
  BoardID: integer('BoardID').primaryKey(),
  Board: varchar('Board', { length: 150 }),
  BoardNickName: varchar('BoardNickName', { length: 150 }),
  StateID: integer('StateID').references(() => master_state.StateID),
  IsActive: boolean('IsActive')
})

// ============ Master_Stream ============
export const master_stream = pgTable('Master_Stream', {
  StreamID: integer('StreamID').primaryKey(),
  Stream: varchar('Stream', { length: 50 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Faculty ============
export const master_faculty = pgTable('Master_Faculty', {
  FacultyID: integer('FacultyID').primaryKey(),
  FacultyName: varchar('FacultyName', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_ApplicationStep ============
export const master_application_step = pgTable('Master_ApplicationStep', {
  ApplicationStepID: integer('ApplicationStepID').primaryKey(),
  Step: varchar('Step', { length: 100 }),
  ApplicationPageURL: varchar('ApplicationPageURL', { length: 200 })
})

// ============ Master_Department ============
export const master_department = pgTable('Master_Department', {
  DepartmentID: integer('DepartmentID').primaryKey(),
  DepartmentName: varchar('DepartmentName', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Document ============
export const master_document = pgTable('Master_Document', {
  DocumentID: integer('DocumentID').primaryKey(),
  Document: varchar('Document', { length: 500 }),
  SeqNo: smallint('SeqNo'),
  IsCompulsory: boolean('IsCompulsory'),
  IsActive: boolean('IsActive')
})

// ============ Master_SecurityQuestion ============
export const master_security_question = pgTable('Master_SecurityQuestion', {
  SecurityQuestionID: integer('SecurityQuestionID').primaryKey(),
  SecurityQuestion: varchar('SecurityQuestion', { length: 200 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Locality ============
export const master_locality = pgTable('Master_Locality', {
  LocalityID: integer('LocalityID').primaryKey(),
  LocalityName: varchar('LocalityName', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_CollegeType ============
export const master_college_type = pgTable('Master_CollegeType', {
  CollegeTypeID: integer('CollegeTypeID').primaryKey(),
  CollegeType: varchar('CollegeType', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_CollegeCategory ============
export const master_college_category = pgTable('Master_CollegeCategory', {
  CollegeCategoryID: integer('CollegeCategoryID').primaryKey(),
  CollegeCategory: varchar('CollegeCategory', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_CollegeStatus ============
export const master_college_status = pgTable('Master_CollegeStatus', {
  CollegeStatusID: integer('CollegeStatusID').primaryKey(),
  CollegeStatus: varchar('CollegeStatus', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_AutonomousStatus ============
export const master_autonomous_status = pgTable('Master_AutonomousStatus', {
  AutonomousStatusID: integer('AutonomousStatusID').primaryKey(),
  AutonomousStatus: varchar('AutonomousStatus', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_MinorityStatus ============
export const master_minority_status = pgTable('Master_MinorityStatus', {
  MinorityStatusID: integer('MinorityStatusID').primaryKey(),
  MinorityStatus: varchar('MinorityStatus', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_AffiliationType ============
export const master_affiliation_type = pgTable('Master_AffiliationType', {
  AffiliationTypeID: integer('AffiliationTypeID').primaryKey(),
  AffiliationType: varchar('AffiliationType', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_Designation ============
export const master_designation = pgTable('Master_Designation', {
  DesignationID: integer('DesignationID').primaryKey(),
  Designation: varchar('Designation', { length: 100 }),
  DesignationType: varchar('DesignationType', { length: 50 }),
  SeatNo: smallint('SeatNo'),
  IsActive: boolean('IsActive')
})

// ============ Master_HostelType ============
export const master_hostel_type = pgTable('Master_HostelType', {
  HostelTypeID: integer('HostelTypeID').primaryKey(),
  HostelType: varchar('HostelType', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ Master_HostelLocation ============
export const master_hostel_location = pgTable('Master_HostelLocation', {
  HostelLocationID: integer('HostelLocationID').primaryKey(),
  HostelLocation: varchar('HostelLocation', { length: 100 }),
  IsActive: boolean('IsActive')
})

// ============ User Type Master ============
export const master_user_type = pgTable('Master_UserType', {
  UserTypeID: integer('UserTypeID').primaryKey(),
  UserType: varchar('UserType', { length: 50 }),
  UserTypeCode: varchar('UserTypeCode', { length: 100 }),
  UserInitial: varchar('UserInitial', { length: 10 }),
  DashboardURL: varchar('DashboardURL', { length: 100 }),
  IsAdmin: boolean('IsAdmin').notNull(),
  IsActive: boolean('IsActive').notNull()
})

// ============ User Master ============
export const user_master = pgTable('User_Master', {
  UserID: bigserial('UserID', { mode: 'bigint' }).primaryKey(),
  UserTypeID: integer('UserTypeID').references(() => master_user_type.UserTypeID),
  UserLoginID: varchar('UserLoginID', { length: 100 }),
  UserPassword: varchar('UserPassword', { length: 100 }),
  UserName: varchar('UserName', { length: 150 }),
  UserMobileNo: varchar('UserMobileNo', { length: 50 }),
  UserEmailID: varchar('UserEmailID', { length: 100 }),
  SecurityQuestionID: smallint('SecurityQuestionID').references(() => master_security_question.SecurityQuestionID),
  SecurityQuestionAnswer: varchar('SecurityQuestionAnswer', { length: 100 }),
  LastLoginDateTime: timestamp('LastLoginDateTime'),
  LastLoginIPAddress: varchar('LastLoginIPAddress', { length: 100 }),
  IsActive: boolean('IsActive'),
  CreatedByID: varchar('CreatedByID', { length: 100 }),
  CreatedOnDate: timestamp('CreatedOnDate'),
  CreatedIPAddress: varchar('CreatedIPAddress', { length: 100 })
})

// ============ Verification Tokens ============
export const verification_tokens = pgTable('Verification_Tokens', {
  TokenID: bigserial('TokenID', { mode: 'bigint' }).primaryKey(),
  Email: varchar('Email', { length: 100 }).notNull(),
  Token: varchar('Token', { length: 200 }).notNull(),
  TokenType: varchar('TokenType', { length: 50 }).notNull(), // EMAIL_VERIFICATION, PASSWORD_RESET, etc.
  ExpiresAt: timestamp('ExpiresAt').notNull(),
  IsUsed: boolean('IsUsed').default(false),
  CreatedAt: timestamp('CreatedAt').defaultNow()
})
