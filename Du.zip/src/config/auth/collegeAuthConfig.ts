export const collegeLoginConfig = {
  labels: {
    title: "Vasantrao Naik Marathwada Krishi Vidyapeeth - College Portal",
    collegeLoginLabel: "College Login",
    emailLabel: "College Code",
    emailPlaceholder: "College Code (e.g., COL1234)",
    passwordLabel: "Password",
    passwordPlaceholder: "Password",
    captchaLabel: "Enter Captcha",
    loginButtonLabel: "College Log In",
    forgotPasswordHref: "/auth/forgot/options",
    signupHref: "/auth/college-register",
  },
  // TEST-ONLY credentials for College login. REMOVE or change before production.
  // Use these credentials to test the isolated college login flow.
  testCredentials: {
    email: "test1234",
    password: "Test1234",
  },
};
