import { StepConfig } from "@/components/profile/ProfileWizard";
import BasicDetails from "@/components/forms/college/BasicDetails";
import AddressDetails from "@/components/forms/college/AddressDetails";
import ContactDetails from "@/components/forms/college/ContactDetails";
import HostelDetails from "@/components/forms/college/HostelDetails";
import ProgramDetails from "@/components/forms/college/ProgramDetails";
import Declaration from "@/components/forms/college/Declaration";

export const COLLEGE_STEPS: StepConfig[] = [
  { id: "basic", label: "Basic Details", component: BasicDetails },
  { id: "address", label: "Address Details", component: AddressDetails },
  { id: "contact", label: "Contact Details", component: ContactDetails },
  { id: "hostel", label: "Hostel Details", component: HostelDetails },
  { id: "program", label: "Program Details", component: ProgramDetails },
  { id: "declaration", label: "Declaration", component: Declaration },
];
