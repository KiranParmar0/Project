import { z } from "zod";
import { FormSection } from "@/components/ui/DynamicForm";

// Shared address options
const countryOptions = [
  { value: "UK", label: "UK" },
  { value: "UAE", label: "UAE" },
  { value: "USA", label: "USA" },
  { value: "IN", label: "India" },
];

const stateOptions = [
  { value: "1", label: "Maharashtra" },
  { value: "2", label: "Karnataka" },
];

const districtOptions = [
  { value: "1", label: "Mumbai" },
  { value: "2", label: "Pune" },
];

// Verhoeff checksum validation for Aadhaar
function verhoeffValidate(num: string) {
  const d = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 2, 3, 4, 0, 6, 7, 8, 9, 5],
    [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
    [3, 4, 0, 1, 2, 8, 9, 5, 6, 7],
    [4, 0, 1, 2, 3, 9, 5, 6, 7, 8],
    [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
    [6, 5, 9, 8, 7, 1, 0, 4, 3, 2],
    [7, 6, 5, 9, 8, 2, 1, 0, 4, 3],
    [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
    [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
  ];
  const p = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
    [1, 5, 7, 6, 2, 8, 3, 0, 9, 4],
    [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
    [8, 9, 1, 6, 0, 4, 3, 5, 2, 7],
    [9, 4, 5, 3, 1, 2, 6, 8, 7, 0],
    [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
    [2, 7, 9, 3, 8, 0, 6, 4, 1, 5],
    [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
  ];
  let c = 0;
  const digits = num
    .split("")
    .reverse()
    .map((ch) => parseInt(ch, 10));
  for (let i = 0; i < digits.length; i++) {
    c = d[c][p[i % 8][digits[i]]];
  }
  return c === 0;
}

export const personalDetailsConfig: FormSection[] = [
  {
    title: "Basic Personal Details:",
    fields: [
      {
        name: "firstName",
        label: "First Name",
        type: "text",
        placeholder: "First Name",
        required: true,
        validation: z
          .string()
          .min(2, "First name must be at least 2 characters")
          .max(50, "First name must not exceed 50 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "First name can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "middleName",
        label: "Middle Name",
        type: "text",
        placeholder: "Middle Name",
        required: true,
        validation: z
          .string()
          .min(1, "Middle name is required")
          .max(50, "Middle name must not exceed 50 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Middle name can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "lastName",
        label: "Last Name",
        type: "text",
        placeholder: "Last Name",
        required: true,
        validation: z
          .string()
          .min(2, "Last name must be at least 2 characters")
          .max(50, "Last name must not exceed 50 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Last name can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "fullName",
        label: "The full name that will appear in future records",
        type: "text",
        placeholder: "Full Name as per Records",
        required: true,
        gridColumn: "1 / 3",
        validation: z
          .string()
          .min(5, "Full name must be at least 5 characters")
          .max(150, "Full name must not exceed 150 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Full name can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "gender",
        label: "Gender",
        type: "select",
        gridColumn: "1 / 2",
        placeholder: "Select Gender",
        required: true,
        options: [
          { value: "M", label: "Male" },
          { value: "F", label: "Female" },
          { value: "T", label: "Transgender" },
        ],
      },
      {
        name: "dob",
        label: "Date of Birth",
        type: "date",
        placeholder: "Select Date",
        required: true,
        validation: z.string().refine((date) => {
          const dob = new Date(date);
          const today = new Date();
          const age = today.getFullYear() - dob.getFullYear();
          return age >= 15 && age <= 100;
        }, "You must be at least 15 years old and not more than 100 years old"),
      },
      {
        name: "bloodGroup",
        label: "Blood Group",
        type: "select",
        placeholder: "Select Blood Group",
        required: true,
        options: [
          { value: "A+", label: "A+" },
          { value: "A-", label: "A-" },
          { value: "B+", label: "B+" },
          { value: "B-", label: "B-" },
          { value: "O+", label: "O+" },
          { value: "O-", label: "O-" },
          { value: "AB+", label: "AB+" },
          { value: "AB-", label: "AB-" },
        ],
      },
      {
        name: "fatherName",
        label: "Father's Name",
        type: "text",
        placeholder: "Father's Name",
        required: true,
        validation: z
          .string()
          .min(2, "Father's name must be at least 2 characters")
          .max(100, "Father's name must not exceed 100 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Father's name can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "fatherOccupation",
        label: "Father's Occupation",
        type: "text",
        placeholder: "Occupation",
        required: true,
        validation: z
          .string()
          .min(2, "Occupation must be at least 2 characters")
          .max(100, "Occupation must not exceed 100 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Father's occupation can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "motherName",
        label: "Mother's Name",
        type: "text",
        placeholder: "Mother's Name",
        required: true,
        validation: z
          .string()
          .min(2, "Mother's name must be at least 2 characters")
          .max(100, "Mother's name must not exceed 100 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Mother's name can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "motherOccupation",
        label: "Mother's Occupation",
        type: "text",
        placeholder: "Occupation",
        required: true,
        validation: z
          .string()
          .min(2, "Occupation must be at least 2 characters")
          .max(100, "Occupation must not exceed 100 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Mother's occupation can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "annualIncome",
        label: "Annual Income",
        type: "select",
        placeholder: "Select Annual Income",
        required: true,
        options: [
          { value: "10,000-50,000", label: "10,000-50,000" },
          { value: "50,000-2,50,000", label: "50,000-2,50,000" },
          { value: "2,50,000-5,00,000", label: "2,50,000-5,00,000" },
          { value: "5,00,000-8,00,000", label: "5,00,000-8,00,000" },
          { value: "8,00,000-15,00,000", label: "8,00,000-15,00,000" },
          { value: "More than 15,00,000", label: "More than 15,00,000" },
        ],
      },
      {
        name: "motherTongue",
        label: "Mother Tongue",
        type: "text",
        placeholder: "e.g., Hindi, English, Tamil",
        required: true,
        validation: z
          .string()
          .min(2, "Mother tongue must be at least 2 characters")
          .max(50, "Mother tongue must not exceed 50 characters")
          .regex(
            /^[A-Za-z\s]+$/,
            "Mother tongue can only contain letters and spaces"
          ),
        restrictInput: "alpha",
      },
      {
        name: "aadharNumber",
        label: "Aadhar Number",
        type: "text",
        placeholder: "0000-0000-0000",
        required: true,
        inputMode: "numeric",
        validation: z
          .string()
          .regex(
            /^[\d\s-]+$/,
            "Aadhaar may contain only digits, spaces or hyphens"
          )
          .refine((val) => {
            const cleaned = String(val || "").replace(/\D/g, "");
            // must be exactly 12 digits
            if (cleaned.length !== 12) return false;
            // Aadhaar should not start with 0 or 1
            if (/^[01]/.test(cleaned)) return false;
            // checksum validation
            return verhoeffValidate(cleaned);
          }, "Invalid Aadhaar number (must be 12 digits, not start with 0 or 1, and pass checksum)"),
        restrictInput: "numeric",
      },
      {
        name: "abcId",
        label: "ABCID Number",
        type: "text",
        placeholder: "",
        required: false,
      },
      {
        name: "emailAddress",
        label: "Email Address",
        type: "email",
        placeholder: "me@gmail.com",
        required: true,
        disabled: true,
        validation: z
          .string()
          .email("Please enter a valid email address")
          .min(5, "Email must be at least 5 characters")
          .max(100, "Email must not exceed 100 characters")
          .regex(
            /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
            "Please enter a valid email format"
          ),
      },
      {
        name: "mobileNumber",
        label: "Mobile Number",
        type: "tel",
        placeholder: "+91-0000000000",
        required: true,
        inputMode: "tel",
        validation: z
          .string()
          .regex(
            /^[6-9]\d{9}$/,
            "Mobile number must be exactly 10 digits, start with 6-9, and contain numbers only"
          )
          .length(10, "Mobile number must be exactly 10 digits"),
        restrictInput: "numeric",
      },
      {
        name: "whatsappNumber",
        label: "WhatsApp Number",
        type: "tel",
        placeholder: "+91-0000000000",
        required: false,
        inputMode: "tel",
        validation: z
          .string()
          .regex(
            /^[6-9]\d{9}$/,
            "WhatsApp number must be exactly 10 digits, start with 6-9, and contain numbers only"
          )
          .length(10, "WhatsApp number must be exactly 10 digits")
          .optional()
          .or(z.literal("")),
        restrictInput: "numeric",
      },
    ],
  },
];
export const addressDetailsConfig: FormSection[] = [
  {
    title: "Current Address Details:",
    fields: [
      {
        name: "nationality",
        label: "Nationality",
        type: "radio",
        required: true,
        gridColumn: "1 / -1",
        options: [
          { value: "I", label: "Indian" },
          { value: "O", label: "Other than Indian" },
        ],
      },
      {
        name: "country",
        label: "Country",
        type: "select",
        placeholder: "Select Country",
        required: true,
        options: countryOptions,
      },
      {
        name: "state",
        label: "State",
        type: "select",
        placeholder: "Select State",
        required: true,
        options: stateOptions,
      },
      {
        name: "district",
        label: "District",
        type: "select",
        placeholder: "Select District",
        required: true,
        options: districtOptions,
      },
      {
        name: "address1",
        label: "Address 1",
        type: "text",
        placeholder: "Address 1",
        required: true,
      },
      {
        name: "address2",
        label: "Address 2",
        type: "text",
        placeholder: "Address 2",
        required: false,
      },
      {
        name: "tehsil",
        label: "Tehsil",
        type: "text",
        placeholder: "Tehsil",
        required: true,
      },
      {
        name: "village",
        label: "Village/ City",
        type: "text",
        placeholder: "Village",
        required: true,
      },
      {
        name: "pincode",
        label: "Pincode",
        type: "text",
        placeholder: "Pin code",
        required: true,
      },
    ],
  },
  {
    title: "Permanent Address Details:",
    fields: [
      {
        name: "sameAsCurrentAddress",
        label: "Same as Current Address",
        type: "checkbox",
        required: false,
        gridColumn: "1 / -1",
      },
      {
        name: "p_country",
        label: "Country",
        type: "select",
        placeholder: "Select Country",
        required: true,
        options: countryOptions,
      },
      {
        name: "p_state",
        label: "State",
        type: "select",
        placeholder: "Select State",
        required: true,
        options: stateOptions,
      },
      {
        name: "p_district",
        label: "District",
        type: "select",
        placeholder: "Select District",
        required: true,
        options: districtOptions,
      },
      {
        name: "p_address1",
        label: "Address 1",
        type: "text",
        placeholder: "Address 1",
        required: true,
      },
      {
        name: "p_address2",
        label: "Address 2",
        type: "text",
        placeholder: "Address 2",
        required: false,
      },
      {
        name: "p_tehsil",
        label: "Tehsil",
        type: "text",
        placeholder: "Tehsil",
        required: true,
      },
      {
        name: "p_village",
        label: "Village/ City",
        type: "text",
        placeholder: "Village",
        required: true,
      },
      {
        name: "p_pincode",
        label: "Pincode",
        type: "text",
        placeholder: "Pin code",
        required: true,
      },
    ],
  },
];
export const reservationDetailsConfig: FormSection[] = [
  {
    title: "Reservation Details: ",
    fields: [
      {
        name: "domicileState",
        label: "Domicile State",
        type: "select",
        placeholder: "Select State",
        required: true,
        gridColumn: "1 / 2",
        options: [
          { value: "M", label: "Maharashtra" },
          { value: "O", label: "Outside Maharashtra" },
        ],
      },
      {
        name: "category",
        label: "Category",
        type: "select",
        placeholder: "Select Category",
        required: true,
      },
      {
        name: "religion",
        label: "Religion",
        type: "select",
        placeholder: "Select Religion",
        required: true,
      },
      {
        name: "caste",
        label: "Caste",
        type: "text",
        placeholder: "Caste",
        required: true,
        // hide caste for Scheduled Castes (show only for OBC/ST)
      },
      {
        name: "haveCasteCertificate",
        label: "Do you have a caste certificate?",
        type: "radio",
        required: true,
        // show only for Scheduled Castes
        visibleWhen: {
          field: "category",
          is: ["2", "3", "4", "5", "6", "7", "8", "9", "10"],
        },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "haveNCLCertificate",
        label: "Do you have a NCL certificate?",
        type: "radio",
        required: true,
        // NCL is applicable for OBC only
        visibleWhen: {
          field: "category",
          is: ["4", "5", "6", "7", "8", "9", "10"],
        },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "haveEWSCertificate",
        label: "Do you have a EWS certificate?",
        type: "radio",
        required: true,
        // hide for Scheduled Castes; show for OBC/ST
        visibleWhen: { field: "category", is: ["11"] },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "haveCasteValidity",
        label: "Do you have a caste validity?",
        type: "radio",
        required: true,
        // show only for Scheduled Castes
        visibleWhen: {
          field: "category",
          is: ["2", "3", "4", "5", "6", "7", "8", "9", "10"],
        },

        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "haveCasteValidityReceipt",
        label: "Do you have a caste validity receipt?",
        type: "radio",
        required: true,
        // show receipt only when category is OBC/SC/ST AND haveCasteValidity is 'no'
        visibleWhen: [
          { field: "haveCasteValidity", is: "no" },
          {
            field: "category",
            is: ["2", "3", "4", "5", "6", "7", "8", "9", "10"],
          },
        ],
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "previousCategory",
        label: "Previous Category",
        type: "select",
        placeholder: "Select Category",
        required: true,
        visibleWhen: { field: "category", is: ["9"] },
        gridColumn: "1 / 2",
        options: [
          { value: "SC", label: "SC" },
          { value: "ST", label: "ST" },
        ],
      },
      {
        name: "areOrphan",
        label: "Are you an orphan?",
        type: "radio",
        gridColumn: "1 / 2",
        required: true,
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "physicallyDisabled",
        label: "Are you physically disabled?",
        type: "radio",
        required: true,

        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "disabilityDetails",
        label: "Please provide details",
        type: "text",
        placeholder: "Details",
        required: false,
        visibleWhen: [{ field: "physicallyDisabled", is: "yes" }],
      },
      {
        name: "defensePersonnel",
        label: "Are you a child of Defense Personnel/Ex Servicemen?",
        type: "radio",
        required: true,
        gridColumn: "1 / 3",
        // Show defense-related fields only when domicile is Maharashtra
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "freedomFighter",
        label: "Is your parent or grandparent recognized as a Freedom Fighter?",
        type: "radio",
        required: true,
        gridColumn: "3 / 5",
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "governmentProject",
        label:
          "Has your family been affected or displaced due to any government development project?",
        type: "radio",
        required: true,
        gridColumn: "1 / -1",
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "IsSports",
        label: "Do you belong to the sports category (Sportsperson)?",
        type: "radio",
        gridColumn: "1 / 3",
        required: true,
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "sportsDetails",
        label: "Please provide details",
        type: "text",
        placeholder: "Details",
        gridColumn: "3 / 4",
        visibleWhen: [{ field: "domicileState", is: "M" }, { field: "IsSports", is: "yes" }],
        required: false,
      },
      {
        name: "nccStudent",
        label: "Are you an NCC student/cadet?",
        type: "radio",
        required: true,
        gridColumn: "1 / 2",
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "nssMember",
        label: "Are you a member of NSS?",
        type: "radio",
        required: true,
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "agricultureFamily",
        label: "Do you belong to an agriculture-based family?",
        type: "radio",
        gridColumn: "3 / 5",
        required: true,
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "minorityCommunity",
        label: "Do you belong to any 'Minority' community?",
        type: "radio",
        required: true,
        gridColumn: "1 / 3",
        visibleWhen: { field: "domicileState", is: "M" },
        options: [
          { value: "yes", label: "Yes" },
          { value: "no", label: "No" },
        ],
      },
      {
        name: "isReligiousMinorityYes",
        label: "Which religious minority do you belong to?",
        type: "select",
        placeholder: "Select",
        visibleWhen: [
          { field: "domicileState", is: "M" },
          { field: "minorityCommunity", is: "yes" },
        ],
        required: false,
        options: [
          { value: "1", label: "Religious" },
          { value: "2", label: "Linguistic" },
          { value: "3", label: "Both" },
        ],
      },
      {
        name: "religiousMinority",
        label: "Religious Minority",
        type: "select",
        placeholder: "Select",
        visibleWhen: [
          { field: "domicileState", is: "M" },
          { field: "minorityCommunity", is: "yes" },
          { field: "isReligiousMinorityYes", is: ["1", "3"] },
        ],
        required: false,
        options: [
          { value: "1", label: "Muslim" },
          { value: "2", label: "Christian" },
        ],
      },
      {
        name: "linguisticMinority",
        label: "Linguistic Minority",
        type: "select",
        placeholder: "Select Category",
        visibleWhen: [
          { field: "domicileState", is: "M" },
          { field: "minorityCommunity", is: "yes" },
          { field: "isReligiousMinorityYes", is: ["2", "3"] },
        ],
        required: false,
        options: [{ value: "1", label: "Urdu" }],
      },
    ],
  },
];

export const qualificationModalConfig: FormSection[] = [
  {
    title: "",
    fields: [
      {
        name: "qualificationType",
        label: "Qualification Type",
        type: "select",
        placeholder: "Select Type",
        required: true,
      },
      {
        name: "qualificationName",
        label: "Qualification Name",
        type: "select",
        placeholder: "Select Qualification Name",
        required: true,
      },
      {
        name: "boardName",
        label: "Board Name",
        type: "select",
        placeholder: "Select Board",
        gridColumn: "1 / 2",
        required: true,
        visibleWhen: {
          field: "qualificationType",
          is: ["7", "8", "9"],
        },
      },
      {
        name: "universityName",
        label: "University Name",
        type: "select",
        gridColumn: "1 / 2",
        placeholder: "Select University",
        required: true,
        visibleWhen: {
          field: "qualificationType",
          is: ["1", "2", "3", "4", "5", "6"],
        },
      },
      {
        name: "PRNNumber",
        label: "PRN / Registration Number",
        type: "text",
        placeholder: "Enter PRN / Registration Number",
        required: true,
      },
      {
        name: "passedAppeared",
        label: "Please select your course status: Passed / Appeared.",
        type: "radio",
        placeholder: "Enter Roll Number",
        required: true,
        gridColumn: "1 / -1",
        options: [
          { label: "Passed", value: "passed" },
          { label: "Appeared", value: "appeared" },
        ],
      },
      {
        name: "passingYear",
        label: "Passing Year",
        type: "select",
        placeholder: "Select State",
        required: true,
        visibleWhen: [{ field: "passedAppeared", is: "passed" }],

        options: Array.from({ length: 50 }, (_, i) => {
          const year = new Date().getFullYear() - i;
          return { label: String(year), value: String(year) };
        }),
      },
      {
        name: "passingMonth",
        label: "Passing Month",
        type: "select",
        placeholder: "Select Category",
        visibleWhen: [{ field: "passedAppeared", is: "passed" }],

        required: true,
        options: [
          { label: "January", value: "01" },
          { label: "February", value: "02" },
          { label: "March", value: "03" },
          { label: "April", value: "04" },
          { label: "May", value: "05" },
          { label: "June", value: "06" },
          { label: "July", value: "07" },
          { label: "August", value: "08" },
          { label: "September", value: "09" },
          { label: "October", value: "10" },
          { label: "November", value: "11" },
          { label: "December", value: "12" },
        ],
      },
      {
        name: "markingSystem",
        label: "Please select the applicable marking system.",
        type: "radio",
        gridColumn: "1 / -1",
        options: [
          { label: "Percentage", value: "Percentage" },
          { label: "Grade", value: "Grade" },
        ],
        required: true,
      },
      {
        name: "marksObtained",
        label: "Marks Obtained",
        type: "text",
        placeholder: "Enter Marks Obtained",
        required: true,
        restrictInput: "numeric",
        visibleWhen: [{ field: "markingSystem", is: "Percentage" }],
      },
      {
        name: "marksOutOf",
        label: "Marks Out Of",
        type: "text",
        placeholder: "Enter Marks Out Of",
        restrictInput: "numeric",
        required: true,
        visibleWhen: [{ field: "markingSystem", is: "Percentage" }],
      },
      {
        name: "percentage",
        label: "Percentage",
        type: "text",
        placeholder: "%",
        disabled: true,
        visibleWhen: [{ field: "markingSystem", is: "Percentage" }],
      },
      {
        name: "cgpaObtained",
        label: "CGPA Obtained",
        type: "text",
        placeholder: "Enter CGPA Obtained",
        required: true,
        visibleWhen: [{ field: "markingSystem", is: "Grade" }],
      },
      {
        name: "cgpaOutOf",
        label: "CGPA Out Of",
        type: "text",
        placeholder: "Enter CGPA Out Of",
        required: true,
        visibleWhen: [{ field: "markingSystem", is: "Grade" }],
      },
      {
        name: "grade",
        label: "Grade",
        type: "text",
        placeholder: "Enter Grade",
        required: true,
        visibleWhen: [{ field: "markingSystem", is: "Grade" }],
      },
    ],
  },
];

// Full page qualification table config
export const qualificationTableConfig = {
  tableName: "Qualification Details:",
  addButtonLabel: "Add New Qualification",
  columns: [
    { key: "srNo", label: "Sr. No", width: "60px" },
    { key: "qualificationType", label: "Qualification Type" },
    { key: "qualificationName", label: "Qualification Name" },
    { key: "boardUniversity", label: "Board/ University" },
    { key: "resultType", label: "Qualification Status" },
    { key: "percentage", label: "Percentage/ Grade" },
    { key: "passingMonthYear", label: "Passing Month/Year" },
    { key: "delete", label: "Delete", width: "80px" },
  ],
  emptyMessage:
    "No qualifications added yet. Click 'Add New Qualification' to begin.",
};

export const bankDetailsConfig: FormSection[] = [
  {
    title: "Bank Account Details:",
    fields: [
      {
        name: "bankName",
        label: "Select Bank",
        type: "text",
        placeholder: "Bank Name",
        required: true,
        gridColumn: "1 / 3",
        description:
          "Bank name will be auto-filled when you enter a valid IFSC code",
      },
      {
        name: "holderName",
        label: "Account Holder Name",
        type: "text",
        placeholder: "Name",
        required: true,
        gridColumn: "3/ 5",
      },
      {
        name: "branchName",
        label: "Branch Name",
        type: "text",
        placeholder: "Branch Name",
        gridColumn: "1 / 3",
        required: true,
        description:
          "Branch name will be auto-filled when you enter a valid IFSC code",
      },
      {
        name: "ifscCode",
        label: "IFSC Code",
        type: "text",
        placeholder: "e.g., SBIN0001234",
        gridColumn: "3 / 5",
        required: true,
        validation: z
          .string()
          .min(11, "IFSC code must be 11 characters")
          .max(11, "IFSC code must be 11 characters")
          .regex(
            /^[A-Z]{4}0[A-Z0-9]{6}$/i,
            "Invalid IFSC code format (e.g., SBIN0001234)"
          ),
      },
      {
        name: "accountNo",
        label: "Account Number",
        type: "text",
        placeholder: "Account Number",
        required: true,
        inputMode: "numeric",
        gridColumn: "1/ 3",
        validation: z
          .string()
          .min(9, "Account number must be at least 9 digits")
          .max(18, "Account number must not exceed 18 digits")
          .regex(/^\d+$/, "Account number must contain only digits"),
      },
      {
        name: "confirmAccountNo",
        label: "Confirm Account Number",
        type: "text",
        placeholder: "Re-enter Account Number",
        required: true,
        inputMode: "numeric",
        gridColumn: "3 / 5",
        validation: z
          .string()
          .regex(/^\d+$/, "Account number must contain only digits"),
      },
    ],
  },
];
export const photoSignConfig = {
  title: "Photo & Signature:",

  photo: {
    label: "Photo",
    acceptedFormats: ["image/jpeg", "image/jpg", "image/png"],
    maxSizeKB: 150,
    recommendedSize: "600x600 px",
    uploadButtonText: "Upload",
  },

  signature: {
    label: "Signature",
    acceptedFormats: ["image/jpeg", "image/jpg", "image/png"],
    maxSizeKB: 150,
    dimensionRange: {
      minWidth: 300,
      maxWidth: 600,
      minHeight: 100,
      maxHeight: 300,
    },
    uploadButtonText: "Upload",
  },

  confirmation: {
    text: "I hereby confirm that the photograph and signature uploaded are correct and belong to me.",
    required: true,
  },

  validation: {
    photoRequired: false,
    signatureRequired: false,
    bothRequired: false,
  },
};

export type PhotoSignConfig = typeof photoSignConfig;

export const documentDetailsConfig = {
  title: "Document Details:",

  instructions: [
    "Photograph must be approximately(width x height) 2×2 inch (600×600 px).",
    "Signature image must be between 1 inch × 0.33 inch and 2 inch × 1 inch in size (i.e., between 300×100 and 600×300 pixels).",
    "Photograph & Signature JPG/JPEG/PNG format, and less than 150 KB.",
  ],

  documents: [
    {
      id: "ssc_certificate",
      name: "SSC Certificate",
      fileType: ".pdf",
      required: true,
      acceptedFormats: [".pdf"],
      maxSizeKB: 2048, // 2MB
    },
    {
      id: "random_certificate",
      name: "Random Certificate",
      fileType: ".jpg, .jpeg, .png",
      required: false,
      acceptedFormats: [".jpg", ".jpeg", ".png"],
      maxSizeKB: 2048, // 2MB
    },
  ],

  tableHeaders: {
    documentName: "Document Name",
    fileType: "File Type",
    uploadedFile: "Uploaded File",
  },

  uploadButtonText: "Upload Document",

  validation: {
    allowedTypes: ["application/pdf", "image/jpeg", "image/jpg", "image/png"],
    maxFileSizeBytes: 2 * 1024 * 1024, // 2MB
  },
};

export type DocumentDetailsConfig = typeof documentDetailsConfig;

export const declarationConfig = {
  title: "Student Declaration:",

  instructionText:
    "Please read the declaration carefully and confirm your acceptance before submitting the form.",

  declarations: [
    "I hereby declare that all the information provided by me in this form is true, complete, and correct to the best of my knowledge.",
    "I confirm that all documents uploaded/submitted by me are genuine and have not been altered or misrepresented in any way.",
    "I understand that if any information provided is found to be false or misleading, my admission/application may be cancelled without prior notice.",
    "I agree to abide by all the rules, regulations, and policies of the institution, including academic, administrative, and disciplinary guidelines.",
    "I understand the fee structure and agree to pay all applicable fees within the specified timelines.",
    "I undertake that I will maintain proper conduct, follow anti-ragging rules, and uphold the dignity of the institution.",
    "I consent to the use of my personal, academic, and contact information by the institution for academic, administrative, and regulatory purposes.",
  ],

  signatureLabel: "Original",
  signatureRequired: true,

  acceptance: {
    required: true,
    showCheckbox: true,
  },

  submitButtonText: "Submit",
  previousButtonText: "Previous",
};

export type DeclarationConfig = typeof declarationConfig;
