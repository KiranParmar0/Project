"use client"

import { ReactNode } from 'react'
import { ChakraProvider, createSystem, defaultConfig } from '@chakra-ui/react'
import { ToastProvider } from '@chakra-ui/toast'
import { Global } from '@emotion/react'

const customConfig = {
  ...defaultConfig,
  theme: {
    ...defaultConfig.theme,
    semanticTokens: {
      ...defaultConfig.theme?.semanticTokens,
      colors: {
        ...defaultConfig.theme?.semanticTokens?.colors,
        'error': {
          value: { _light: '#DC2626', _dark: '#EF4444' }
        },
        'error.fg': {
          value: { _light: '#DC2626', _dark: '#EF4444' }
        },
        'error.emphasized': {
          value: { _light: '#B91C1C', _dark: '#DC2626' }
        },
        'error.subtle': {
          value: { _light: '#FEE2E2', _dark: '#7F1D1D' }
        }
      }
    }
  }
}

const system = createSystem(customConfig)

const rootVars = `
:root{
  --brand-500: #327245;
  --brand-700: #0b4f2c;
  --accent: #FB9300;
  --muted: #6b7280;
  --max-width: 1300px;
  --error-color: #DC2626;
  --error-bg: #FEE2E2;
}
body { font-family: var(--font-quicksand), sans-serif; margin:0; color: #1f2937; background: #fff }
`

const globalErrorStyles = `
[data-invalid] {
  border-color: var(--error-color) !important;
}

.chakra-form-error {
  color: var(--error-color);
  font-size: 0.875rem;
  margin-left: 10px;
  line-height: 1.25rem;
}

.chakra-form__error-message {
  color: var(--error-color);
  font-size: 0.875rem;
  margin: 15px 10px 0;
  line-height: 1.25rem;
}
`

export default function ChakraProviders({ children }: { children: ReactNode }) {
  return (
    <ChakraProvider value={system}>
      <Global styles={rootVars + globalErrorStyles} />
      {children}
    </ChakraProvider>
  )
}
