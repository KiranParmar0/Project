"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useEffect } from "react";

export function useAuth(redirectIfUnauthenticated = true) {
  const { data: session, status } = useSession();
  const router = useRouter();

  useEffect(() => {
    if (redirectIfUnauthenticated && status === "unauthenticated") {
      router.push("/auth/signin");
    }
  }, [status, redirectIfUnauthenticated, router]);

  return {
    session,
    status,
    isAuthenticated: status === "authenticated",
    isLoading: status === "loading",
    user: session?.user,
  };
}
