"use client";

import { useSession } from "next-auth/react";

export function useCurrentUser() {
  const { data: session, status } = useSession();

  return {
    user: session?.user || null,
    // role: session?.user?.role as "user" | "admin" | "superadmin" | undefined,
    loading: status === "loading",
    authenticated: status === "authenticated",
  };
}
