// src/app/api/master/security-questions/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { master_security_question } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const questions = await db.select()
      .from(master_security_question)
      .where(eq(master_security_question.IsActive, true));

    return NextResponse.json({
      success: true,
      data: questions
    });
  } catch (err: any) {
    console.error("[SECURITY-QUESTIONS ERROR]", err);
    return NextResponse.json({
      success: false,
      error: "Failed to fetch security questions"
    }, { status: 500 });
  }
}
