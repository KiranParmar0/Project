// src/app/api/auth/signup/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { registration_details, user_master, master_security_question, verification_tokens } from "@/db/schema";
import { eq, and } from "drizzle-orm";
import bcrypt from "bcryptjs";
import nodemailer from "nodemailer";

function generateOTP() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// local design/verify PDF (your pipeline will convert path to URL)
const DESIGN_VERIFY_PDF = "/mnt/data/Verify Email.pdf";

async function sendVerificationEmail(to: string, otp: string) {
  const {
    SMTP_HOST,
    SMTP_PORT,
    SMTP_USER,
    SMTP_PASS,
    FROM_EMAIL = "no-reply@example.com",
  } = process.env;

  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) {
    // dev fallback: log
    console.info(`\n==============================================`);
    console.info(`[DEV] Email Verification OTP`);
    console.info(`==============================================`);
    console.info(`To: ${to}`);
    console.info(`OTP: ${otp}`);
    console.info(`==============================================\n`);
    return false;
  }

  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS },
  });

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2>Email Verification</h2>
      <p>Hello,</p>
      <p>Thank you for creating an account. Your One-Time Password (OTP) for email verification is:</p>
      <div style="background-color: #f4f4f4; padding: 20px; text-align: center; font-size: 32px; font-weight: bold; letter-spacing: 5px; margin: 20px 0;">
        ${otp}
      </div>
      <p>This OTP will expire in 24 hours.</p>
      <p>If you didn't request this verification, please ignore this email.</p>
    </div>
  `;

  await transporter.sendMail({
    from: FROM_EMAIL,
    to,
    subject: "Email Verification OTP",
    html,
  });

  return true;
}

export async function POST(req: Request) {
  let candidateId: bigint | null = null;

  try {
    const body = await req.json();
    const fullName = (body?.fullName || "").toString().trim();
    const email = (body?.email || "").toString().trim();
    const password = (body?.password || "").toString();
    const securityQuestion = (body?.securityQuestion || "").toString().trim();
    const securityAnswer = (body?.securityAnswer || "").toString().trim();

    // Validate required fields
    if (!fullName || !email || !password || !securityQuestion || !securityAnswer) {
      return NextResponse.json({
        success: false,
        error: "All fields are required"
      }, { status: 400 });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json({
        success: false,
        error: "Invalid email format"
      }, { status: 400 });
    }

    // Check if email already exists in registration_details
    const existingCandidate = await db.select()
      .from(registration_details)
      .where(eq(registration_details.CandidateEmailID, email))
      .limit(1);

    if (existingCandidate.length > 0) {
      return NextResponse.json({
        success: false,
        error: "Email already registered"
      }, { status: 409 });
    }

    // Check if email already exists in user_master
    const existingUser = await db.select()
      .from(user_master)
      .where(eq(user_master.UserEmailID, email))
      .limit(1);

    if (existingUser.length > 0) {
      return NextResponse.json({
        success: false,
        error: "Email already registered"
      }, { status: 409 });
    }

    // Get client IP address
    const ip = req.headers.get("x-forwarded-for") ||
      req.headers.get("x-real-ip") ||
      "unknown";

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Find security question ID from master table
    let securityQuestionId: number | null = null;

    // Map security question values to IDs or search in master table
    const securityQuestions = await db.select().from(master_security_question);

    // Try to find matching question (case-insensitive partial match)
    const matchingQuestion = securityQuestions.find((q: typeof master_security_question.$inferSelect) =>
      q.SecurityQuestion?.toLowerCase().includes(securityQuestion.toLowerCase()) ||
      securityQuestion.toLowerCase().includes(q.SecurityQuestion?.toLowerCase() || '')
    );

    if (matchingQuestion) {
      securityQuestionId = matchingQuestion.SecurityQuestionID;
    }

    // Insert into Registration_Details
    const [newCandidate] = await db.insert(registration_details).values({
      CandidateName: fullName,
      CandidateEmailID: email,
      CandidateMobileNo: "", // Will be updated when user provides mobile
      CreatedByID: "SYSTEM",
      CreatedOnDate: new Date(),
      CreatedIPAddress: ip
    }).returning();

    candidateId = newCandidate.CandidateID;

    // Insert into User_Master for login credentials
    const [newUser] = await db.insert(user_master).values({
      UserTypeID: null, // Will be set by admin or defaults to null
      UserLoginID: email,
      UserPassword: hashedPassword,
      UserName: fullName,
      UserMobileNo: "", // Will be updated later
      UserEmailID: email,
      SecurityQuestionID: securityQuestionId,
      SecurityQuestionAnswer: securityAnswer,
      IsActive: false, // Will be activated after email verification
      CreatedByID: "SYSTEM",
      CreatedOnDate: new Date(),
      CreatedIPAddress: ip
    }).returning();

    // Generate 6-digit OTP
    const otp = generateOTP();

    // Store OTP in database (expires in 24 hours)
    const expiresAt = new Date();
    expiresAt.setHours(expiresAt.getHours() + 24);

    await db.insert(verification_tokens).values({
      Email: email,
      Token: otp,
      TokenType: "EMAIL_VERIFICATION",
      ExpiresAt: expiresAt,
      IsUsed: false
    });

    // Send verification email with OTP
    await sendVerificationEmail(email, otp);

    return NextResponse.json({
      success: true,
      candidateId: newCandidate.CandidateID.toString(),
      userId: newUser.UserID.toString(),
      email: email,
      message: "Account created successfully. Please check your email to verify your account."
    });

  } catch (err: any) {
    console.error("[SIGNUP ERROR]", err);

    // Rollback: Delete registration_details if it was created
    if (candidateId) {
      try {
        await db.delete(registration_details)
          .where(eq(registration_details.CandidateID, candidateId));
        console.log(`[ROLLBACK] Deleted registration record for CandidateID: ${candidateId}`);
      } catch (rollbackErr) {
        console.error("[ROLLBACK ERROR]", rollbackErr);
      }
    }

    // Provide user-friendly error messages
    let errorMessage = "Failed to create account";

    if (err?.message?.includes("foreign key constraint")) {
      errorMessage = "System configuration error. Please contact support.";
    } else if (err?.message?.includes("duplicate key")) {
      errorMessage = "Email already registered";
    } else if (err?.message) {
      errorMessage = err.message;
    }

    return NextResponse.json({
      success: false,
      error: errorMessage
    }, { status: 500 });
  }
}
