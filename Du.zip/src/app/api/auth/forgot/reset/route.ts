// src/app/api/auth/forgot/reset/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { user_master, verification_tokens } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";
import bcrypt from "bcryptjs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const resetToken = (body?.resetToken || "").toString().trim();
    const newPassword = (body?.newPassword || "").toString();

    if (!resetToken || !newPassword) {
      return NextResponse.json({
        success: false,
        error: "Reset token and new password are required"
      }, { status: 400 });
    }

    if (newPassword.length < 6) {
      return NextResponse.json({
        success: false,
        error: "Password must be at least 6 characters"
      }, { status: 400 });
    }

    // Find valid reset token
    const tokens = await db.select()
      .from(verification_tokens)
      .where(
        and(
          eq(verification_tokens.Token, resetToken),
          eq(verification_tokens.TokenType, 'RESET_TOKEN'),
          eq(verification_tokens.IsUsed, false),
          gt(verification_tokens.ExpiresAt, new Date())
        )
      )
      .limit(1);

    if (!tokens || tokens.length === 0) {
      return NextResponse.json({
        success: false,
        error: "Invalid or expired reset token"
      }, { status: 400 });
    }

    const token = tokens[0];
    const email = token.Email;

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update user password
    await db.update(user_master)
      .set({ UserPassword: hashedPassword })
      .where(eq(user_master.UserEmailID, email));

    // Mark token as used
    await db.update(verification_tokens)
      .set({ IsUsed: true })
      .where(eq(verification_tokens.TokenID, token.TokenID));

    return NextResponse.json({ success: true, message: "Password reset successful" });
  } catch (err: any) {
    console.error("[RESET-PASSWORD ERROR]", err);
    return NextResponse.json({
      success: false,
      error: "Failed to reset password"
    }, { status: 500 });
  }
}
