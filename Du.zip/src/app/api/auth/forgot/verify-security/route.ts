// src/app/api/auth/forgot/verify-security/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { user_master, verification_tokens } from "@/db/schema";
import { eq, and } from "drizzle-orm";

function makeResetToken() {
  return `RT-${Date.now()}-${Math.floor(Math.random() * 900000 + 100000)}`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = (body?.email || "").toString().trim();
    const questionId = Number(body?.questionId || 0);
    const answer = (body?.answer || "").toString().trim();

    if (!email || !questionId || !answer) {
      return NextResponse.json({
        success: false,
        error: "Email, question ID, and answer are required"
      }, { status: 400 });
    }

    // Find user with matching email, security question, and answer
    const users = await db.select()
      .from(user_master)
      .where(
        and(
          eq(user_master.UserEmailID, email),
          eq(user_master.SecurityQuestionID, questionId)
        )
      )
      .limit(1);

    if (!users || users.length === 0) {
      return NextResponse.json({
        success: false,
        error: "Invalid email or security question"
      }, { status: 400 });
    }

    const user = users[0];

    // Verify security answer (case-insensitive comparison)
    if (!user.SecurityQuestionAnswer ||
      user.SecurityQuestionAnswer.toLowerCase() !== answer.toLowerCase()) {
      return NextResponse.json({
        success: false,
        error: "Incorrect security answer"
      }, { status: 400 });
    }

    // Generate reset token
    const resetToken = makeResetToken();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    // Store reset token
    await db.insert(verification_tokens).values({
      Email: email,
      Token: resetToken,
      TokenType: 'RESET_TOKEN',
      ExpiresAt: expiresAt,
      IsUsed: false,
    });

    return NextResponse.json({ success: true, resetToken, email });
  } catch (err: any) {
    console.error("[VERIFY-SECURITY ERROR]", err);
    return NextResponse.json({
      success: false,
      error: "Failed to verify security question"
    }, { status: 500 });
  }
}
