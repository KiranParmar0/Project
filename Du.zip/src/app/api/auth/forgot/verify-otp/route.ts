// src/app/api/auth/forgot/verify-otp/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { verification_tokens } from "@/db/schema";
import { eq, and, gt } from "drizzle-orm";

function makeResetToken() {
  return `RT-${Date.now()}-${Math.floor(Math.random() * 900000 + 100000)}`;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = (body?.email || "").toString().trim();
    const otp = (body?.otp || "").toString().trim();

    if (!email || !otp) {
      return NextResponse.json({ success: false, error: "Email and OTP are required" }, { status: 400 });
    }

    // Find valid OTP in database
    const tokens = await db.select()
      .from(verification_tokens)
      .where(
        and(
          eq(verification_tokens.Email, email),
          eq(verification_tokens.Token, otp),
          eq(verification_tokens.TokenType, 'PASSWORD_RESET'),
          eq(verification_tokens.IsUsed, false),
          gt(verification_tokens.ExpiresAt, new Date())
        )
      )
      .limit(1);

    if (!tokens || tokens.length === 0) {
      return NextResponse.json({ success: false, error: "Invalid or expired OTP" }, { status: 400 });
    }

    const token = tokens[0];

    // Mark OTP as used
    await db.update(verification_tokens)
      .set({ IsUsed: true })
      .where(eq(verification_tokens.TokenID, token.TokenID));

    // Generate a reset token for password reset
    const resetToken = makeResetToken();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000); // 15 minutes

    // Store reset token
    await db.insert(verification_tokens).values({
      Email: email,
      Token: resetToken,
      TokenType: 'RESET_TOKEN',
      ExpiresAt: expiresAt,
      IsUsed: false,
    });

    return NextResponse.json({ success: true, resetToken, email });
  } catch (err: any) {
    console.error("[VERIFY-OTP ERROR]", err);
    return NextResponse.json({ success: false, error: "Failed to verify OTP" }, { status: 500 });
  }
}
