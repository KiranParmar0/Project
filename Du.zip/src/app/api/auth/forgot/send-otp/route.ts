// src/app/api/auth/forgot/send-otp/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { user_master, verification_tokens } from "@/db/schema";
import { eq } from "drizzle-orm";
import nodemailer from "nodemailer";

function generate6Digit() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

async function sendEmailOTP(to: string, otp: string) {
  const {
    SMTP_HOST,
    SMTP_PORT,
    SMTP_USER,
    SMTP_PASS,
    FROM_EMAIL = "no-reply@example.com",
  } = process.env;

  if (!SMTP_HOST || !SMTP_PORT || !SMTP_USER || !SMTP_PASS) {
    console.info(`[DEV-OTP-NOMAIL] SMTP not configured - OTP for ${to}: ${otp}`);
    return false;
  }

  const transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT),
    secure: Number(SMTP_PORT) === 465,
    auth: {
      user: SMTP_USER,
      pass: SMTP_PASS,
    },
  });

  const subject = `Password Reset Code — ${otp}`;
  const html = `
    <p>Hi,</p>
    <p>Your 6-digit password reset code is <b>${otp}</b>. It is valid for 10 minutes.</p>
    <p>If you did not request this, please ignore this email.</p>
  `;

  await transporter.sendMail({
    from: FROM_EMAIL,
    to,
    subject,
    html,
  });

  return true;
}

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = (body?.email || "").toString().trim();

    if (!email) {
      return NextResponse.json({ success: false, error: "Email is required" }, { status: 400 });
    }

    // Check if user exists in database
    const user = await db.select()
      .from(user_master)
      .where(eq(user_master.UserEmailID, email))
      .limit(1);

    if (!user || user.length === 0) {
      return NextResponse.json({ success: false, error: "Email not found" }, { status: 404 });
    }

    // Generate OTP
    const otp = generate6Digit();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

    // Store OTP in verification_tokens table
    await db.insert(verification_tokens).values({
      Email: email,
      Token: otp,
      TokenType: 'PASSWORD_RESET',
      ExpiresAt: expiresAt,
      IsUsed: false,
    });

    // Send OTP via email
    const sent = await sendEmailOTP(email, otp);
    if (!sent) {
      console.info(`[DEV-OTP] OTP for ${email}: ${otp}`);
    }

    return NextResponse.json({ success: true, message: "OTP sent to your email" });
  } catch (err: any) {
    console.error("[SEND-OTP ERROR]", err);
    return NextResponse.json({ success: false, error: "Failed to send OTP" }, { status: 500 });
  }
}
