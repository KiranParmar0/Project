// src/app/api/auth/login/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { user_master } from "@/db/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const email = (body?.email || "").toString().trim();
    const password = (body?.password || "").toString();

    // Validate required fields
    if (!email || !password) {
      return NextResponse.json({
        success: false,
        error: "Email and password are required"
      }, { status: 400 });
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json({
        success: false,
        error: "Invalid email format"
      }, { status: 400 });
    }

    // Find user by email
    const [user] = await db.select()
      .from(user_master)
      .where(eq(user_master.UserEmailID, email))
      .limit(1);

    if (!user) {
      return NextResponse.json({
        success: false,
        error: "Invalid email or password"
      }, { status: 401 });
    }

    // Check if user account is active
    if (!user.IsActive) {
      return NextResponse.json({
        success: false,
        error: "Email not verified. Please verify your email before logging in."
      }, { status: 403 });
    }

    // Verify password
    const isPasswordValid = await bcrypt.compare(password, user.UserPassword || "");
    if (!isPasswordValid) {
      return NextResponse.json({
        success: false,
        error: "Invalid email or password"
      }, { status: 401 });
    }

    // Update last login information
    const ip = req.headers.get("x-forwarded-for") ||
      req.headers.get("x-real-ip") ||
      "unknown";

    await db.update(user_master)
      .set({
        LastLoginDateTime: new Date(),
        LastLoginIPAddress: ip
      })
      .where(eq(user_master.UserID, user.UserID));

    // Return success with user info
    return NextResponse.json({
      success: true,
      userId: user.UserID.toString(),
      email: user.UserEmailID,
      name: user.UserName,
      message: "Login successful"
    });

  } catch (err: any) {
    console.error("[LOGIN ERROR]", err);
    return NextResponse.json({
      success: false,
      error: err?.message || "Failed to login"
    }, { status: 500 });
  }
}
