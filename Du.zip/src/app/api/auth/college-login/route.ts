import { NextResponse } from "next/server";
import { collegeLoginConfig } from "@/config/auth/collegeAuthConfig";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const identifier = ((body?.identifier || body?.email) || "").toString().trim();
    const password = (body?.password || "").toString();

    if (!identifier || !password) {
      return NextResponse.json({ success: false, error: "Identifier and password required" }, { status: 400 });
    }

    // Static test-only validation
    const { testCredentials } = collegeLoginConfig;
    // Normalize for test convenience: allow case-insensitive email and password
    const normalizedIdentifier = identifier.toLowerCase();
    const expectedIdentifier = (testCredentials.email || "").toLowerCase();
    const passwordMatches = password === testCredentials.password || password.toLowerCase() === (testCredentials.password || "").toLowerCase();

    console.log("[COLLEGE LOGIN ATTEMPT]", { identifier: normalizedIdentifier });

    if (normalizedIdentifier === expectedIdentifier && passwordMatches) {
      return NextResponse.json({
        success: true,
        userId: "college-test-user",
        identifier,
        name: "College Test User",
        role: "college",
        message: "College login successful (test)"
      });
    }

    return NextResponse.json({ success: false, error: "Invalid college credentials" }, { status: 401 });
  } catch (err: any) {
    console.error("[COLLEGE LOGIN ERROR]", err);
    return NextResponse.json({ success: false, error: err?.message || "Failed to login" }, { status: 500 });
  }
}
