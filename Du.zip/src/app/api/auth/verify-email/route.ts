// src/app/api/auth/verify-email/route.ts
import { NextResponse } from "next/server";
import { db } from "@/lib/drizzle";
import { verification_tokens, user_master } from "@/db/schema";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const otp = (body?.otp || "").toString().trim();
    const email = (body?.email || "").toString().trim();

    if (!otp) {
      return NextResponse.json({ success: false, error: "OTP is required" }, { status: 400 });
    }

    if (!email) {
      return NextResponse.json({ success: false, error: "Email is required" }, { status: 400 });
    }

    // Find the verification OTP for this email
    const [verificationToken] = await db.select()
      .from(verification_tokens)
      .where(
        and(
          eq(verification_tokens.Email, email),
          eq(verification_tokens.Token, otp),
          eq(verification_tokens.TokenType, "EMAIL_VERIFICATION"),
          eq(verification_tokens.IsUsed, false)
        )
      )
      .limit(1);

    if (!verificationToken) {
      return NextResponse.json({
        success: false,
        error: "Invalid OTP. Please check and try again."
      }, { status: 400 });
    }

    // Check if OTP is expired
    if (new Date() > verificationToken.ExpiresAt) {
      return NextResponse.json({
        success: false,
        error: "OTP has expired. Please request a new one."
      }, { status: 400 });
    }    // Mark token as used
    await db.update(verification_tokens)
      .set({ IsUsed: true })
      .where(eq(verification_tokens.TokenID, verificationToken.TokenID));

    // Activate the user account
    await db.update(user_master)
      .set({ IsActive: true })
      .where(eq(user_master.UserEmailID, verificationToken.Email));

    return NextResponse.json({
      success: true,
      email: verificationToken.Email,
      message: "Email verified successfully! You can now log in."
    });
  } catch (err: any) {
    console.error("[VERIFY-EMAIL ERROR]", err);
    return NextResponse.json({
      success: false,
      error: err?.message || "Failed to verify email"
    }, { status: 500 });
  }
}
