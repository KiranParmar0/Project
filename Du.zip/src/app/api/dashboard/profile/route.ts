// src/app/api/dashboard/profile/route.ts
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { createAuthOptions } from "@/lib/auth";
import { db } from "@/lib/drizzle";
import { registration_details, user_master } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const session = await getServerSession(createAuthOptions());

    if (!session || !session.user?.email) {
      return NextResponse.json(
        { success: false, error: "Unauthorized" },
        { status: 401 }
      );
    }

    // Get user from user_master
    const users = await db
      .select()
      .from(user_master)
      .where(eq(user_master.UserEmailID, session.user.email))
      .limit(1);

    if (!users || users.length === 0) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    const user = users[0];

    // Get registration details - assuming UserLoginID matches CandidateEmailID
    const registrations = await db
      .select()
      .from(registration_details)
      .where(eq(registration_details.CandidateEmailID, session.user.email))
      .limit(1);

    const registration = registrations && registrations.length > 0 ? registrations[0] : null;

    // Calculate profile completion percentage
    // This is a simple calculation - you can make it more sophisticated
    let completionPercentage = 0;
    if (registration) {
      completionPercentage = 30; // Basic registration completed
      // Add more logic based on other filled tables
    }

    const profileData = {
      name: user.UserName || registration?.CandidateName || "--",
      email: user.UserEmailID || "--",
      mobileNumber: user.UserMobileNo || registration?.CandidateMobileNo || "--",
      ipAddress: user.LastLoginIPAddress || registration?.CreatedIPAddress || "--",
      courseName: "--", // Will be populated from application data
      schoolName: "--", // Will be populated from application data
      courseYear: "--", // Will be populated from application data
      applicationStatus: registration ? "In Progress" : "Not Submitted",
      profileCompletion: completionPercentage,
      candidateId: registration?.CandidateID ? registration.CandidateID.toString() : null,
    };

    return NextResponse.json({
      success: true,
      data: profileData,
    });
  } catch (err: any) {
    console.error("[DASHBOARD-PROFILE ERROR]", err);
    return NextResponse.json(
      { success: false, error: "Failed to fetch profile data" },
      { status: 500 }
    );
  }
}
