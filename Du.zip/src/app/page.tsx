// src/app/page.tsx
"use client";
import React, { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import Welcome from "@/components/layout/Welcome";
import Programmes from "@/components/layout/Programmes";
import NewsEvents from "@/components/layout/NewsEvents";
import { Center, Spinner } from "@chakra-ui/react";

export default function HomePage() {
  const router = useRouter();
  const { data: session, status } = useSession();

  useEffect(() => {
    // If already logged in, redirect to dashboard
    if (status === "authenticated") {
      router.push("/dashboard");
    }
  }, [status, router]);

  // Show loader while checking session or if authenticated (redirecting)
  if (status === "loading" || status === "authenticated") {
    return (
      <Center minH="100vh">
        <Spinner size="xl" color="blue.500" />
      </Center>
    );
  }

  return (
    <>
      <Welcome />
      <Programmes />
      <NewsEvents />
    </>
  );
}
