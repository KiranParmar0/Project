"use client";

import VerifyEmailModalProps from "@/components/forms/VerifyEmailModal";
import { useRouter } from "next/navigation";

export default function VerifyEmailPage() {
  const router = useRouter();
  const email = "student@mail.com"; // replace with actual email from signup

  return (
    <VerifyEmailModalProps
      email={email}
      isOpen={true}
      onClose={() => {
        // Close handler → navigate to Sign-in (adjust as needed)
        router.push("/auth/signin");
      }}
      onVerify={(otp) => {
        console.log("OTP Verified:", otp);
        // On success → redirect to Sign-in or Dashboard
        router.push("/auth/signin");
      }}
      onResend={() => {
        console.log("Resend OTP triggered");
      }}
    />
  );
}
