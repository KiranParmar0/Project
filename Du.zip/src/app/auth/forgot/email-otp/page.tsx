"use client";
import React from "react";
import ForgotEmailOtp from "@/components/forms/ForgotEmailOtp";

export default function EmailOtpPage() {
  return (
    <ForgotEmailOtp
      defaultEmail=""
      onSend={(e: any) => console.log("send otp to", e)}
      onVerified={(e: any) => console.log("verified", e)}
    />
  );
}
