// src/app/auth/signup/page.tsx
import SignupForm from "@/components/forms/SignupForm";

export default function SignupPage() {
  return <SignupForm />;
}
