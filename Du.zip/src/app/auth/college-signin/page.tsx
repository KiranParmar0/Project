"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import LoginForm from "@/components/forms/LoginForm";
import { collegeLoginConfig } from "@/config/auth/collegeAuthConfig";
import { collegeSignIn } from "@/lib/collegeAuth";
import { toaster } from "@/components/ui/toaster";

export default function CollegeSigninPage() {
  const router = useRouter();
  const { data: session, status } = useSession();

  useEffect(() => {
    if (status === "authenticated") {
      router.push("/dashboard");
    }
  }, [status, router]);

  if (status === "loading") {
    return (
      <div style={{ display: "flex", justifyContent: "center", alignItems: "center", height: "100vh" }}>
        Loading...
      </div>
    );
  }

  const handleCollegeSubmit = async (data: any) => {
    const res = await collegeSignIn(data.email, data.password);
    if (res?.success) {
      toaster.create({ title: "Login successful", description: "College login (test)", type: "success", duration: 2000 });
      router.replace("/dashboard");
    } else {
      toaster.create({ title: "Login failed", description: res?.error || "Invalid credentials", type: "error", duration: 3000 });
      return;
    }
  };

  return <LoginForm labels={collegeLoginConfig.labels} onSubmit={handleCollegeSubmit} />;
}
