"use client";
import React from "react";
import DashboardLayout from "@/components/layout/DashboardLayout";
import { Box } from "@chakra-ui/react";

export default function ProfileLayout({ children }: { children: React.ReactNode }) {
  return (
    <DashboardLayout>
      <Box bg="gray.50" minH="100vh" p={4}>
        {/* Page Content */}
        <Box>{children}</Box>
      </Box>
    </DashboardLayout>
  );
}
