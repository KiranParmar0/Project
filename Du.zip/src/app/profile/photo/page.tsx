"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { toaster } from "@/components/ui/toaster";
import PhotoSignature from "@/components/forms/PhotoSignature";
import ProfilePageWrapper from "@/components/layout/ProfilePageWrapper";
import { useAuth } from "@/hooks/useAuth";

export default function PhotoPage() {
  const [defaultValues, setDefaultValues] = useState<any>(null);
  const router = useRouter();
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    // TODO: Fetch photo and signature from API
    if (isAuthenticated && user) {
      setDefaultValues({
        photo: null,
        signature: null,
      });
    }
  }, [isAuthenticated, user]);

  const handleNext = async () => {
    // TODO: Save photo and signature to API
    try {
      // API call would go here
      // await fetch('/api/profile/photo', { method: 'POST', body: JSON.stringify(data) })

      toaster.create({
        title: "Photo & Signature saved!",
        type: "success",
        duration: 2000,
      });

      router.push("/profile/documents");
    } catch (error) {
      toaster.create({
        title: "Failed to save",
        description: "Please try again",
        type: "error",
        duration: 3000,
      });
    }
  };

  if (!defaultValues) {
    return <div>Loading...</div>;
  }
  return (
    <ProfilePageWrapper activeTab="photo" profileProgress={0}>
      <PhotoSignature onNext={handleNext} />
    </ProfilePageWrapper>
  );
}