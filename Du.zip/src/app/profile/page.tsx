import StudentProfileWizard from "@/components/profile/StudentProfileWizard";

export default function ProfilePage() {
  return <StudentProfileWizard />;
}
