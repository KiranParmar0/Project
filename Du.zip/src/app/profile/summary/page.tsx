"use client";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "@chakra-ui/toast";
import ProfileSummary from "@/components/forms/ProfileSummary";
import ProtectedRoute from "@/components/auth/ProtectedRoute";
import { useAuth } from "@/hooks/useAuth";

export default function SummaryPage() {
  const [profileData, setProfileData] = useState<any>(null);
  const router = useRouter();
  const toast = useToast();
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    // Fetch profile data from API when authenticated
    if (isAuthenticated && user) {
      // TODO: Fetch actual profile data from API
      // For now, set empty object to avoid errors
      setProfileData({});
    }
  }, [isAuthenticated, user]);

  const handleEditSection = (section: string) => {
    // Map section names to their respective routes
    const sectionRoutes: Record<string, string> = {
      personal: "/profile/personal",
      address: "/profile/address",
      contact: "/profile/personal",
      qualification: "/profile/qualification",
      reservation: "/profile/reservation",
      photo: "/profile/photo",
      bank: "/profile/bank",
      documents: "/profile/documents",
    };

    const route = sectionRoutes[section];
    if (route) {
      router.push(route);
    }
  };

  const handleSubmit = async () => {
    // TODO: Submit profile data to API
    try {
      // Future: Make API call to submit application
      // const response = await fetch('/api/profile/submit', { ... });

      toast({
        title: "Application Submitted!",
        description: "Your application has been successfully submitted.",
        status: "success",
        duration: 3000,
      });

      // Redirect to success page
      router.push("/profile/success");
    } catch (error) {
      toast({
        title: "Submission Failed",
        description: "Failed to submit application. Please try again.",
        status: "error",
        duration: 5000,
      });
    }
  };

  if (!profileData) {
    return <div>Loading...</div>;
  }
  return (
    <ProtectedRoute>
      <ProfileSummary
        data={profileData}
        onEditSection={handleEditSection}
      />
    </ProtectedRoute>
  );
}

// How to feed real data

// When the user reaches this page:

// Fetch from DB:

// const profile = await db.query.profiles.findFirst({ where: eq(profiles.userId, session.user.id) });


// Pass the result to the component:

// <ProfileSummary data={profile} ... />


// Each document should include:

// { name: "SSC Certificate", url: "https://s3/.../file.pdf" }


// Photo/signature should include:

// photo: { url: "https://s3/..." }