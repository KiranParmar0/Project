import { ReactNode } from 'react';
// import { Quicksand } from 'next/font/google';
import ChakraProviders from '../providers/ChakraProviders';
import SessionProvider from '../components/providers/SessionProvider';
import { TRPCProvider } from '../lib/trpc-provider';
import MainContainer from '../components/layout/MainContainer';
import { PopupProvider } from '../contexts/PopupContext';
import GlobalPopupWrapper from '../components/ui/GlobalPopupWrapper';
import { Toaster } from '../components/ui/toaster';

// Temporarily disabled due to SSL certificate issues in build environment
// const quicksand = Quicksand({
//   subsets: ['latin'],
//   weight: ['300', '400', '500', '600', '700'],
//   display: 'swap',
//   variable: '--font-quicksand',
// });

export const metadata = {
  title: 'DU App',
  description: 'Dynamic University app starter'
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>
        <SessionProvider>
          <TRPCProvider>
            <ChakraProviders>
              <PopupProvider>
                <MainContainer>
                  {children}
                </MainContainer>
                <GlobalPopupWrapper />
                <Toaster />
              </PopupProvider>
            </ChakraProviders>
          </TRPCProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
