"use client";
import React from "react";
import dynamic from "next/dynamic";

const PaymentForm = dynamic(() => import("@/components/forms/Payment"), {
  ssr: false,
  loading: () => <div>Loading payment...</div>,
});

export default function DashboardPaymentPage() {
  return <PaymentForm />;
}
