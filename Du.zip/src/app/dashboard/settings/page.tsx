"use client";
import React from "react";
import dynamic from "next/dynamic";

const ApplicationStatus = dynamic(() => import("@/components/dashboard/ApplicationStatus"), {
  ssr: false,
  loading: () => <div>Loading status...</div>,
});

const mockData = {
  applicationId: "APPL-2025-0001",
  status: "submitted" as const,
  submittedAt: "2025-02-18",
};

export default function DashboardSettingsPage() {
  return <ApplicationStatus data={mockData} onEditSection={(s: string) => { /* navigate if needed */ }} />;
}
