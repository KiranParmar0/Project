"use client";
import React from "react";
import dynamic from "next/dynamic";

const DocumentDetails = dynamic(() => import("@/components/forms/DocumentDetails"), {
  ssr: false,
  loading: () => <div>Loading documents...</div>,
});

export default function DashboardDocumentsPage() {
  return <DocumentDetails />;
}
