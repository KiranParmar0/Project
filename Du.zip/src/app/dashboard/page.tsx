"use client";
import React from "react";
import DashboardHome from "../../components/dashboard/DashboardHome";

export default function DashboardPage() {
  return <DashboardHome />;
}
