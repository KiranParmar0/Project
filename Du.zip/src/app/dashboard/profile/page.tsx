"use client";
import React, { useEffect, useState } from "react";
import dynamic from "next/dynamic";
import { useRouter } from "next/navigation";
import { useToast } from "@chakra-ui/toast";
import mockDataFile from "@/data/mockData.json";

const ProfileSummary = dynamic(() => import("@/components/forms/ProfileSummary"), {
  ssr: false,
  loading: () => <div>Loading profile...</div>,
});

export default function DashboardProfilePage() {
  const [profileData, setProfileData] = useState<any>(null);
  const router = useRouter();
  const toast = useToast();

  useEffect(() => {
    const storedUser = localStorage.getItem("mockUser");
    if (storedUser) {
      const user = JSON.parse(storedUser);
      setProfileData(user.profile);
    } else {
      // Initialize with empty profile data if no mock data available
      setProfileData(null);
    }
  }, []);

  const handleEditSection = (section: string) => {
    const sectionRoutes: Record<string, string> = {
      personal: "/dashboard/apply#personal",
      address: "/dashboard/apply#address",
      contact: "/dashboard/apply#personal",
      qualification: "/dashboard/apply#qualification",
      reservation: "/dashboard/apply#reservation",
      photo: "/dashboard/apply#photo",
      bank: "/dashboard/apply#bank",
      documents: "/dashboard/apply#documents",
    };

    const route = sectionRoutes[section];
    if (route) router.push(route);
  };

  const handleSubmit = () => {
    const storedUser = localStorage.getItem("mockUser");
    if (storedUser) {
      const user = JSON.parse(storedUser);
      user.profile = profileData;
      user.profile.submittedAt = new Date().toISOString();
      user.profile.status = "submitted";
      localStorage.setItem("mockUser", JSON.stringify(user));
    }

    toast({
      title: "Application Submitted!",
      description: "Your application has been successfully submitted.",
      status: "success",
      duration: 3000,
    });

    router.push("/dashboard/success");
  };

  if (!profileData) return <div>Loading...</div>;

  return (
    <ProfileSummary data={profileData}  onEditSection={handleEditSection} />
  );
}
