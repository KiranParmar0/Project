"use client";
import React, { useEffect, useRef, useState } from "react";
import dynamic from "next/dynamic";
import { Box, Flex, Button, VStack, Text, HStack } from "@chakra-ui/react";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { trpc } from "@/lib/trpc";
import WelcomeBanner from "@/components/dashboard/WelcomeBanner";
import { useSession } from "next-auth/react";

const PersonalDetails = dynamic(() => import("@/components/forms/PersonalDetails"), { ssr: false });
const AddressDetails = dynamic(() => import("@/components/forms/AddressDetails"), { ssr: false });
const ReservationDetails = dynamic(() => import("@/components/forms/ReservationDetails"), { ssr: false });
const QualificationDetails = dynamic(() => import("@/components/forms/QualificationDetails"), { ssr: false });
const BankDetails = dynamic(() => import("@/components/forms/BankDetails"), { ssr: false });
const PhotoSignature = dynamic(() => import("@/components/forms/PhotoSignature"), { ssr: false });
const DocumentDetails = dynamic(() => import("@/components/forms/DocumentDetails"), { ssr: false });
const Declaration = dynamic(() => import("@/components/forms/Declaration"), { ssr: false });

const TABS = [
  { id: "personal", label: "Personal Details" },
  { id: "address", label: "Address Details" },
  { id: "reservation", label: "Reservation Details" },
  { id: "qualification", label: "Qualification Details" },
  { id: "bank", label: "Bank Details" },
  { id: "photo", label: "Photo Sign" },
  { id: "documents", label: "Document Details" },
  { id: "declaration", label: "Declaration" },
];

export default function DashboardApplyPage() {
  const refs = useRef<Record<string, HTMLDivElement | null>>({});
  const [active, setActive] = useState<string>(TABS[0].id);
  const { user } = useCurrentUser();
  const [profileProgress, setProfileProgress] = useState(0);
  const { data: session } = useSession();
  const role = (session?.user as any)?.role;
  const isCollege = !!role && role.toString().toLowerCase().includes("college");

  // Fetch profile status from tRPC
  const { data: profileStatus } = trpc.student.getProfileStatus.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // On first mount, prefer any explicit URL hash (e.g. /apply#address)
  useEffect(() => {
    if (typeof window === "undefined") return;
    const hash = window.location.hash.replace("#", "");
    if (hash) setActive(hash);
  }, []);

  // Keep in sync with future hash changes (router.push with # may trigger this)
  useEffect(() => {
    if (typeof window === "undefined") return;
    const onHashChange = () => {
      const h = window.location.hash.replace("#", "");
      if (h) setActive(h);
    };

    window.addEventListener("hashchange", onHashChange);
    return () => window.removeEventListener("hashchange", onHashChange);
  }, []);

  useEffect(() => {
    if (profileStatus) {
      setProfileProgress(profileStatus.profileProgress);
      // Set active tab to current section if available and no explicit hash
      if (profileStatus.currentSection && !window.location.hash) {
        setActive(profileStatus.currentSection);
      }
    }

    // on mount, if URL has a hash, set it as active (scroll happens in separate effect)
    if (typeof window !== "undefined") {
      const hash = window.location.hash.replace("#", "");
      if (hash) {
        setActive(hash);
      }
    }
  }, [profileStatus]);

  // When `active` changes and the element exists, scroll to it.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const el = refs.current[active];
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "start" });
      // keep URL hash in sync
      window.history.replaceState(null, "", `#${active}`);
    }
  }, [active]);

  const handleTabClick = (id: string) => {
    setActive(id);
    if (typeof window !== "undefined") {
      window.history.replaceState(null, "", `#${id}`);
    }
  };

  const handleNext = () => {
    const currentIndex = TABS.findIndex((t) => t.id === active);
    if (currentIndex < TABS.length - 1) {
      handleTabClick(TABS[currentIndex + 1].id);
    }
  };

  const handlePrevious = () => {
    const currentIndex = TABS.findIndex((t) => t.id === active);
    if (currentIndex > 0) {
      handleTabClick(TABS[currentIndex - 1].id);
    }
  };

  return (
    <Box>
      {/* Welcome Section with Tabs */}
      <Box mb={6}>
        <WelcomeBanner
          userName={user?.name ?? undefined}
          message={isCollege ? "Please fill and complete your college profile." : "Please fill and complete your student profile."}
          profileProgress={profileProgress}
          variant="circle"
          tabs={TABS}
          activeTab={active}
          onTabClick={handleTabClick}
        />
      </Box>

      {/* Form Content */}
      <Box bg="white" borderRadius="lg" boxShadow="sm" p={6}>
        <VStack align="stretch">
          {
            active === "personal" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["personal"] = el)} id="personal">
                <PersonalDetails onNext={handleNext} />
              </Box>
            )
          }

          {
            active === "address" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["address"] = el)} id="address">
                <AddressDetails onNext={handleNext} />
              </Box>
            )
          }
          {
            active === "reservation" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["reservation"] = el)} id="reservation">
                <ReservationDetails onNext={handleNext} />
              </Box>
            )
          }

          {
            active === "qualification" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["qualification"] = el)} id="qualification">
                <QualificationDetails onNext={handleNext} />
              </Box>
            )
          }
          {
            active === "bank" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["bank"] = el)} id="bank">
                <BankDetails onNext={handleNext} />
              </Box>
            )
          }
          {
            active === "photo" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["photo"] = el)} id="photo">
                <PhotoSignature onNext={handleNext} />
              </Box>
            )
          }

          {
            active === "documents" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["documents"] = el)} id="documents">
                <DocumentDetails onNext={handleNext} />
              </Box>
            )
          }
          {
            active === "declaration" && (
              <Box ref={(el: HTMLDivElement | null) => (refs.current["declaration"] = el)} id="declaration">
                <Declaration onNext={handleNext} />
              </Box>
            )
          }
        </VStack>
      </Box>
    </Box>
  );
}
