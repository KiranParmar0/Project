"use client";
import React from "react";
import { Box } from "@chakra-ui/react";
import CollegeProfileWizard from "@/components/profile/CollegeProfileWizard";

export default function CollegeProfilePage() {
  return (
    <Box p={6}>
      <CollegeProfileWizard />
    </Box>
  );
}
