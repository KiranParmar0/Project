"use client";
import React from "react";
import { trpc } from "@/lib/trpc-provider";
import { Center, Spinner, Box, Text, Table } from "@chakra-ui/react";

export default function CollegeApplicationsPage() {
  const { data, isLoading } = trpc.dashboard.getCollegeApplications.useQuery();

  if (isLoading) {
    return (
      <Center minH="300px">
        <Spinner />
      </Center>
    );
  }

  return (
    <Box p={6}>
      <Text fontSize="2xl" fontWeight={700} mb={4}>Applications</Text>
      <Table.Root variant="line" bg="white">
        <Table.Header>
          <Table.Row>
            <Table.ColumnHeader>ID</Table.ColumnHeader>
            <Table.ColumnHeader>Applicant</Table.ColumnHeader>
            <Table.ColumnHeader>Programme</Table.ColumnHeader>
            <Table.ColumnHeader>Status</Table.ColumnHeader>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {data?.map((a: any) => (
            <Table.Row key={a.id}>
              <Table.Cell>{a.id}</Table.Cell>
              <Table.Cell>{a.applicant}</Table.Cell>
              <Table.Cell>{a.programme}</Table.Cell>
              <Table.Cell>{a.status}</Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table.Root>
    </Box>
  );
}
