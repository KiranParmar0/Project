"use client";
import React from "react";
import { trpc } from "@/lib/trpc-provider";
import { Center, Spinner, Box, Text, Table } from "@chakra-ui/react";

export default function CollegeStudentsPage() {
  const { data, isLoading } = trpc.dashboard.getCollegeStudents.useQuery();

  if (isLoading) {
    return (
      <Center minH="300px">
        <Spinner />
      </Center>
    );
  }

  return (
    <Box p={6}>
      <Text fontSize="2xl" fontWeight={700} mb={4}>Manage Students</Text>
      <Table.Root variant="line" bg="white">
        <Table.Header>
          <Table.Row>
            <Table.ColumnHeader>ID</Table.ColumnHeader>
            <Table.ColumnHeader>Name</Table.ColumnHeader>
            <Table.ColumnHeader>Email</Table.ColumnHeader>
            <Table.ColumnHeader>Status</Table.ColumnHeader>
          </Table.Row>
        </Table.Header>
        <Table.Body>
          {data?.map((s: any) => (
            <Table.Row key={s.id}>
              <Table.Cell>{s.id}</Table.Cell>
              <Table.Cell>{s.name}</Table.Cell>
              <Table.Cell>{s.email}</Table.Cell>
              <Table.Cell>{s.status}</Table.Cell>
            </Table.Row>
          ))}
        </Table.Body>
      </Table.Root>
    </Box>
  );
}
