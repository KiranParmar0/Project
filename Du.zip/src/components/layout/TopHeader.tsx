"use client";
import React from "react";
import NextImage from "next/image";
import { Flex, Text, Box, Spacer, HStack, Button, Avatar, Menu, Portal, IconButton, Link } from "@chakra-ui/react";
import MdNotificationsNone from "../../assets/MdNotificationsNone.svg";
import { usePathname, useRouter } from "next/navigation";
import { Toaster, toaster } from "../ui/toaster";
import { signOut } from "next-auth/react";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { LuArrowLeft, LuBell, LuLogOut } from "react-icons/lu";

export default function TopHeader() {
  const { user } = useCurrentUser();
  const router = useRouter();
  const pathname = usePathname();
  
  // Check if user is a college
  const role = (user as any)?.role;
  const isCollege = !!role && role.toString().toLowerCase().includes("college");
  
  const handleLogout = async () => {
    // Clear any local storage or session storage
    if (typeof window !== 'undefined') {
      localStorage.clear();
      sessionStorage.clear();
    }

    // Sign out without auto-redirect
    await signOut({
      redirect: false
    });

    // Force redirect to login page
    window.location.href = "/auth/signin";
  };
  return (
    <Flex
      py={4}
      align="center"
    >
      <Toaster />
      <Text fontSize="md" fontWeight="800" color="green.700" lineHeight="1.6" textTransform={"uppercase"}>
        {
          pathname !== "/profile" && pathname !== "/dashboard/college/profile" ? "VASANTRAO NAIK MARATHWADA KRISHI VIDYAPEETH, Parbhani" : <Link color="green.700" onClick={() => router.push(isCollege ? "/dashboard" : "/dashboard")}><LuArrowLeft /> {isCollege ? "College Profile" : "Student Profile"}</Link>
        }
      </Text>
      <Spacer />

      {user && (
        <HStack gap={4} align="center">
          <IconButton size="sm" aria-label="Notifications" rounded="full" bg="white" variant="ghost">
            <LuBell color="gray" />
          </IconButton>
          <Text fontSize="sm" fontWeight="500" color="gray.700">
            {user.name ?? user.email ?? "User"}
          </Text>
          <Menu.Root>
            <Menu.Trigger asChild>
              <Button variant="ghost" size="sm" p={0}>
                <Avatar.Root size={"md"}>
                  <Avatar.Fallback>{user.name?.charAt(0) ?? user.email?.charAt(0) ?? "U"}</Avatar.Fallback>
                  {
                    user.image && (
                      <Avatar.Image src={user.image ?? ""} />
                    )
                  }
                </Avatar.Root>
              </Button>
            </Menu.Trigger>
            <Portal>
              <Menu.Positioner>
                <Menu.Content>
                  <Menu.Item value="logout" onClick={handleLogout} color="fg.error"
                    _hover={{ bg: "bg.error", color: "fg.error", cursor: "pointer" }}>
                    <LuLogOut />
                    Logout
                  </Menu.Item>
                </Menu.Content>
              </Menu.Positioner>
            </Portal>
          </Menu.Root>
        </HStack>
      )}
    </Flex>
  );
}
