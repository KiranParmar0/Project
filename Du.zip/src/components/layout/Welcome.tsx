"use client";
import React from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import img from "../../assets/image 2.png";
import i1 from "../../assets/College.png";
import i2 from "../../assets/content creation.png";
import i3 from "../../assets/University Building.png";
import i4 from "../../assets/Scholarship.png";
import i6 from "../../assets/Research_icon.svg";
import i7 from "../../assets/certificateicon.svg";
import { Box, Flex, Heading, Text, Button } from "@chakra-ui/react";
import type { StaticImageData } from "next/image";
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";


type StatItem = {
  icon: string | StaticImageData;
  number: number;
  label: string;
};

export default function Welcome() {
  const router = useRouter();

  const handleGetStarted = () => {
    router.push("/auth/signup");
  };

  const handleViewProgrammes = () => {
    router.push("/programmes");
  };

  const stats: StatItem[] = [
    { number: 30, label: "Affiliated Universities", icon: i1 },
    { number: 30, label: "Total UG Programmes", icon: i2 },
    { number: 30, label: "Total PG Programmes", icon: i2 },
    { number: 30, label: "Diploma Courses", icon: i2 },
    { number: 30, label: "Affiliated Colleges", icon: i3 },
    { number: 30, label: "Affiliated Agri. Tech. School", icon: i3 },
    { number: 30, label: "Total Students", icon: i4 },
    { number: 30, label: "Research Stations", icon: i6 },
    { number: 30, label: "Ph.D. Programmes", icon: i7 },
    { number: 30, label: "Constitutent Agri. Tech. School", icon: i3 }
  ];

  return (
    <Box as="section" maxW="var(--max-width)" mx="auto" py={{ base: 8, md: 12 }} px={4}>
      <Flex direction={{ base: "column", md: "row" }} gap={{ base: 8, md: 10 }}>
        {/* LEFT */}
        <Box flex={{ base: 'auto', md: '0 0 40%' }} mt={{ md: -6 }}>
          <Text color="var(--brand-500)" fontSize={{ base: '2xl', md: 'xl' }} mb={2}>Vasantrao Naik Marathwada Krishi Vidyapeeth</Text>

          <Heading as="h1" fontSize={{ base: '2xl', md: '5xl' }} fontWeight={500} lineHeight={1.1} mb={6}>
            Student Lifecycle <br /> Management
          </Heading>

          <Box maxH="440px" overflowY="auto" pr={2}>
            <Flex direction="column" gap={4}>
              {stats.map((item, index) => (
                <Flex key={index} align="center" gap={3} p={3} borderRadius="8px" >
                  <Box flexShrink={0} display="flex" gap={3} >
                    <Image src={item.icon} alt="" width={40} height={40} />
                    <Text fontSize="3xl" fontWeight={700} color="var(--brand-500)">{item.number}
                    </Text>
                    <Text color="var(--muted)" display="flex" fontSize="lg" alignItems="center">{item.label}
                    </Text>
                  </Box>
                </Flex>
              ))}
            </Flex>
          </Box>
        </Box>

        {/* RIGHT */}
        <Box flex="1">
          <Flex justify="space-between" align="center" pl={{ md: 20 }}>
            <Text color="var(--muted)">
              A comprehensive digital platform to manage every stage of a student&apos;s
              academic journey — from admission to graduation.
            </Text>

            <Flex gap={8} justifyContent="space-between">
              <Button
                aria-label="prev"
                rounded="full"
                w={10}
                h={10}
                bg="white"
                color="var(--brand-700)"
                borderWidth="1px"
                borderColor="rgba(0,0,0,0.12)"
                _hover={{ bg: 'gray.50' }}
                boxShadow="sm"
              >
                <FaArrowLeft size={16} />
              </Button>

              <Button
                aria-label="next"
                rounded="full"
                w={10}
                h={10}
                bg="white"
                color="var(--brand-700)"
                borderWidth="1px"
                borderColor="rgba(0,0,0,0.12)"
                _hover={{ bg: 'gray.50' }}
                boxShadow="sm"
              >
                <FaArrowRight size={16} />
              </Button>
            </Flex>
          </Flex>

          <Box mt={6} borderRadius="16px" overflow="hidden" boxShadow="md" h={{ base: '260px', md: '490px' }}>
            <Image src={img} alt="Main Visual" style={{ objectFit: 'cover', width: '100%', height: '100%' }} />
          </Box>
        </Box>
      </Flex>
    </Box>
  );
}
