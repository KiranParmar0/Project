"use client";
import React from "react";
import NextImage from "next/image";
import Logo from '../../assets/logo.png';
import { useRouter, usePathname } from "next/navigation";
import { useSession } from "next-auth/react";
import { Box, VStack, Text, Flex, Icon, HStack } from "@chakra-ui/react";
import { FaTachometerAlt, FaUser, FaGraduationCap, FaFileUpload, FaMoneyBillAlt, FaClipboardList, FaChevronDown } from 'react-icons/fa';

export default function Sidebar() {
  const router = useRouter();
  const pathname = usePathname();
  const { data: session } = useSession();
  const role = (session?.user as any)?.role;
  const isCollege = !!role && role.toString().toLowerCase().includes("college");

  const studentNav = [
    { label: "Dashboard", href: "/dashboard", icon: FaTachometerAlt },
    { label: "Student Profile", href: "/profile", icon: FaUser },
    { label: "Apply for program", href: "/apply", icon: FaGraduationCap },
    { label: "Settings", href: "/settings", icon: FaClipboardList },
  ];

  const collegeNav = [
    { label: "Dashboard", href: "/dashboard", icon: FaTachometerAlt },
    { label: "College Profile", href: "/dashboard/college/profile", icon: FaGraduationCap },
    { label: "Enrolment List", href: "/dashboard/college/students", icon: FaUser },
    { label: "Payment History", href: "/dashboard/college/applications", icon: FaClipboardList },
    { label: "Settings", href: "/settings", icon: FaClipboardList },
  ];

  const navItems = isCollege ? collegeNav : studentNav;

  // Determine the most-specific nav item that matches the current pathname.
  // This prevents the generic `/dashboard` item from remaining active when
  // a more specific child route (e.g. `/dashboard/college/profile`) is current.
  const activeHref = (() => {
    if (!pathname) return null;
    let best: string | null = null;
    for (const item of navItems) {
      const href = item.href;
      if (pathname === href || pathname.startsWith(href + "/")) {
        if (!best || href.length > best.length) {
          best = href;
        }
      }
    }
    return best;
  })();

  return (
    <Box
      as="aside"
      w={{ base: "72px", md: "250px" }}
      borderRight="1px solid"
      borderColor="gray.200"
      p={{ base: 3, md: 6 }}
      position="fixed"
      top={0}
      left={0}
      bottom={0}
      zIndex={40}
      overflowY="auto"
      bg="white"
    >
      <Flex direction="column" align={{ base: "center", md: "center" }} mb={8}>
        <Box
          w={16}
          h={16}
          overflow="hidden"
          role="button"
          aria-label="Go to home"
          cursor="pointer"
          onClick={() => router.replace('/')}
          mb={3}
        >
          <NextImage src={Logo} alt="logo" width={64} height={64} />
        </Box>
        <Text fontSize="xs" fontWeight={700} textAlign="center" display={{ base: "none", md: "block" }} color="gray.700">
          VNMKV Student Portal
        </Text>
      </Flex>

      <VStack align="stretch" gap={3}>
        {navItems.map((item) => {
          const active = item.href === activeHref;

          return (
            <Flex
              key={item.href}
              align="center"
              justify="space-between"
              px={{ base: 2, md: 4 }}
              py={3}
              borderRadius="8px"
              bg={active ? "black" : "transparent"}
              color={active ? "white" : "gray.700"}
              cursor="pointer"
              onClick={() => router.push(item.href)}
              transition="all 0.2s"
              _hover={{
                bg: active ? "black" : "gray.100",
              }}
            >
              <HStack gap={3} align="center">
                <Icon as={item.icon} boxSize={4} />
                <Text fontSize="sm" fontWeight={500} display={{ base: "none", md: "block" }}>
                  {item.label}
                </Text>
              </HStack>

              {active && (
                <Icon as={FaChevronDown} boxSize={3} display={{ base: "none", md: "block" }} />
              )}
            </Flex>
          );
        })}
      </VStack>
    </Box>
  );
}
