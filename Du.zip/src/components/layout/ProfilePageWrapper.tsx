"use client";
import React, { useCallback, useEffect, memo } from "react";
import { useRouter } from "next/navigation";
import { Box } from "@chakra-ui/react";
import WelcomeBanner from "@/components/dashboard/WelcomeBanner";
import { useCurrentUser } from "@/hooks/useCurrentUser";
import { trpc } from "@/lib/trpc";

const TABS = [
  { id: "personal", label: "Personal Details" },
  { id: "address", label: "Address Details" },
  { id: "reservation", label: "Reservation Details" },
  { id: "qualification", label: "Qualification Details" },
  { id: "bank", label: "Bank Details" },
  { id: "photo", label: "Photo Sign" },
  { id: "documents", label: "Document Details" },
  { id: "declaration", label: "Declaration" },
];

interface ProfilePageWrapperProps {
  activeTab: string;
  children: React.ReactNode;
  profileProgress?: number; // Optional - will fetch from API if not provided
}

function ProfilePageWrapper({
  activeTab,
  children,
  profileProgress: propProfileProgress,
}: ProfilePageWrapperProps) {
  const router = useRouter();
  const { user } = useCurrentUser();

  // Fetch profile status from API
  const { data: profileStatus } = trpc.student.getProfileStatus.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // Use API data if available, otherwise use prop value
  const profileProgress = profileStatus?.profileProgress ?? propProfileProgress ?? 0;

  // Prefetch all profile routes for instant navigation
  useEffect(() => {
    TABS.forEach((tab) => {
      router.prefetch(`/profile/${tab.id}`);
    });
  }, [router]);

  const handleTabClick = useCallback((id: string) => {
    router.push(`/profile/${id}`);
  }, [router]);

  return (
    <Box>
      <Box>
        {/* <WelcomeBanner
          userName={user?.name ?? undefined}
          profileProgress={profileProgress}
          variant="circle"
          tabs={TABS}
          activeTab={activeTab}
          onTabClick={handleTabClick}
        /> */}
      </Box>
      <Box bg="white" borderRadius="lg" boxShadow="sm" p={6}>
        {children}
      </Box>
    </Box>
  );
}

export default memo(ProfilePageWrapper);
