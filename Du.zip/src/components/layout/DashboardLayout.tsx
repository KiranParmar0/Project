"use client";
import React from "react";
import { Box, Flex } from "@chakra-ui/react";
import Sidebar from "./Sidebar";
import TopHeader from "./TopHeader";
import { usePathname } from "next/navigation";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() || "";

  // Map dashboard nested routes to a background color for the right content.
  // Adjust these values to match branding per section.
  let contentBg = "gray.50";
  if (pathname === "/dashboard") contentBg = "gray.50";
  else if (pathname.startsWith("/dashboard/profile")) contentBg = "gray.50";
  else if (pathname.startsWith("/dashboard/apply")) contentBg = "gray.50";
  else if (pathname.startsWith("/dashboard/documents")) contentBg = "gray.50";
  else if (pathname.startsWith("/dashboard/payment")) contentBg = "gray.50";
  else if (pathname.startsWith("/dashboard/settings")) contentBg = "gray.50";
  else if (pathname.startsWith("/profile")) contentBg = "gray.50";

  return (
    <Flex minH="100vh">
      {/* Left Sidebar (fixed) */}
      <Sidebar />

      {/* Right content section - add left margin to avoid overlap with fixed sidebar */}
      <Flex direction="column" flex={1} ml={{ base: "72px", md: "250px" }} p={4} bg={"#F5F8F8"}>
        {/* Top header */}
        <TopHeader />

        {/* Page content */}
        <Box bg={contentBg} minH="calc(100vh - 73px)" transition="background-color 200ms ease">{children}</Box>
      </Flex>
    </Flex>
  );
}
