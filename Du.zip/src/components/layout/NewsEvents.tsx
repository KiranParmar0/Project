"use client";
import React from 'react';
import { useRouter } from 'next/navigation';
import { Box, Grid, Heading, Text, Button, Flex, Link as ChakraLink, Icon } from '@chakra-ui/react'
import NextLink from 'next/link'
import { FaArrowLeft, FaArrowRight } from "react-icons/fa";

export default function NewsEvents() {
  const router = useRouter();

  const handleViewMore = () => {
    router.push("/news");
  };

  // REUSABLE link props - consistent behavior for all items
  const linkProps = {
    as: NextLink,
    href: "/news",
    role: 'group' as const,
    display: 'inline-flex',
    alignItems: 'center',
    textDecoration: 'none',
    color: 'whiteAlpha.900',
    transformStyle: 'preserve-3d' as const,
    transition: 'transform .18s, color .18s', // no mention of box-shadow here
    willChange: 'transform' as const,

    // Hover -> 3D pop + turn black
    _hover: {
      transform: 'translateY(-6px) scale(1.05)',
      color: 'black',
      textDecoration: 'none',
    },

    // Active -> ONLY change color + small press (no boxShadow, no border)
    _active: {
      color: 'black',
      transform: 'translateY(-2px)',
      boxShadow: 'none',
    },

    // Remove focus outline / ring (prevents box on keyboard focus)
    _focus: {
      boxShadow: 'none',
      outline: 'none',
    },

    // For better accessibility on some browsers
    _focusVisible: {
      boxShadow: 'none',
      outline: 'none',
    },

    // group hover for internal children
    _groupHover: {
      color: 'black',
    },
  };

  const makeColumn = (title: string) => (
    <Box textAlign="left">
      <Heading as="h4" mb={6} fontSize={{ base: 'lg', md: 'xl' }} fontWeight={700} textAlign="left">{title}</Heading>

      {/* item 1 */}
      <Box mb={6}>
        <Text fontSize={{ base: 'sm', md: 'md' }} mb={1} lineHeight={1.4}>City Council Approves New Public Park Development Project in Downtown Area</Text>
        <Text fontSize={{ base: 'xs', md: 'sm' }} color="var(--accent)" mb={2}>21 minutes ago</Text>
        <Box mt={2}>
          <ChakraLink {...linkProps}>
            <Text
              fontSize={{ base: 'sm', md: 'md' }}
              transition="color .18s, text-shadow .18s, transform .18s"
              _groupHover={{ color: 'black', transform: 'translateY(-2px)' }}
              textShadow="0 1px 0 rgba(255,255,255,0.06), 0 3px 6px rgba(0,0,0,0.12)"
              fontWeight={700}
            >
              Read More
            </Text>

            <Icon
              as={FaArrowRight}
              ml={3}
              color="currentColor"
              transition="transform .18s, color .18s"
              _groupHover={{ transform: 'translateY(-4px) rotate(10deg) scale(1.15)', color: 'black' }}
              boxSize={{ base: '18px', md: '20px' }}
            />
          </ChakraLink>
        </Box>
      </Box>

      {/* item 2 */}
      <Box mb={6}>
        <Text fontSize={{ base: 'sm', md: 'md' }} mb={1} lineHeight={1.4}>City Council Approves New Public Park Development Project in Downtown Area</Text>
        <Text fontSize={{ base: 'xs', md: 'sm' }} color="var(--accent)" mb={2}>21 minutes ago</Text>
        <Box mt={2}>
          <ChakraLink {...linkProps}>
            <Text
              transition="all .22s cubic-bezier(.175, .885, .32, 1.275)"
              textShadow="0 1px 0 rgba(255,255,255,0.06), 0 3px 6px rgba(0,0,0,0.12)"
              fontWeight={700}
              _groupHover={{ transform: 'translateY(-2px)', color: 'black' }}
            >
              Read More
            </Text>

            <Icon
              as={FaArrowRight}
              ml={3}
              color="currentColor"
              transition="all .22s cubic-bezier(.175, .885, .32, 1.275)"
              boxSize={{ base: '18px', md: '20px' }}
              _groupHover={{
                transform: 'translateY(-4px) rotate(12deg) scale(1.18)',
                color: 'black'
              }}
            />
          </ChakraLink>

        </Box>
      </Box>

      {/* item 3 */}
      <Box mb={6}>
        <Text fontSize={{ base: 'sm', md: 'md' }} mb={1} lineHeight={1.4}>City Council Approves New Public Park Development Project in Downtown Area</Text>
        <Text fontSize={{ base: 'xs', md: 'sm' }} color="var(--accent)" mb={2}>on 25 July 2025</Text>
        <Box mt={2}>
          <ChakraLink {...linkProps}>
            <Text
              transition="all .2s ease-out"
              fontWeight={700}
              textShadow="0 1px 0 rgba(255,255,255,0.06), 0 3px 6px rgba(0,0,0,0.12)"
              _groupHover={{
                color: 'black',
                transform: 'translateY(-2px)'
              }}
              _groupActive={{
                color: 'black',
                transform: 'translateY(-1px)',
              }}
            >
              Read More
            </Text>

            <Icon
              as={FaArrowRight}
              ml={3}
              color="currentColor"
              boxSize={{ base: '18px', md: '20px' }}
              transition="all .2s ease-out"
              _groupHover={{
                transform: 'translateY(-4px) scale(1.18)',
                color: 'black'
              }}
              _groupActive={{
                transform: 'translateY(-1px) scale(1.05)',
                color: 'black'
              }}
            />
          </ChakraLink>
        </Box>
      </Box>

      <Box>
        <Button
          onClick={handleViewMore}
          variant="ghost"
          mt={6}
          px={6}
          py={2}
          borderRadius="999px"
          border="2px solid"
          borderColor="white"
          color="white"
          bg="transparent"
          w={{ base: '160px', md: '140px' }}
          _hover={{ bg: 'var(--accent)', borderColor: 'var(--accent)' }}
        >
          View More
        </Button>
      </Box>
    </Box>
  )

  return (
    <Box as="section" bg="var(--brand-700)" color="white" py={{ base: 12, md: 20 }}>
      <Box maxW="var(--max-width)" mx="auto" px={{ base: 6, md: 12 }}>
        <Heading textAlign="center" mb={{ base: 6, md: 10 }} fontSize={{ base: 'lg', md: '2xl' }}>News & Events</Heading>

        <Grid textAlign='left' templateColumns={{ base: '1fr', md: 'repeat(3, 1fr)' }} gap={{ base: 6, md: 20 }}>
          {makeColumn('Upcoming Events')}
          {makeColumn('News/ Updates')}
          {makeColumn('Recruitment')}
        </Grid>
      </Box>
    </Box>
  );
}
