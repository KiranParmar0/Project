import React from 'react'
import { Box, Flex, Grid, Heading, Text } from '@chakra-ui/react'
import NextImage from 'next/image'
import Logo from '../../assets/logo.png'
import SocialMedia from '../../assets/Frame 163.png'
export default function Footer() {
  return (
    <Box as="footer" bg="white" py={8} w="full">
      <Box maxW="var(--max-width)" mx="auto" px={{ base: 6, md: 12 }}>
        {/* Top row: logo left, social right */}
        <Flex justify="space-between" align="center" mb={6} borderBottom="3px solid #F0EFEF">
          <Flex align="center" gap={3}>
            <Box>
              <NextImage src={Logo} alt="logo" width={25} height={22} />
            </Box>
            <Text fontSize="sm" color="gray.600" fontWeight={700} >VNMKV Student Portal</Text>
          </Flex>

          <Box>
            <NextImage src={SocialMedia} alt="social-icons" width={100} height={28} />
          </Box>
        </Flex>

        {/* Middle: three equal columns */}
        <Grid templateColumns={{ base: '1fr', md: 'repeat(3, 1fr)' }} gap={8} textAlign={{ base: 'left', md: 'left' }} mb={8}>
          <Box>
            <Heading as="h4" size="sm" mb={3} fontWeight={550}>Contact Us</Heading>
            <Text fontSize="sm" color="gray.700">Vasantrao Naik Marathwada Krishi Vidyapeeth,<br />Parbhani, Maharashtra - 431402</Text>
          </Box>

          <Box>
            <Heading as="h4" size="sm" mb={3} fontWeight={550}>Important Links</Heading>
            <Box as="ul" pl={0} style={{ listStyle: 'none' }}>
              <Box as="li" mb={2}><Text fontSize="sm">About Us</Text></Box>
              <Box as="li" mb={2}><Text fontSize="sm">Privacy Policy</Text></Box>
              <Box as="li" mb={2}><Text fontSize="sm">Disclaimer</Text></Box>
              <Box as="li"><Text fontSize="sm">Terms & Conditions</Text></Box>
            </Box>
          </Box>

          <Box>
            <Heading as="h4" size="sm" mb={3} fontWeight={550}>Helpdesk</Heading>
            <Text fontSize="sm" color="gray.700">Phone : 02452-223801<br />Timing : 10:00 am to 6:00 pm (All Days)</Text>
          </Box>
        </Grid>

        {/* Bottom: legal text stacked and right-aligned */}
        <Flex justify="flex-end" direction="column" align="flex-end">
          <Text fontWeight={650}>VNMKV Parbhani. All Rights Reserved.</Text>
        </Flex>
      </Box>
    </Box>
  )
}