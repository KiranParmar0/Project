"use client";
import React from "react";
import { usePathname } from "next/navigation";
import { Box } from "@chakra-ui/react";
import Header from "./Header";
import Footer from "./Footer";
import BackButton from "../ui/BackButton";

/**
 * MainContainer now accepts children so page content is rendered inside it.
 * This is required for Next.js app-router layout to show the current page.
 * Header/Footer only shown on public pages, Back button on auth/profile pages
 */
export default function MainContainer({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  // Routes where we show header and footer
  const publicRoutes = ["/", "/landing", "/programmes", "/news"];
  const showHeaderFooter = publicRoutes.includes(pathname);

  // Routes where we show back button instead
  // Only show BackButton for `/auth` routes; dashboard and profile use their own navigation
  const authRoutes = pathname.startsWith("/auth");

  return (
    <Box minH="100vh">
      {showHeaderFooter && <Header />}

      <Box mx="auto">
        {authRoutes && !showHeaderFooter && (
          <Box mt={4} ml={{ base: 0, md: 20 }}>
            <BackButton />
          </Box>
        )}
        {children}
      </Box>

      {showHeaderFooter && <Footer />}
    </Box>
  );
}
