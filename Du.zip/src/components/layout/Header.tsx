"use client";
import React from "react";
import NextImage from 'next/image';
import Logo from '../../assets/logo.png';
import {
  Box,
  Flex,
  HStack,
  Stack,
  Button,
  Text,
  Link,
  Icon,
  IconButton,
  useDisclosure,
  CloseButton,
  VStack,
} from '@chakra-ui/react';
import { useRouter } from "next/navigation";
import { collegeLoginConfig } from "@/config/auth/collegeAuthConfig";
import { FaPhoneAlt, FaEnvelope, FaFacebook, FaTwitter, FaInstagram, FaLinkedin, FaBars } from 'react-icons/fa';

export default function Header() {
  const router = useRouter();
  const disclosure = useDisclosure();
  const btnRef = React.useRef<HTMLButtonElement | null>(null);

  return (
    <Box as="header">
      {/* Top Bar */}
      {/* Main Header */}
      <Box borderBottom="1px solid #F0EFEF" >
        <Flex
          maxW="var(--max-width)"
          mx="auto"
          py={4}
          px={{ base: 6 }}
          align="center"
          justify="space-between"
        >
          <HStack gap={3} align="center">
            <Box w="60px" h="60px" overflow="hidden">
              <NextImage src={Logo} alt="University Logo" width={60} height={60} />
            </Box>
            <Box>
              <Text fontWeight={700} fontSize="lg" color="black">
                VNMKV Student Portal
              </Text>
            </Box>
          </HStack>

          <Box>
            <Stack
              gap={{ base: 2, md: 4 }}
              direction={{ base: 'column', md: 'row' }}
              align={{ base: 'stretch', md: 'center' }}
              display={{ base: 'none', md: 'flex' }}
            >
              <Button
                variant="ghost"
                color="gray.600"
                _hover={{ bg: 'var(--brand-500)', color: 'white', borderWidth: '2px' }}
                borderRadius="full"
                borderWidth="2px"
                px={{ base: 3, md: 6 }}
                py={{ base: 2, md: 3 }}
                w={{ base: '100%', md: 'auto' }}
                fontSize={{ base: 'sm', md: 'md' }}
                onClick={() => router.push('/auth/college-signin')}
                fontWeight={700}
              >
                {collegeLoginConfig.labels?.collegeLoginLabel ?? 'College Login'}
              </Button>

              <Button
                variant="ghost"
                color="gray.600"
                _hover={{ bg: 'var(--brand-500)', color: 'white', borderWidth: '2px' }}
                borderRadius="full"
                borderWidth="2px"

                px={{ base: 3, md: 6 }}
                py={{ base: 2, md: 3 }}
                w={{ base: '100%', md: 'auto' }}
                fontSize={{ base: 'sm', md: 'md' }}
                onClick={() => router.push('/auth/signin')}
                fontWeight={700}
              >
                Login
              </Button>

              <Button
                bg="var(--brand-500)"
                color="white"
                _hover={{ bg: 'var(--brand-700)' }}
                borderRadius="full"
                px={{ base: 3, md: 6 }}
                py={{ base: 2, md: 3 }}
                w={{ base: '100%', md: 'auto' }}
                fontSize={{ base: 'sm', md: 'md' }}
                onClick={() => router.push('/auth/signup')}
                fontWeight={700}
              >
                Register
              </Button>
            </Stack>

            <IconButton
              aria-label="Open menu"
              display={{ base: 'inline-flex', md: 'none' }}
              onClick={disclosure.onOpen}
              ref={btnRef}
              variant="ghost"
              size="md"
            >
              <Icon as={FaBars} />
            </IconButton>

            {disclosure.open && (
              <Box position="fixed" top={0} right={0} h="100vh" w="80%" bg="white" zIndex={50} p={4}>
                <Flex justify="flex-end">
                  <CloseButton onClick={disclosure.onClose} />
                </Flex>
                <Box mt={4}>
                  <VStack gap={4} align="stretch">
                    <Button
                      variant="ghost"
                      color="gray.600"
                      _hover={{ bg: 'var(--brand-500)', color: 'white' }}
                      borderRadius="full"
                      borderWidth="2px"
                      w="100%"
                      onClick={() => {
                        router.push('/auth/college-signin');
                        disclosure.onClose();
                      }}
                    >
                      {collegeLoginConfig.labels?.collegeLoginLabel ?? 'College Login'}
                    </Button>

                    <Button
                      variant="ghost"
                      color="gray.600"
                      _hover={{ bg: 'var(--brand-500)', color: 'white' }}
                      borderRadius="full"
                      borderWidth="2px"

                      w="100%"
                      onClick={() => {
                        router.push('/auth/signin');
                        disclosure.onClose();
                      }}
                    >
                      Login
                    </Button>

                    <Button
                      bg="var(--brand-500)"
                      color="white"
                      _hover={{ bg: 'var(--brand-700)' }}
                      borderRadius="full"
                      w="100%"
                      onClick={() => {
                        router.push('/auth/signup');
                        disclosure.onClose();
                      }}
                    >
                      Register
                    </Button>
                  </VStack>
                </Box>
              </Box>
            )}
          </Box>
        </Flex>
      </Box>
    </Box>
  );
}
