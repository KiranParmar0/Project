"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { Box, Flex, Heading, Text, Button } from '@chakra-ui/react'

export default function Programmes() {
  const router = useRouter();
  const tabs = ["Diploma Programmes", "UG Programmes", "PG Programmes", "PHD Programmes"];

  // use null for no active tab (so clicking same tab resets it)
  const [active, setActive] = useState<number | null>(0);

  const handleTabClick = (index: number) => {
    if (active === index) {
      setActive(null); // clicking same tab → unselect
    } else {
      setActive(index); // clicking new tab → activate
    }
  };

  const handleCourseClick = () => {
    router.push("/programmes");
  };

  return (
    <Box as="section" py={12}>
      <Flex direction="column" align="center" gap={6}>
        <Box w="100%" pb={6}>
          <Flex wrap="wrap" justify="center" gap={6}>
            {tabs.map((t, i) => {
              const isActive = active === i;
              return (
                <Button
                  key={i}
                  onClick={() => handleTabClick(i)}
                  variant="ghost"
                  bg="transparent"
                  color={isActive ? 'var(--brand-500)' : 'var(--muted)'}
                  fontWeight={isActive ? 700 : 500}
                  fontSize={isActive ? { base: 'lg', md: '2xl' } : { base: 'md', md: 'xl' }}
                  px={4}
                  py={2}
                  borderRadius={0}
                  // borderBottom={isActive ? '3px solid var(--brand-500)' : '3px solid transparent'}
                  transform={isActive ? 'translateY(-6px) scale(1.06)' : 'translateY(0) scale(1)'}
                  transition="transform 220ms cubic-bezier(.2,.9,.2,1), color 160ms ease, font-size 160ms ease, text-shadow 220ms ease"
                  zIndex={isActive ? 2 : 1}
                  textShadow={isActive ? '0 6px 20px rgba(15,23,42,0.06)' : 'none'}
                  _hover={{ color: 'var(--brand-700)', bg: 'transparent', transform: isActive ? 'translateY(-6px) scale(1.08)' : 'translateY(-3px) scale(1.02)' }}
                >
                  {t}
                </Button>
              );
            })}
          </Flex>
        </Box>

        <Flex wrap="wrap" justify="center" gap={8} w="100%">
          <Box w={{ base: '100%', md: '350px' }} p={6} pb={{ base: '75px', md: 6 }} borderRadius="15px" boxShadow="md" bg="white" position="relative" minH={{ base: 'auto', md: '550px' }}>
            <Heading as="h3" size="lg" mb={3} fontWeight={700}>Diploma in Agriculture Course</Heading>
            <Text fontSize='md' mb={2} fontWeight={550} >Course Overview:</Text>
            <Text mb={3}>The &quot;Diploma in Agriculture&quot; is a diploma-level programme aimed at training students in various aspects of agriculture (crop production, soil science, livestock, etc.).</Text>
            <Text fontSize='md' mb={2} fontWeight={550}>Course Duration: <Text as="span" fontWeight={400}>2 Years</Text></Text>
            <Text fontSize='md' mb={2} fontWeight={550}>Eligibility Criteria:</Text>
            <Box as="ul" style={{ listStyleType: 'disc' }} pl={6} mb={4}>
              <Box as="li" style={{ display: 'list-item' }}>10th (or equivalent) pass from recognized board</Box>
              <Box as="li" style={{ display: 'list-item' }}>Minimum aggregate marks (e.g., 50%)</Box>
            </Box>
            <Button onClick={handleCourseClick} position="absolute" bottom="24px" left="24px" right="24px" bg="transparent" border="2px solid var(--brand-500)" color="var(--brand-500)" borderRadius="30px" py={3} _hover={{ bg: 'var(--brand-500)', color: 'white' }}>View Course Information</Button>
          </Box>

          <Box w={{ base: '100%', md: '350px' }} p={6} pb={{ base: '75px', md: 6 }} borderRadius="15px" boxShadow="md" bg="white" position="relative" minH={{ base: 'auto', md: '550px' }}>
            <Heading as="h3" size="lg" mb={3} fontWeight={700}>Diploma in Agriculture Course</Heading>
            <Text fontSize='md' mb={2} fontWeight={550}>Course Overview:</Text>
            <Text mb={3}>The &quot;Polytechnic in Agriculture&quot; (sometimes called a &quot;Diploma in Agriculture&quot; through an agricultural polytechnic) is a diploma/polytechnic-level programme aimed at training students in various aspects of agriculture (crop production, soil science, horticulture, etc.).</Text>
            <Text fontSize='md' mb={2} fontWeight={550}>Course Duration: <Text as="span" fontWeight={400}>3 Years</Text></Text>
            <Text fontSize='md' mb={2} fontWeight={550}>Eligibility Criteria:</Text>
            <Box as="ul" style={{ listStyleType: 'disc' }} pl={6} mb={4}>
              <Box as="li" style={{ display: 'list-item' }}>10th standard (SSC) or equivalent from a recognized board</Box>
              <Box as="li" style={{ display: 'list-item' }}>minimum aggregate marks (e.g., 50%)</Box>
            </Box>
            <Button onClick={handleCourseClick} position="absolute" bottom="24px" left="24px" right="24px" bg="transparent" border="2px solid var(--brand-500)" color="var(--brand-500)" borderRadius="30px" py={3} _hover={{ bg: 'var(--brand-500)', color: 'white' }}>View Course Information</Button>
          </Box>
          <Box w={{ base: '100%', md: '350px' }} p={6} pb={{ base: '75px', md: 6 }} borderRadius="15px" boxShadow="md" bg="white" position="relative" minH={{ base: 'auto', md: '550px' }}>
            <Heading as="h3" size="lg" mb={3} fontWeight={700}>Diploma in Agriculture Course</Heading>
            <Text fontSize='md' mb={2} fontWeight={550}>Course Overview:</Text>
            <Text mb={3}>The course is designed to provide skill-oriented practical training in horticultural crops and gardening work — for persons who will work as malis/gardeners, nursery workers, landscape workers.</Text>
            <Text fontSize='md' mb={2} fontWeight={550}>Course Duration: <Text as="span" fontWeight={400}>1 Year</Text></Text>
            <Text fontSize='md' mb={2} fontWeight={550}>Eligibility Criteria:</Text>
            <Box as="ul" style={{ listStyleType: 'disc' }} pl={6} mb={4}>
              <Box as="li" style={{ display: 'list-item' }}>8th class pass</Box>
            </Box>
            <Button onClick={handleCourseClick} position="absolute" bottom="24px" left="24px" right="24px" variant="outline" border="2px solid var(--brand-500)" color="var(--brand-500)" borderRadius="30px" py={3} _hover={{ bg: 'var(--brand-500)', color: 'white' }}>View Course Information</Button>
          </Box>
        </Flex>
      </Flex>
    </Box>
  );
}
