"use client";
import React from "react";
import { Box, Flex, Text, HStack, Avatar, Circle, Button } from "@chakra-ui/react";
import NextImage from "next/image";
import ProfileImage from "../../assets/profile.image.svg";
import DonutChart from "@/components/ui/DonutChart";

interface Tab {
  id: string;
  label: string;
}

interface WelcomeBannerProps {
  userName?: string;
  message?: string;
  profileProgress: number;
  variant?: "donut" | "circle";
  tabs?: Tab[];
  activeTab?: string;
  onTabClick?: (id: string) => void;
}

export default function WelcomeBanner({
  userName = "User",
  message = "Please fill and complete your student profile.",
  profileProgress = 0,
  variant = "donut",
  tabs,
  activeTab,
  onTabClick,
}: WelcomeBannerProps) {
  const firstName = userName.split(" ")[0];

  return (
    <Box
      bg="white"
      borderRadius="12px"
      px={{ base: 4, md: 6 }}
      py={{ base: 3, md: 4 }}
      boxShadow="sm"
      border="1px solid"
      borderColor="gray.100"
      position="sticky"
      top={0}
      zIndex={10}
    >
      <Flex align="center" justify="space-between" gap={4} flexWrap="wrap" mb={tabs ? 4 : 0}>
        <HStack gap={4} align="center" flex="1" minW={{ base: "200px", md: "auto" }}>
          {variant === "donut" ? (
            <Box w="40px" h="40px" borderRadius="full" overflow="hidden" flexShrink={0}>
              <NextImage src={ProfileImage} alt="Profile" width={40} height={40} />
            </Box>
          ) : (
            <Avatar.Root size="lg" colorPalette="blue" flexShrink={0}>
              <Avatar.Fallback>{firstName.charAt(0)}</Avatar.Fallback>
            </Avatar.Root>
          )}

          <Box>
            <Text fontSize={{ base: "md", md: "xl" }} fontWeight={700} color="gray.800">
              Welcome, {firstName}
            </Text>
            <Text fontSize="sm" color="gray.600">
              {message}
            </Text>
          </Box>
        </HStack>

        <Flex align="center" gap={{ base: 2, md: 3 }} flexShrink={0}>
          <Text fontSize="sm" color="gray.700" fontWeight={600} display={{ base: "none", md: "block" }}>
            Profile
            <br />
            Progress:
          </Text>
          <Text fontSize="sm" color="gray.700" fontWeight={600} display={{ base: "block", md: "none" }}>
            Profile Progress:
          </Text>

          {variant === "donut" ? (
            <Box display="flex" alignItems="center" justifyContent="center">
              <DonutChart
                value={profileProgress}
                size={84}
                strokeWidth={10}
                segments={8}
                gapDegrees={6}
                filledColor="#E8921D"
                emptyColor="#C7D2C6"
              />
            </Box>
          ) : (
            <Circle size="70px" bg="orange.100" position="relative" overflow="hidden">
              <Circle size="60px" bg="white" position="absolute" zIndex={1} />
              <Box
                position="absolute"
                top="0"
                left="0"
                right="0"
                bottom="0"
                bg={`conic-gradient(#FF8C00 ${profileProgress}%, transparent ${profileProgress}%)`}
              />
              <Text position="relative" zIndex={2} fontSize="md" fontWeight="700" color="orange.600">
                {Math.round(profileProgress)}%
              </Text>
            </Circle>
          )}
        </Flex>
      </Flex>

      {/* Tabs Section */}
      {tabs && tabs.length > 0 && (
        <Flex gap={2} flexWrap="wrap" mt={4}>
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              size="sm"
              variant={activeTab === tab.id ? "solid" : "outline"}
              bg={activeTab === tab.id ? "#327245" : "transparent"}
              color={activeTab === tab.id ? "white" : "gray.700"}
              borderColor={activeTab === tab.id ? "#327245" : "gray.300"}
              _hover={{
                bg: activeTab === tab.id ? "#2a5f39" : "gray.50",
              }}
              onClick={() => onTabClick?.(tab.id)}
              borderRadius="md"
              px={4}
              py={2}
              fontSize="sm"
              fontWeight={500}
            >
              {tab.label}
            </Button>
          ))}
        </Flex>
      )}
    </Box>
  );
}
