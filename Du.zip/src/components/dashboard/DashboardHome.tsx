"use client";
import React from "react";
import { useRouter } from "next/navigation";
import { Box, Grid, Text, Flex, Center, Button, VStack, HStack, Spinner } from "@chakra-ui/react";
import { useSession } from "next-auth/react";
import WelcomeBanner from "@/components/dashboard/WelcomeBanner";
import { trpc } from "@/lib/trpc-provider";

export default function DashboardHome() {
  const router = useRouter();

  // Use tRPC query
  const { data: profileData, isLoading: isLoadingProfile } = trpc.dashboard.getProfile.useQuery();
  const { data: profileStatus, isLoading: isLoadingStatus } = trpc.student.getProfileStatus.useQuery();

  const { data: session } = useSession();

  console.log("Profile Data:", profileData);

  const handleStartApplication = () => {
    // Navigate to the profile wizard (student)
    router.push("/profile");
  };

  const handleViewStatus = () => {
    router.push("/dashboard/settings");
  };

  const handleViewProgrammes = () => {
    router.push("/programmes");
  };

  if (isLoadingProfile || isLoadingStatus) {
    return (
      <Center minH="400px">
        <Spinner size="xl" color="green.700" />
      </Center>
    );
  }

  const firstName = profileData?.name?.split(" ")[0] || "User";
  const completionPercentage = profileStatus?.profileProgress || profileData?.profileCompletion || 0;
  const role = (session?.user as any)?.role;
  const isCollege = !!role && role.toString().toLowerCase().includes("college");

  function formatDateTime(val: any) {
    if (!val) return "--";
    try {
      const d = new Date(val);
      if (isNaN(d.getTime())) return String(val);
      return d.toLocaleString();
    } catch (e) {
      return String(val);
    }
  }

  return (
    <Box>
      {/* Top welcome banner */}
      <WelcomeBanner
        userName={profileData?.name}
        profileProgress={completionPercentage}
        variant="circle"
      />

      {/* Main info card */}
      <Box mt={4} p={{ base: 4, md: 6 }} borderRadius="12px" boxShadow="sm" bg="white" border="1px solid" borderColor="gray.100">
        {isCollege ? (
          <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={6}>
            <Box>
              <Text fontSize="sm" color="gray.600">Name:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.name || "SP College"}</Text>

              <Text fontSize="sm" color="gray.600">Email Address:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.email || "--"}</Text>

              <Text fontSize="sm" color="gray.600">IP Address:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.ipAddress || "--"}</Text>

              <Text fontSize="sm" color="gray.600">Mobile Number:</Text>
              <Text fontSize="sm" fontWeight={600}>{profileData?.mobileNumber || "--"}</Text>
            </Box>

            <Box>
              <Text fontSize="sm" color="gray.600">Designation:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{(profileData as any)?.designation || "--"}</Text>

              <Text fontSize="sm" color="gray.600">College Application Status:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.applicationStatus || "--"}</Text>

              <Text fontSize="sm" color="gray.600">Last Logged In:</Text>
              <Text fontSize="sm" fontWeight={600}>{formatDateTime((profileData as any)?.lastLogin || (profileData as any)?.lastLoginDateTime || (profileData as any)?.lastLoggedIn)}</Text>
            </Box>
          </Grid>
        ) : (
          <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={6}>
            <Box>
              <Text fontSize="sm" color="gray.600">Name:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.name || ""}</Text>

              <Text fontSize="sm" color="gray.600">Email Address:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.email || "--"}</Text>

              <Text fontSize="sm" color="gray.600">IP Address:</Text>
              <Text fontSize="sm" fontWeight={600} mb={3}>{profileData?.ipAddress || "--"}</Text>

              <Text fontSize="sm" color="gray.600">Mobile Number:</Text>
              <Text fontSize="sm" fontWeight={600}>{profileData?.mobileNumber || "--"}</Text>
            </Box>

            <Box>
              <Grid templateColumns="1fr 1fr" gap={4}>
                <Box>
                  <Text fontSize="sm" color="gray.600">Course Name:</Text>
                  <Text fontSize="sm" fontWeight={600}>{profileData?.courseName || "--"}</Text>
                </Box>

                <Box>
                  <Text fontSize="sm" color="gray.600">School Name:</Text>
                  <Text fontSize="sm" fontWeight={600}>{profileData?.schoolName || "--"}</Text>
                </Box>
              </Grid>

              <Grid templateColumns="1fr 1fr" gap={4} mt={3}>
                <Box>
                  <Text fontSize="sm" color="gray.600">Course Year:</Text>
                  <Text fontSize="sm" fontWeight={600}>{profileData?.courseYear || "--"}</Text>
                </Box>

                <Box>
                  <Text fontSize="sm" color="gray.600">Application Status:</Text>
                  <Box
                    display="inline-block"
                    bg={profileData?.applicationStatus === "Not Submitted" ? "#FFECEC" : "#E8F5E9"}
                    color={profileData?.applicationStatus === "Not Submitted" ? "#E53E3E" : "#2E7D32"}
                    px={3}
                    py={1}
                    borderRadius="md"
                    fontSize="sm"
                    fontWeight={600}
                  >
                    {profileData?.applicationStatus || "Not Submitted"}
                  </Box>
                </Box>
              </Grid>
            </Box>
          </Grid>
        )}

        <Center mt={6}>
          <Button bg="#327245" color="white" _hover={{ bg: "#276033" }} borderRadius="full" px={8} py={4} onClick={() => router.push(isCollege ? "/dashboard/college/profile" : "/profile") }>
            {isCollege ? 'Click Here to Complete Your College Profile' : 'Click Here to Complete Your Student Profile'}
          </Button>
        </Center>
      </Box>

      {/* Instructions card */}
      <Box mt={4} p={6} borderRadius="12px" boxShadow="sm" bg="white" border="1px solid" borderColor="gray.100">
        <Text fontWeight={700} mb={4}>Instructions:</Text>
        <VStack align="stretch" gap={2} fontSize="sm" color="gray.700">
          <Text>1. Read the entire form carefully before you begin.</Text>
          <Text>2. Enter correct details exactly as per your official documents.</Text>
          <Text>3. Keep all required documents ready (marksheets, Aadhaar, photos, certificates).</Text>
          <Text>4. Check eligibility criteria before selecting your course.</Text>
          <Text>5. Provide a valid and active mobile number and email ID.</Text>
          <Text>6. Fill in all mandatory fields without leaving blanks.</Text>
          <Text>7. Upload documents in the correct format and size for online forms.</Text>
          <Text>8. Review all information thoroughly before submitting.</Text>
          <Text>9. Submit the form before the given deadline.</Text>
          <Text>10. Save or print a copy of the submitted form and receipt.</Text>
          <Text>11. Contact the admission office if you face any issues while filling the form.</Text>
        </VStack>
      </Box>
    </Box>
  );
}

function DashboardCard({ title, value }: any) {
  return (
    <Box

      p={6}
      borderRadius="md"
      boxShadow="sm"
      border="1px solid"
      borderColor="gray.100"
    >
      <Text fontSize="md" color="gray.600">
        {title}
      </Text>
      <Text fontSize="2xl" fontWeight="700" mt={2}>
        {value}
      </Text>
    </Box>
  );
}
