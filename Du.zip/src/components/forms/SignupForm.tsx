"use client";
import React, { useState } from "react";
import { useRouter } from "next/navigation";
import { toaster, Toaster } from "../ui/toaster";
import NextImage from 'next/image';
import Logo from '../../assets/logo.png';
import {
  Box,
  Stack,
  Input,
  Button,
  Text,
  Link,
  Center,
  HStack,
  Image,
} from "@chakra-ui/react";
import {
  FormControl,
  FormErrorMessage,
  FormLabel,
} from "@chakra-ui/form-control";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import VerifyEmailModal from "./VerifyEmailModal";
import { trpc } from "@/lib/trpc-provider";

const EyeIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

const EyeOffIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);

const BackArrowIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <line x1="19" y1="12" x2="5" y2="12" />
    <polyline points="12 19 5 12 12 5" />
  </svg>
);



const SignupSchema = z
  .object({
    fullName: z.string().min(1, "Full name is required"),
    email: z.string().email("Enter a valid email"),
    password: z.string().min(8, "Password must be at least 8 characters"),
    confirmPassword: z.string().min(8, "Confirm your password"),
    securityQuestion: z.string().min(1, "Select a security question"),
    securityAnswer: z.string().min(1, "Security answer is required"),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

type SignupForm = z.infer<typeof SignupSchema>;

interface SecurityQuestion {
  SecurityQuestionID: number;
  SecurityQuestion: string;
  IsActive: boolean;
}

export default function SignupForm({
  onSuccess,
}: {
  onSuccess?: (payload: any) => void;
}) {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [userEmail, setUserEmail] = useState("");
  const [securityQuestions, setSecurityQuestions] = useState<SecurityQuestion[]>([]);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<SignupForm>({
    resolver: zodResolver(SignupSchema),
    defaultValues: {
      fullName: "",
      email: "",
      password: "",
      confirmPassword: "",
      securityQuestion: "",
      securityAnswer: "",
    },
  });

  // Fetch security questions using tRPC
  const { data: questionsData } = trpc.master.getSecurityQuestions.useQuery();
  console.log("questionsData", questionsData);

  React.useEffect(() => {
    if (questionsData) {
      setSecurityQuestions(
        questionsData.map((q: { id: number; question: string }) => ({
          SecurityQuestionID: q.id,
          SecurityQuestion: q.question,
          IsActive: true,
        }))
      );
    }
  }, [questionsData]);

  const signupMutation = trpc.auth.signup.useMutation({
    onSuccess: (result) => {
      // Store email for verification modal
      setUserEmail(result.email || "");
      if (typeof window !== "undefined") {
        sessionStorage.setItem("verifyEmail", result.email || "");
      }

      toaster.create({
        title: "Account created successfully!",
        description: result.message || "Please verify your email to continue.",
        type: "success",
      });

      // Open verification modal
      setIsVerifyModalOpen(true);

      onSuccess?.(result);
    },
    onError: (error) => {
      toaster.create({
        title: "Signup failed",
        description: error.message || "Unable to create account",
        type: "error",
        duration: 5000,
      });
    },
  });

  const submit = async (data: SignupForm) => {
    signupMutation.mutate({
      name: data.fullName,
      email: data.email,
      password: data.password,
      securityQuestionId: parseInt(data.securityQuestion),
      securityAnswer: data.securityAnswer,
    });
  };

  return (
    <Center >
      <Toaster />
      <Box
        w="full"
        maxW="520px"
        borderRadius="12px"
      >
        <Stack gap={6}>
          <Center>
            <NextImage src={Logo} alt="logo" width={110} height={32} />
          </Center>

          <Text fontSize="20px" fontWeight={600} textAlign="center" lineHeight={1.5}>
            Vasantrao Naik Marathwada Krishi Vidyapeeth,
            <br />
            Parbhani - 431 402 (Maharashtra)
          </Text>

          <Box as="form" width="100%" onSubmit={handleSubmit(submit)}>
            <Stack gap={4}>
              <FormControl isInvalid={!!errors.fullName}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>Full Name</FormLabel>
                <Input
                  placeholder="Full Name"
                  borderRadius="25px"
                  {...register("fullName")}
                />
                {errors.fullName?.message && (
                  <FormErrorMessage>{errors.fullName.message}</FormErrorMessage>
                )}
              </FormControl>

              <FormControl isInvalid={!!errors.email}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>Email Address</FormLabel>
                <Input
                  type="email"
                  placeholder="you@example.com"
                  borderRadius="25px"
                  {...register("email")}
                />
                {errors.email?.message && (
                  <FormErrorMessage>{errors.email.message}</FormErrorMessage>
                )}
              </FormControl>

              <FormControl isInvalid={!!errors.password}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>Create Password</FormLabel>
                <Box position="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Create password"
                    borderRadius="25px"
                    pr="40px"
                    {...register("password")}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    style={{
                      position: "absolute",
                      right: "12px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#999",
                      padding: 0,
                    }}
                  >
                    {showPassword ? <EyeOffIcon /> : <EyeIcon />}
                  </button>
                </Box>
                {errors.password?.message && (
                  <FormErrorMessage>{errors.password.message}</FormErrorMessage>
                )}
              </FormControl>

              <FormControl isInvalid={!!errors.confirmPassword}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>Confirm Password</FormLabel>
                <Box position="relative">
                  <Input
                    type={showConfirm ? "text" : "password"}
                    placeholder="Confirm password"
                    borderRadius="25px"
                    pr="40px"
                    {...register("confirmPassword")}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm((s) => !s)}
                    style={{
                      position: "absolute",
                      right: "12px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#999",
                      padding: 0,
                    }}
                  >
                    {showConfirm ? <EyeOffIcon /> : <EyeIcon />}
                  </button>
                </Box>
                {errors.confirmPassword?.message && (
                  <FormErrorMessage>{errors.confirmPassword.message}</FormErrorMessage>
                )}
              </FormControl>

              <FormControl isInvalid={!!errors.securityQuestion}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>Security Question</FormLabel>
                <Box position="relative">
                  <select
                    {...register("securityQuestion")}
                    aria-label="Security Question"
                    style={{
                      borderRadius: "25px",
                      height: "48px",
                      width: "100%",
                      paddingLeft: "16px",
                      paddingRight: "48px",
                      borderWidth: "1px",
                      borderStyle: "solid",
                      borderColor: "#e2e8f0",
                      backgroundColor: "white",
                      cursor: "pointer",
                      fontSize: "16px",
                      appearance: "none",
                      WebkitAppearance: "none",
                      MozAppearance: "none",
                      outline: "none",
                      overflow: "hidden",
                    }}
                  >
                    <option value="">Select question</option>
                    {securityQuestions.map((q) => (
                      <option key={q.SecurityQuestionID} value={q.SecurityQuestionID}>
                        {q.SecurityQuestion}
                      </option>
                    ))}
                  </select>
                  <Box
                    position="absolute"
                    right="16px"
                    top="50%"
                    transform="translateY(-50%)"
                    pointerEvents="none"
                    color="gray.400"

                  >
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points="6 9 12 15 18 9" />
                    </svg>
                  </Box>
                </Box>
                {errors.securityQuestion?.message && (
                  <FormErrorMessage>{errors.securityQuestion.message}</FormErrorMessage>
                )}
              </FormControl>

              <FormControl isInvalid={!!errors.securityAnswer}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>Security Answer</FormLabel>
                <Input
                  placeholder="Security Answer"
                  borderRadius="25px"
                  {...register("securityAnswer")}
                />
                {errors.securityAnswer?.message && (
                  <FormErrorMessage>{errors.securityAnswer.message}</FormErrorMessage>
                )}
              </FormControl>

              <Button
                borderRadius="full"
                bgColor="green.700"
                color="white"
                _hover={{ bg: "green.800" }}
                type="submit"
                width="100%"
                loading={signupMutation.isPending}
                height="48px"
              >
                Verify Email
              </Button>

              <Center>
                <Text fontSize="sm">
                  Already Have an Account?{' '}
                  <Link href="/auth/signin" color="red.500" fontWeight={600}>
                    Log In
                  </Link>
                </Text>
              </Center>
            </Stack>
          </Box>
        </Stack>
      </Box>

      {/* Verify Email Modal */}
      <VerifyEmailModal
        isOpen={isVerifyModalOpen}
        onClose={() => setIsVerifyModalOpen(false)}
        email={userEmail}
      />
    </Center>
  );
}
