"use client";
import React, { useState } from "react";
import {
  Box,
  Flex,
  Text,
  Button,
  Stack,
  Table,
  Dialog,
  IconButton,
} from "@chakra-ui/react";
import { MdDelete } from "react-icons/md";
import DynamicForm, { FormSection } from "../ui/DynamicForm";
import {
  qualificationModalConfig,
  qualificationTableConfig,
} from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";
import { useMemo } from "react";

interface Qualification {
  qualificationType: string;
  qualificationName: string;
  boardName?: string;
  universityName?: string;
  boardUniversity?: string; // Keeping for potential legacy usage or fallback

  qualificationTypeLabel?: string;
  qualificationNameLabel?: string;
  boardUniversityLabel?: string;

  resultType: string;
  percentage: string;
  grade?: string;

  passingMonth: string;
  passingYear: string;
  passingMonthYear: string;

  marksObtained?: string;
  marksOutOf?: string;
  cgpa?: string;
  cgpaOutOf?: string;

  seatNo: string;
  prnNo?: string;

  passedAppeared?: string;
}

interface QualificationDetailsProps {
  defaultValues?: { qualifications?: Qualification[] };
  onNext?: () => void;
}

export default function QualificationDetails({
  defaultValues,
  onNext,
  onPrev,
}: QualificationDetailsProps & { onPrev?: () => void }) {
  const [qualifications, setQualifications] = useState<Qualification[]>(
    defaultValues?.qualifications || []
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [selectedQualificationId, setSelectedQualificationId] = useState<number | null>(null);

  // tRPC Hooks
  const utils = trpc.useUtils();
  const { data: fetchedQualifications, isLoading } = trpc.student.getQualificationDetails.useQuery();
  const saveMutation = trpc.student.saveQualificationDetails.useMutation({
    onSuccess: () => {
      utils.student.getQualificationDetails.invalidate();
      onNext?.();
    },
    onError: (error) => {
      alert(`Error saving qualifications: ${error.message}`);
    }
  });

  const { data: masterQualifications } = trpc.master.getQualifications.useQuery();
  const { data: masterPrograms } = trpc.master.getProgramsByQualification.useQuery(
    selectedQualificationId ?? 0,
    { enabled: !!selectedQualificationId }
  );
  const { data: masterBoards } = trpc.master.getBoards.useQuery();
  const { data: masterUniversities } = trpc.master.getUniversities.useQuery();

  // Populate state from fetched data
  React.useEffect(() => {
    if (fetchedQualifications && fetchedQualifications.length > 0) {
      const mapped: Qualification[] = fetchedQualifications.map((q: any) => {
        // Determine if it was a board or university based on which label is present
        // or heuristics if both/neither (though usually only one join matches if IDs don't overlap much, 
        // but IDs validly overlap between tables. ideally we check qualification type. 
        // For now, if boardLabel is set, use it.

        const isBoard = !!q.boardLabel;

        return {
          qualificationType: String(q.qualificationType),
          qualificationTypeLabel: q.qualificationTypeLabel || "",
          qualificationName: String(q.qualificationName),
          qualificationNameLabel: q.qualificationNameLabel || "",
          boardName: isBoard ? String(q.boardUniversity) : undefined,
          universityName: !isBoard ? String(q.boardUniversity) : undefined,
          boardUniversityLabel: q.boardUniversityLabel || "",

          resultType: q.resultType || "",
          percentage: q.percentage ? String(q.percentage) : "",
          grade: q.grade || "",

          passingMonth: q.passingMonth ? String(q.passingMonth) : "",
          passingYear: q.passingYear ? String(q.passingYear) : "",
          passingMonthYear: (q.passingMonth && q.passingYear) ? `${q.passingMonth}-${q.passingYear}` : "",

          marksObtained: q.marksObtained ? String(q.marksObtained) : "",
          marksOutOf: q.marksOutOf ? String(q.marksOutOf) : "",
          cgpa: q.cgpa ? String(q.cgpa) : "",
          cgpaOutOf: q.cgpaOutOf ? String(q.cgpaOutOf) : "",

          seatNo: q.seatNo || "",
          prnNo: q.prnNo || "",

          // Helper for editing
          passedAppeared: q.resultType, // assuming resultType maps to passedAppeared options
        };
      });
      setQualifications(mapped);
    }
  }, [fetchedQualifications]);

  const handleAddQualification = (data: Record<string, any>) => {
    // Resolve Labels for display
    const qualTypeLabel =
      (masterQualifications || []).find((q: any) => String(q.id) === String(data.qualificationType))?.name ||
      data.qualificationType || "";

    const qualNameLabel =
      (masterPrograms || []).find((p: any) => String(p.id) === String(data.qualificationName))?.name ||
      data.qualificationName || "";

    const boardOrUniLabel = data.boardName
      ? (masterBoards || []).find((b: any) => String(b.id) === String(data.boardName))?.name || data.boardName
      : data.universityName
        ? (masterUniversities || []).find((u: any) => String(u.id) === String(data.universityName))?.name || data.universityName
        : "";

    const computedPercentage = data.percentage
      ? String(data.percentage)
      : data.marksObtained && data.marksOutOf
        ? String(Number((Number(data.marksObtained) / Number(data.marksOutOf)) * 100).toFixed(2))
        : "";

    // Construct new Qualification object
    const newQualification: Qualification = {
      qualificationType: data.qualificationType,
      qualificationTypeLabel: qualTypeLabel,
      qualificationName: data.qualificationName,
      qualificationNameLabel: qualNameLabel,
      boardName: data.boardName,
      universityName: data.universityName,
      boardUniversityLabel: boardOrUniLabel,

      resultType: data.resultType || data.passedAppeared || "",
      passedAppeared: data.passedAppeared,
      percentage: computedPercentage,
      grade: data.grade,

      passingMonth: data.passingMonth,
      passingYear: data.passingYear,
      passingMonthYear: (data.passingMonth && data.passingYear) ? `${data.passingMonth}-${data.passingYear}` : "",

      marksObtained: data.marksObtained,
      marksOutOf: data.marksOutOf,
      cgpa: data.cgpaObtained, // Form field is cgpaObtained
      cgpaOutOf: data.cgpaOutOf,
      seatNo: data.seatNo,
      prnNo: data.prnNo,
    };

    if (editingIndex !== null) {
      const updated = [...qualifications];
      updated[editingIndex] = newQualification;
      setQualifications(updated);
      setEditingIndex(null);
    } else {
      setQualifications([...qualifications, newQualification]);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (index: number) => {
    setQualifications(qualifications.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (qualifications.length === 0) {
      alert("Please add at least one qualification");
      return;
    }

    // Map state to API Payload
    const payload = qualifications.map(q => ({
      qualificationType: String(q.qualificationType),
      qualificationName: q.qualificationName ? String(q.qualificationName) : undefined,
      boardUniversity: q.boardName ? String(q.boardName) : q.universityName ? String(q.universityName) : undefined,
      resultType: q.resultType,
      percentage: q.percentage ? String(q.percentage) : undefined,
      grade: q.grade,
      passingMonth: q.passingMonth ? String(q.passingMonth) : undefined,
      passingYear: q.passingYear ? String(q.passingYear) : undefined,
      marksObtained: q.marksObtained ? String(q.marksObtained) : undefined,
      marksOutOf: q.marksOutOf ? String(q.marksOutOf) : undefined,
      cgpa: q.cgpa ? String(q.cgpa) : undefined,
      cgpaOutOf: q.cgpaOutOf ? String(q.cgpaOutOf) : undefined,
      seatNo: q.seatNo,
      prnNo: q.prnNo,
    }));

    saveMutation.mutate(payload);
  };

  return (
    <>
      <Box as="form" onSubmit={handleSubmit} bg="white" borderRadius="lg" p={{ base: 2, md: 4 }} boxShadow="sm">
        <Stack gap={6}>
          {/* Header */}
          <Flex justify="space-between" align="center">
            <Text fontSize="md" fontWeight="600" color="orange.500">
              {qualificationTableConfig.tableName}
            </Text>
            <Button
              size="sm"
              bg="orange.500"
              color="white"
              _hover={{ bg: "orange.600" }}
              disabled={isLoading || saveMutation.isPending}
              onClick={() => {
                setEditingIndex(null);
                setSelectedQualificationId(null);
                setIsModalOpen(true);
              }}
            >
              {qualificationTableConfig.addButtonLabel}
            </Button>
          </Flex>

          {/* Table */}
          {qualifications.length > 0 ? (
            <Box overflowX="auto">
              <Table.Root size="sm" variant="line">
                <Table.Header>
                  <Table.Row bg="gray.50">
                    {qualificationTableConfig.columns.map((col) => (
                      <Table.ColumnHeader
                        key={col.key}
                        fontSize="sm"
                        fontWeight={600}
                        color="gray.700"
                        width={col.width}
                      >
                        {col.label}
                      </Table.ColumnHeader>
                    ))}
                  </Table.Row>
                </Table.Header>
                <Table.Body>
                  {qualifications.map((qual, index) => (
                    <Table.Row key={index}>
                      <Table.Cell>{index + 1}</Table.Cell>
                      <Table.Cell>{qual.qualificationTypeLabel || qual.qualificationType}</Table.Cell>
                      <Table.Cell>{qual.qualificationNameLabel || qual.qualificationName}</Table.Cell>
                      <Table.Cell>{qual.boardUniversityLabel || "-"}</Table.Cell>
                      <Table.Cell>{qual.resultType}</Table.Cell>
                      <Table.Cell>{qual.percentage ? `${qual.percentage}%` : qual.grade || "-"}</Table.Cell>
                      <Table.Cell>{qual.passingMonthYear}</Table.Cell>
                      <Table.Cell>
                        <Flex gap={2}>
                          <IconButton
                            size="xs"
                            variant="ghost"
                            colorPalette="blue"
                            onClick={() => {
                              setEditingIndex(index);
                              setSelectedQualificationId(Number(qual.qualificationType));
                              setIsModalOpen(true);
                            }}
                            aria-label="Edit qualification"
                          >
                            <Box as="span" fontSize="xs">Edit</Box>
                          </IconButton>
                          <IconButton
                            size="xs"
                            variant="ghost"
                            colorPalette="red"
                            onClick={() => handleDelete(index)}
                            aria-label="Delete qualification"
                          >
                            <MdDelete size={16} />
                          </IconButton>
                        </Flex>
                      </Table.Cell>
                    </Table.Row>
                  ))}
                </Table.Body>
              </Table.Root>
            </Box>
          ) : (
            <Box
              p={8}
              textAlign="center"
              borderWidth="1px"
              borderStyle="dashed"
              borderColor="gray.300"
              borderRadius="md"
            >
              <Text color="gray.500" fontSize="sm">
                {isLoading ? "Loading qualifications..." : qualificationTableConfig.emptyMessage}
              </Text>
            </Box>
          )}

          {/* Footer Buttons */}
          <Box borderTop="1px solid" borderColor="gray.200" pt={6} mt={2}>
            <Flex justify="space-between" align="center">
              <Button
                variant="outline"
                size="md"
                borderColor="gray.300"
                color="gray.700"
                onClick={() => onPrev?.()}
              >
                Previous
              </Button>
              <Button
                type="submit"
                size="md"
                bg="black"
                color="white"
                loading={saveMutation.isPending}
                _hover={{ bg: "gray.800" }}
              >
                Save & Next
              </Button>
            </Flex>
          </Box>
        </Stack>
      </Box>

      {/* Add/Edit Qualification Modal */}
      <Dialog.Root
        open={isModalOpen}
        onOpenChange={(details: any) => setIsModalOpen(!!details?.open)}
        placement="center"
        size="xl"
      >
        <Dialog.Backdrop />
        <Dialog.Positioner>
          <Dialog.Content>
            <Dialog.Header>
              <Dialog.Title>
                {editingIndex !== null ? "Edit Qualification" : "Add Qualification"}
              </Dialog.Title>
              <Dialog.CloseTrigger />
            </Dialog.Header>
            <Dialog.Body>
              <DynamicForm
                sections={useMemo(() => {
                  return qualificationModalConfig.map((section: FormSection) => ({
                    ...section,
                    fields: section.fields.map((f) => {
                      if (f.name === 'qualificationType') {
                        return {
                          ...f,
                          options: (masterQualifications || []).map((q: any) => ({ value: String(q.id), label: q.name })),
                        };
                      }
                      if (f.name === 'qualificationName') {
                        return {
                          ...f,
                          options: (masterPrograms || []).map((p: any) => ({ value: String(p.id), label: p.name })),
                        };
                      }
                      if (f.name === 'boardName') {
                        return {
                          ...f,
                          options: (masterBoards || []).map((b: any) => ({ value: String(b.id), label: b.name })),
                        };
                      }
                      if (f.name === 'universityName') {
                        return {
                          ...f,
                          options: (masterUniversities || []).map((u: any) => ({ value: String(u.id), label: u.name })),
                        };
                      }
                      return f;
                    })
                  }));
                }, [masterQualifications, masterPrograms, masterBoards, masterUniversities])}
                onSubmit={handleAddQualification}
                submitButtonText={editingIndex !== null ? "Update Qualification" : "Add Qualification"}
                cancelButtonText="Cancel"
                showPreviousButton={false}
                onChange={(name, value, setValue, getValues) => {
                  if (name === 'qualificationType') {
                    const num = Number(value) || null;
                    setSelectedQualificationId(num);
                    // only clear if changing triggers (avoid clearing on initial load if possible, though DynamicForm might trigger this)
                  }

                  // Calculate percentage dynamically when marks change
                  if (name === 'marksObtained' || name === 'marksOutOf') {
                    const values = getValues ? getValues() : {};
                    const obtainedRaw = name === 'marksObtained' ? value : values.marksObtained;
                    const outOfRaw = name === 'marksOutOf' ? value : values.marksOutOf;
                    const obtained = Number(obtainedRaw);
                    const outOf = Number(outOfRaw);
                    if (!isNaN(obtained) && !isNaN(outOf) && outOf > 0) {
                      const perc = (obtained / outOf) * 100;
                      const formatted = Number.isFinite(perc) ? String(Number(perc.toFixed(2))) : "";
                      setValue?.('percentage', formatted);
                    } else {
                      setValue?.('percentage', '');
                    }
                  }

                  if (name === 'markingSystem' && value === 'Grade') {
                    setValue?.('percentage', '');
                  }
                }}
                defaultValues={
                  editingIndex !== null ? qualifications[editingIndex] : undefined
                }
              />
            </Dialog.Body>
          </Dialog.Content>
        </Dialog.Positioner>
      </Dialog.Root>
    </>
  );
}
