"use client";

import { useEffect, useState } from "react";
import DynamicForm from "../ui/DynamicForm";
import { personalDetailsConfig } from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../ui/toaster";
import { useCurrentUser } from "@/hooks/useCurrentUser";

export default function PersonalDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [initialValues, setInitialValues] = useState<Record<string, any>>({});
  const [formKey, setFormKey] = useState(0);
  const utils = trpc.useUtils();
  const { user } = useCurrentUser();

  // Fetch existing personal details from database
  const { data: existingData, isLoading } = trpc.student.getPersonalDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  console.log("Existing personal details:", existingData);

  // Save personal details mutation
  const savePersonalDetails = trpc.student.savePersonalDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Personal details saved successfully",
        type: "success",
        duration: 3000,
      });
      // Refetch personal details and profile status
      utils.student.getPersonalDetails.invalidate();
      utils.student.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save personal details",
        type: "error",
        duration: 5000,
      });
    },
  });

  useEffect(() => {
    if (existingData || user?.email) {
      const mappedData = {
        firstName: existingData?.FirstName || "",
        middleName: existingData?.MiddleName || "",
        lastName: existingData?.LastName || "",
        fullName: existingData?.FullName || "",
        gender: existingData?.Gender || "",
        dob: existingData?.DOB || "",
        bloodGroup: existingData?.BloodGroup || "",
        fatherName: existingData?.FatherName || "",
        fatherOccupation: existingData?.FatherOccupation || "",
        motherName: existingData?.MotherName || "",
        motherOccupation: existingData?.MotherOccupation || "",
        annualIncome: existingData?.AnnualIncome || "",
        motherTongue: existingData?.MotherTongue || "",
        aadharNumber: existingData?.AadharNo || "",
        abcId: existingData?.ABCID || "",
        emailAddress: existingData?.EmailID || user?.email || "",
        mobileNumber: existingData?.MobileNo || "",
        whatsappNumber: existingData?.WhatappMobileNo || "",
      };
      setInitialValues(mappedData);
      // Force form re-initialization with new data
      setFormKey(prev => prev + 1);
    }
  }, [existingData, user?.email]);

  const handleSubmit = (data: Record<string, any>) => {
    savePersonalDetails.mutate({
      firstName: data.firstName,
      middleName: data.middleName,
      lastName: data.lastName,
      fullName: data.fullName,
      gender: data.gender,
      dob: data.dob,
      bloodGroup: data.bloodGroup,
      fatherName: data.fatherName,
      fatherOccupation: data.fatherOccupation,
      motherName: data.motherName,
      motherOccupation: data.motherOccupation,
      annualIncome: data.annualIncome,
      motherTongue: data.motherTongue,
      aadharNumber: data.aadharNumber,
      abcId: data.abcId,
      emailAddress: data.emailAddress,
      mobileNumber: data.mobileNumber,
      whatsappNumber: data.whatsappNumber,
    });
  };

  // Show loading state while fetching data or waiting for user session
  if (isLoading || !user) {
    return <div>Loading...</div>;
  }

  return (
    <DynamicForm
      key={formKey}
      sections={personalDetailsConfig}
      onSubmit={handleSubmit}
      defaultValues={initialValues}
      submitButtonText="Save & Next"
      isSubmitting={savePersonalDetails.isPending}
      previousButton={{
        label: "Cancel",
        onClick: () => {
          if (onPrev) {
            onPrev();
          } else {
            window.location.href = "/dashboard";
          }
        },
      }}
    />
  );
}
