"use client";

import {
  Box,
  Text,
  Stack,
  Grid,
  Flex,
  Button,
  Image,
  Link,
  VStack,
  HStack,
  Skeleton,
  SkeletonCircle,
  SkeletonText,
} from "@chakra-ui/react";
import React from "react";
import { MdOutlinePrint } from "react-icons/md";
import { useRouter } from "next/navigation";
import { trpc } from "@/lib/trpc";
export default function ProfileSummary({
  data,
  onEditSection,
  title,
  showPrint = true,
}: {
  data: any; // full profile data from DB or context
  onEditSection?: (section: string) => void;
  title?: string;
  showPrint?: boolean;
}) {
  const [profile, setProfile] = React.useState<any>(data || null);
  const router = useRouter();
  const printRef = React.useRef<HTMLDivElement | null>(null);

  const navigateToSection = (section: string) => {
    const sectionRoutes: Record<string, string> = {
      personal: "/dashboard/apply#personal",
      address: "/dashboard/apply#address",
      contact: "/dashboard/apply#personal",
      qualification: "/dashboard/apply#qualification",
      reservation: "/dashboard/apply#reservation",
      photo: "/dashboard/apply#photo",
      bank: "/dashboard/apply#bank",
      documents: "/dashboard/apply#documents",
    };

    // prefer parent handler, otherwise push route directly
    if (onEditSection) {
      onEditSection(section);
      return;
    }

    const route = sectionRoutes[section];
    if (route) router.push(route);
  };

  // Always fetch the latest pieces from API and merge with passed `data` (if any)
  const { data: personalData, isLoading: personalLoading } = trpc.student.getPersonalDetails.useQuery(undefined);
  const { data: addressData, isLoading: addressLoading } = trpc.student.getAddressDetails.useQuery(undefined);
  const { data: bankData, isLoading: bankLoading } = trpc.student.getBankDetails.useQuery(undefined);
  // Safely call reservation query if it exists on the router; fallback to alternative names or undefined.
  const reservationQuery: any =
    (trpc.student as any).getReservationDetails?.useQuery?.(undefined, { onError: () => { }, retry: false }) ??
    (trpc.student as any).getReservation?.useQuery?.(undefined, { onError: () => { }, retry: false }) ??
    null;
  const reservationData = reservationQuery?.data;
  const reservationLoading = reservationQuery?.isLoading ?? false;
  const { data: photoSignData, isLoading: photoLoading } = trpc.student.getPhotoSignDetails.useQuery(undefined);
  const { data: qualificationData, isLoading: qualificationLoading } = trpc.student.getQualificationDetails.useQuery(undefined);
  const { data: masterDocs, isLoading: masterDocsLoading } = trpc.master.getDocuments.useQuery();
  const { data: uploadDocs, isLoading: uploadDocsLoading } = trpc.student.getRequiredDocuments.useQuery();

  const isAnyLoading = !!(personalLoading || addressLoading || bankLoading || reservationLoading || photoLoading || qualificationLoading || masterDocsLoading || uploadDocsLoading);

  React.useEffect(() => {
    // Merge Documents
    let finalDocuments: any[] = [];
    if (masterDocs) {
      finalDocuments = masterDocs.map(md => {
        const uploaded = uploadDocs?.find(ud => ud.documentId === md.id);
        return {
          name: md.name,
          isRequired: md.isRequired,
          isUploaded: !!uploaded?.isUploaded,
          url: uploaded?.docUrl,
          uploadedOn: uploaded?.uploadedOn ? new Date(uploaded.uploadedOn).toLocaleDateString() : '-',
        };
      });
    } else if (data?.documents) {
      finalDocuments = data.documents;
    }

    // Build mapped profile using API values when available, fall back to `data` prop
    const mapped = {
      personal: {
        firstName: personalData?.FirstName ?? data?.personal?.firstName ?? "",
        middleName: personalData?.MiddleName ?? data?.personal?.middleName ?? "",
        lastName: personalData?.LastName ?? data?.personal?.lastName ?? "",
        FullName: personalData?.FullName ?? data?.personal?.FullName ?? data?.personal?.fullName ?? "",
        gender: personalData?.Gender ?? data?.personal?.gender ?? "",
        dob: personalData?.DOB ?? data?.personal?.dob ?? "",
        bloodGroup: personalData?.BloodGroup ?? data?.personal?.bloodGroup ?? "",
        fatherName: personalData?.FatherName ?? data?.personal?.fatherName ?? "",
        motherName: personalData?.MotherName ?? data?.personal?.motherName ?? "",
        email: personalData?.EmailID ?? data?.personal?.email ?? "",
        mobile: personalData?.MobileNo ?? data?.personal?.mobile ?? "",
        whatsapp: personalData?.WhatappMobileNo ?? data?.personal?.whatsapp ?? "",
        aadhar: personalData?.AadharNo ?? data?.personal?.aadhar ?? "",
        ABCID: personalData?.ABCID ?? data?.personal?.ABCID ?? "",
        fatherOccupation: personalData?.FatherOccupation ?? data?.personal?.fatherOccupation ?? "",
        motherOccupation: personalData?.MotherOccupation ?? data?.personal?.motherOccupation ?? "",
        motherTongue: personalData?.MotherTongue ?? data?.personal?.motherTongue ?? "",
      },
      address: {
        current: {
          nationality: addressData?.Nationality ?? data?.address?.current?.nationality ?? "",
          address1: addressData?.Address1 ?? data?.address?.current?.address1 ?? "",
          address2: addressData?.Address2 ?? data?.address?.current?.address2 ?? "",
          village: addressData?.VillageCity ?? data?.address?.current?.village ?? "",
          district: addressData?.DistrictName ?? addressData?.DistrictID ?? data?.address?.current?.district ?? "",
          state: addressData?.StateName ?? addressData?.StateID ?? data?.address?.current?.state ?? "",
          country: addressData?.Country ?? data?.address?.current?.country ?? "",
          pincode: addressData?.PinCode ?? data?.address?.current?.pincode ?? "",
          tehsil: addressData?.TalukaName ?? addressData?.TalukaID ?? data?.address?.current?.tehsil ?? "",
        },
        permanent: {
          address1: addressData?.PAddress1 ?? data?.address?.permanent?.address1 ?? "",
          address2: addressData?.PAddress2 ?? data?.address?.permanent?.address2 ?? "",
          village: addressData?.PSVillage ?? data?.address?.permanent?.village ?? "",
          district: addressData?.PSDistrictName ?? addressData?.PSDistrictID ?? data?.address?.permanent?.district ?? "",
          tehsil: addressData?.PSTalukaName ?? addressData?.PSTalukaID ?? data?.address?.permanent?.tehsil ?? "",
          state: addressData?.PSStateName ?? addressData?.PSStateID ?? data?.address?.permanent?.state ?? "",
          country: addressData?.PSCountry ?? data?.address?.permanent?.country ?? "",
          pincode: addressData?.PPinCode ?? data?.address?.permanent?.pincode ?? "",
        },
      },
      reservation: {
        domicileState: reservationData?.DomicileStateName ?? reservationData?.DomicileState ?? data?.reservation?.domicileState ?? data?.reservation?.domicile ?? "",
        category: reservationData?.CategoryName ?? reservationData?.Category ?? data?.reservation?.category ?? "",
        religion: reservationData?.ReligionName ?? reservationData?.Religion ?? data?.reservation?.religion ?? "",
        caste: reservationData?.Caste ?? data?.reservation?.caste ?? "",
        haveCasteCertificate: reservationData?.HaveCasteCertificate ?? data?.reservation?.haveCasteCertificate ?? reservationData?.HaveCasteCert ?? data?.reservation?.haveCasteCert ?? "",
        haveNCLCertificate: reservationData?.HaveNCLCertificate ?? data?.reservation?.haveNCLCertificate ?? "",
        haveEWSCertificate: reservationData?.HaveEWSCertificate ?? data?.reservation?.haveEWSCertificate ?? "",
        haveCasteValidity: reservationData?.HaveCasteValidity ?? data?.reservation?.haveCasteValidity ?? "",
        haveCasteValidityReceipt: reservationData?.HaveCasteValidityReceipt ?? data?.reservation?.haveCasteValidityReceipt ?? "",
        previousCategory: reservationData?.CategoryName ?? reservationData?.PreviousCategory ?? data?.reservation?.previousCategory ?? "",
        areOrphan: reservationData?.AreOrphan ?? data?.reservation?.areOrphan ?? data?.reservation?.isOrphan ?? "",
        physicallyDisabled: reservationData?.PhysicallyDisabled ?? data?.reservation?.physicallyDisabled ?? "",
        disabilityDetails: reservationData?.DisabilityDetails ?? data?.reservation?.disabilityDetails ?? "",
        defensePersonnel: reservationData?.DefensePersonnel ?? data?.reservation?.defensePersonnel ?? "",
        freedomFighter: reservationData?.FreedomFighter ?? data?.reservation?.freedomFighter ?? "",
        governmentProject: reservationData?.GovernmentProject ?? data?.reservation?.governmentProject ?? "",
        IsSports: reservationData?.IsSports ?? data?.reservation?.IsSports ?? "",
        sportsDetails: reservationData?.SportsDetails ?? data?.reservation?.sportsDetails ?? "",
        nccStudent: reservationData?.NCCStudent ?? data?.reservation?.nccStudent ?? "",
        nssMember: reservationData?.NSSMember ?? data?.reservation?.nssMember ?? "",
        agricultureFamily: reservationData?.AgricultureFamily ?? data?.reservation?.agricultureFamily ?? "",
        minorityCommunity: reservationData?.ReligiousMinorityName ?? reservationData?.MinorityCommunity ?? data?.reservation?.minorityCommunity ?? "",
        isReligiousMinorityYes: reservationData?.IsReligiousMinorityYes ?? data?.reservation?.isReligiousMinorityYes ?? "",
        religiousMinority: reservationData?.ReligiousMinorityName ?? reservationData?.ReligiousMinority ?? data?.reservation?.religiousMinority ?? "",
        linguisticMinority: reservationData?.LinguisticMinority ?? data?.reservation?.linguisticMinority ?? "",
      },
      qualification: qualificationData?.map(q => ({
        ...q,
        qualificationType: q.qualificationTypeLabel, // Overwrite ID with Label for display
        boardUniversity: q.boardUniversityLabel, // Use constructed label
        qualificationName: q.qualificationNameLabel, // Use ProgramName
        percentage: q.percentage,
        marksObtained: q.marksObtained,
        resultType: q.resultType,
      })) ?? data?.qualification ?? [],
      bank: {
        bankName: bankData?.BankName ?? data?.bank?.bankName ?? "",
        accountHolderName: bankData?.HolderName ?? data?.bank?.accountHolderName ?? "",
        branchName: bankData?.BranchName ?? data?.bank?.branchName ?? "",
        ifsc: bankData?.IFSCCode ?? data?.bank?.ifsc ?? "",
        accountNumber: bankData?.AccountNo ?? data?.bank?.accountNumber ?? "",
      },
      photo: photoSignData?.PhotoURL ?? data?.photo ?? null,
      signature: photoSignData?.SignURL ?? data?.signature ?? null,
      documents: finalDocuments,
    };

    setProfile(mapped);
  }, [data, personalData, addressData, bankData, reservationData, photoSignData, qualificationData, masterDocs, uploadDocs]);

  const {
    personal = {},
    address = { current: {}, permanent: {} },
    reservation = {},
    qualification = [],
    bank = {},
    photo,
    signature,
    documents = [],
  } = profile || data || {};

  return (
    <Box mx="auto" p={4} ref={printRef}>
      <Stack gap={6}>
        <Flex justify="space-between">
          <Text fontSize="xl" fontWeight={700} color={"orange.500"}>
            {title ?? "Profile Summary"}
          </Text>

          {showPrint && (
            <Button colorPalette="brand" size="sm" bg={"#327245"} onClick={() => {
              // open a print-friendly window with the profile content — wider so md+ layouts stay multi-column
              const el = printRef.current;
              if (!el) return;
              const printWindow = window.open('', '_blank', 'width=1400,height=900');
              if (!printWindow) {
                window.print();
                return;
              }

              // clone head styles
              const headHtml = document.head.innerHTML;

              printWindow.document.open();
              printWindow.document.write(`<!doctype html><html><head>${headHtml}</head><body></body></html>`);
              printWindow.document.close();

              // inject content inside a wrapper to control print width
              const container = printWindow.document.body;
              container.innerHTML = `<div class="du-print-wrapper">${el.innerHTML}</div>`;

              // add print-specific styles to keep multi-column layout
              const style = printWindow.document.createElement('style');
              style.innerHTML = `
                .du-print-wrapper { width: 1200px; margin: 0 auto; box-sizing: border-box; padding: 20px; }
                @media print { .du-print-wrapper { width: 1200px; padding: 20px; } }
                @media print { @page { size: A4; margin: 20mm; } }
                /* Hide interactive controls in print */
                .du-print-wrapper button, .du-print-wrapper .no-print, .du-print-wrapper [data-no-print] { display: none !important; }
                /* Personal section: keep main 2fr/1fr split and inner fields 2 columns */
                .du-print-wrapper .personal-grid { display: grid !important; grid-template-columns: 2fr 1fr !important; gap: 24px !important; }
                .du-print-wrapper .personal-fields-grid { display: grid !important; grid-template-columns: repeat(2, 1fr) !important; gap: 16px !important; }
                .du-print-wrapper .personal-grid > div:last-child { display: block !important; }
                /* Reservation & Bank: force 3 columns */
                .du-print-wrapper .reservation-grid { display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 16px !important; }
                .du-print-wrapper .bank-grid { display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 16px !important; }
                /* Qualification: keep card layout and inner 3-column grid */
                .du-print-wrapper .qualification-list { display: block !important; }
                .du-print-wrapper .qualification-item { display: block !important; page-break-inside: avoid; }
                .du-print-wrapper .qualification-grid { display: grid !important; grid-template-columns: repeat(3, 1fr) !important; gap: 16px !important; }
                .du-print-wrapper .qualification-item > div { -webkit-print-color-adjust: exact; }
                /* ensure Chakra stacks/grids keep spacing */
                .du-print-wrapper .chakra-stack, .du-print-wrapper .chakra-grid { gap: 12px !important; }
              `;
              printWindow.document.head.appendChild(style);

              // add meta viewport to ensure responsive CSS evaluates against wide width
              const meta = printWindow.document.createElement('meta');
              meta.name = 'viewport';
              meta.content = 'width=1200';
              printWindow.document.head.appendChild(meta);

              // add script to tweak layout before printing (targets the personal grids)
              const script = printWindow.document.createElement('script');
              script.type = 'text/javascript';
              script.innerHTML = `
                (function(){
                  function fixPersonal(){
                    try{
                      const pg = document.querySelector('.du-print-wrapper .personal-grid');
                      if(pg){ pg.style.setProperty('grid-template-columns','2fr 1fr','important'); pg.style.setProperty('gap','24px','important'); }
                      const pfg = document.querySelector('.du-print-wrapper .personal-fields-grid');
                      if(pfg){ pfg.style.setProperty('grid-template-columns','repeat(2,1fr)','important'); pfg.style.setProperty('gap','16px','important'); }

                      const rg = document.querySelector('.du-print-wrapper .reservation-grid');
                      if(rg){ rg.style.setProperty('grid-template-columns','repeat(3,1fr)','important'); rg.style.setProperty('gap','16px','important'); }
                      const bg = document.querySelector('.du-print-wrapper .bank-grid');
                      if(bg){ bg.style.setProperty('grid-template-columns','repeat(3,1fr)','important'); bg.style.setProperty('gap','16px','important'); }

                      const qg = document.querySelectorAll('.du-print-wrapper .qualification-grid');
                      qg.forEach(el => { el.style.setProperty('grid-template-columns','repeat(3,1fr)','important'); el.style.setProperty('gap','16px','important'); });
                      const qi = document.querySelectorAll('.du-print-wrapper .qualification-item');
                      qi.forEach(el => { el.style.setProperty('display','block','important'); el.style.setProperty('page-break-inside','avoid','important'); });
                    }catch(e){console.error(e);}                
                  }
                  fixPersonal();
                  window.addEventListener('load', fixPersonal);
                  setTimeout(fixPersonal, 300);
                  setTimeout(fixPersonal, 800);
                })();
              `;
              printWindow.document.head.appendChild(script);

              // ensure window is large enough and body has minimum width
              try { printWindow.resizeTo(1400, 900); } catch (e) { }
              printWindow.document.body.style.minWidth = '1200px';

              // wait for images/fonts to load before printing
              setTimeout(() => {
                printWindow.focus();
                printWindow.print();
                // close after a short delay to avoid interrupting save dialog
                setTimeout(() => printWindow.close(), 600);
              }, 900);
            }}>
              <MdOutlinePrint /> Print
            </Button>
          )}
        </Flex>

        {/* ------------------------ PERSONAL ------------------------ */}
        <Box border="1px solid" borderColor="gray.200" borderRadius="md" p={4}>
          <Flex justify="space-between" align="center" mb={4}>
            <Text fontSize="lg" fontWeight={700} color={"green.600"}>
              Personal Details
            </Text>
            <Button size="sm" onClick={() => onEditSection?.("personal")}>
              Edit
            </Button>
          </Flex>

          {/* Layout: left = personal fields, right = photo & signature (as in the provided image) */}
          <Grid className="personal-grid" templateColumns={{ base: "1fr", md: "2fr 1fr" }} gap={6}>
            <Box>
              <Grid className="personal-fields-grid" templateColumns={{ base: "1fr", md: "repeat(2,1fr)" }} gap={4}>
                <Field label="Full Name" value={`${personal?.FullName || ''}`} loading={isAnyLoading} />
                <Field label="Date of Birth" value={personal?.dob} loading={isAnyLoading} />
                <Field label="Gender" value={personal?.gender} loading={isAnyLoading} />
                <Field label="Blood Group" value={personal?.bloodGroup} loading={isAnyLoading} />
                <Field label="Father's Name" value={personal?.fatherName} loading={isAnyLoading} />
                <Field label="Father’s Occupation:" value={personal?.fatherOccupation} loading={isAnyLoading} />
                <Field label="Mother's Name" value={personal?.motherName} loading={isAnyLoading} />
                <Field label="Mother’s Occupation:" value={personal?.motherOccupation} loading={isAnyLoading} />
                <Field label="Mother Tongue:" value={personal?.motherTongue} loading={isAnyLoading} />
                <Field label="Aadhar Number:" value={personal?.aadhar} loading={isAnyLoading} />
                <Field label="ABCID Number:" value={personal?.ABCID} loading={isAnyLoading} />
                <Field label="Email" value={personal?.email} loading={isAnyLoading} />
                <Field label="Mobile" value={personal?.mobile} loading={isAnyLoading} />
                <Field label="WhatsApp" value={personal?.whatsapp} loading={isAnyLoading} />
              </Grid>
            </Box>

            <Box>
              <Text mb={2}>Photo</Text>
              {isAnyLoading ? (
                <Skeleton height="120px" mb={4} />
              ) : photo ? (
                <Image
                  src={typeof photo === 'string' ? photo : (photo?.url ?? (photo instanceof File ? URL.createObjectURL(photo) : '/placeholder.png'))}
                  alt="Photo"
                  maxH="120px"
                  borderRadius="md"
                  objectFit="contain"
                  mb={4}
                />
              ) : (
                <Text color="gray.500">No photo uploaded</Text>
              )}

              <Text mb={2} mt={4}>Signature</Text>
              {isAnyLoading ? (
                <Skeleton height="80px" />
              ) : signature ? (
                <Image
                  src={typeof signature === 'string' ? signature : (signature?.url ?? (signature instanceof File ? URL.createObjectURL(signature) : '/placeholder.png'))}
                  alt="Signature"
                  maxH="80px"
                  borderRadius="md"
                  objectFit="contain"
                />
              ) : (
                <Text color="gray.500">No signature uploaded</Text>
              )}
            </Box>
          </Grid>
        </Box>

        {/* ------------------------ ADDRESS ------------------------ */}
        <Box border="1px solid" borderColor="gray.200" borderRadius="md" p={4}>
          <Flex justify="space-between" align="center" mb={4}>
            <Text fontSize="lg" fontWeight={700} color={"green.600"}>
              Address Details
            </Text>
            <Button size="sm" onClick={() => onEditSection?.("address")}>
              Edit
            </Button>
          </Flex>
          <Stack gap={4}>
            <Box>
              <Text fontWeight={700} mb={2} color={"orange.500"}>Current Address</Text>
              <Box as="hr" my={2} />
              <Grid templateColumns="repeat(3,1fr)" gap={4}>
                <Field label="Nationality" value={address?.current?.nationality} loading={isAnyLoading} />
                <Field label="Country:" value={address?.current?.country} loading={isAnyLoading} />
                <Field label="State" value={address?.current?.state} loading={isAnyLoading} />
                <Field label="District" value={address?.current?.district} loading={isAnyLoading} />
                <Field label="Tehsil:" value={address?.current?.tehsil} loading={isAnyLoading} />
                <Field label="Address 1" value={address?.current?.address1} loading={isAnyLoading} />
                <Field label="Address 2" value={address?.current?.address2} loading={isAnyLoading} />
                <Field label="Village/City" value={address?.current?.village} loading={isAnyLoading} />
                <Field label="Pincode" value={address?.current?.pincode} loading={isAnyLoading} />
              </Grid>
            </Box>

            <Box marginTop={4}>
              <Text fontWeight={700} mb={2} color={"orange.500"}>Permanent Address</Text>
              <Box as="hr" my={2} />
              {address?.isPermanentSameAsCurrent ? (
                <Text>Same as Current Address</Text>
              ) : (
                <Grid templateColumns="repeat(3,1fr)" gap={4}>
                  <Field label="Country:" value={address?.permanent?.country} loading={isAnyLoading} />
                  <Field label="State" value={address?.permanent?.state} loading={isAnyLoading} />
                  <Field label="District" value={address?.permanent?.district} loading={isAnyLoading} />
                  <Field label="Tehsil:" value={address?.permanent?.tehsil} loading={isAnyLoading} />
                  <Field label="Address 1" value={address?.permanent?.address1} loading={isAnyLoading} />
                  <Field label="Address 2" value={address?.permanent?.address2} loading={isAnyLoading} />
                  <Field label="Village/City" value={address?.permanent?.village} loading={isAnyLoading} />
                  <Field label="Pincode" value={address?.permanent?.pincode} loading={isAnyLoading} />
                </Grid>
              )}
            </Box>
          </Stack>
        </Box>

        {/* ------------------------ RESERVATION ------------------------ */}
        <Box border="1px solid" borderColor="gray.200" borderRadius="md" p={4}>
          <Flex justify="space-between" align="center" mb={4}>
            <Text fontSize="lg" fontWeight={700} color={"green.600"}>Reservation Details</Text>
            <Button size="sm" onClick={() => onEditSection?.("reservation")}>Edit</Button>
          </Flex>
          <Grid className="reservation-grid" templateColumns={{ base: "1fr", md: "repeat(3,1fr)" }} gap={4}>
            <Field label="Domicile State" value={reservation?.domicileState ?? reservation?.domicile ?? '-'} loading={isAnyLoading} />
            <Field label="Category" value={reservation?.category ?? '-'} loading={isAnyLoading} />
            <Field label="Religion" value={reservation?.religion ?? '-'} loading={isAnyLoading} />
            <Field label="Caste" value={reservation?.caste ?? '-'} loading={isAnyLoading} />
            <Field label="Have Caste Certificate" value={reservation?.haveCasteCertificate ?? reservation?.haveCasteCert ?? '-'} loading={isAnyLoading} />
            <Field label="Have NCL Certificate" value={reservation?.haveNCLCertificate ?? '-'} loading={isAnyLoading} />
            <Field label="Have EWS Certificate" value={reservation?.haveEWSCertificate ?? '-'} loading={isAnyLoading} />
            <Field label="Have Caste Validity" value={reservation?.haveCasteValidity ?? '-'} loading={isAnyLoading} />
            <Field label="Have Caste Validity Receipt" value={reservation?.haveCasteValidityReceipt ?? '-'} loading={isAnyLoading} />
            <Field label="Previous Category" value={reservation?.previousCategory ?? '-'} loading={isAnyLoading} />
            <Field label="Are Orphan" value={reservation?.areOrphan ?? reservation?.isOrphan ?? '-'} loading={isAnyLoading} />
            <Field label="Physically Disabled" value={reservation?.physicallyDisabled ?? '-'} loading={isAnyLoading} />
            <Field label="Disability Details" value={reservation?.disabilityDetails ?? '-'} loading={isAnyLoading} />
            <Field label="Defense Personnel" value={reservation?.defensePersonnel ?? '-'} loading={isAnyLoading} />
            <Field label="Freedom Fighter" value={reservation?.freedomFighter ?? '-'} loading={isAnyLoading} />
            <Field label="Government Project" value={reservation?.governmentProject ?? '-'} loading={isAnyLoading} />
            <Field label="Sports Category" value={reservation?.IsSports ?? '-'} loading={isAnyLoading} />
            <Field label="Sports Details" value={reservation?.sportsDetails ?? '-'} loading={isAnyLoading} />
            <Field label="NCC Student" value={reservation?.nccStudent ?? '-'} loading={isAnyLoading} />
            <Field label="NSS Member" value={reservation?.nssMember ?? '-'} loading={isAnyLoading} />
            <Field label="Agriculture Family" value={reservation?.agricultureFamily ?? '-'} loading={isAnyLoading} />
            <Field label="Minority Community" value={reservation?.minorityCommunity ?? '-'} loading={isAnyLoading} />
            <Field label="Religious Minority" value={reservation?.religiousMinority ?? '-'} loading={isAnyLoading} />
            <Field label="Linguistic Minority" value={reservation?.linguisticMinority ?? '-'} loading={isAnyLoading} />
          </Grid>
        </Box>

        {/* ------------------------ QUALIFICATION ------------------------ */}
        <Box border="1px solid" borderColor="gray.200" borderRadius="md" p={4}>
          <Flex justify="space-between" align="center" mb={4}>
            <Text fontSize="lg" fontWeight={700} color={"green.600"}>Qualification Details</Text>
            <Button size="sm" onClick={() => onEditSection?.("qualification")}>Edit</Button>
          </Flex>

          <VStack className="qualification-list" gap={4} align="stretch">
            {(qualification || []).map((q: any, i: number) => {
              const institute = q?.boardUniversity ?? q?.boardUniversityLabel ?? q?.universityName ?? q?.institute ?? q?.college ?? q?.qualificationName ?? q?.qualificationType ?? '-';
              const passing = q?.passingMonthYear ?? (q?.passingMonth ? `${q?.passingMonth} ${q?.passingYear ?? ''}` : q?.passingYear ?? '-');
              const prn = q?.PRNNumber ?? q?.prnRegistrationNumber ?? q?.PRN ?? '-';
              return (
                <Box key={i} className="qualification-item" borderTopWidth={i === 0 ? 0 : '1px'} borderTopColor="gray.200" pt={i === 0 ? 0 : 3} pb={3}>
                  <Flex justify="space-between" align="flex-start">
                    <Box>
                      <Text fontWeight={700}>{institute}</Text>
                      <Text fontSize="sm" color="gray.600">{passing}</Text>
                    </Box>


                  </Flex>

                  <Grid className="qualification-grid" templateColumns={{ base: '1fr', md: 'repeat(3,1fr)' }} gap={4} mt={3}>
                    <Box>
                      <Text fontSize="xs" color="gray.600">Qualification Name</Text>
                      <Text fontWeight={600}>{q?.qualificationName ?? q?.name ?? '-'}</Text>
                    </Box>

                    <Box>
                      <Text fontSize="xs" color="gray.600">Qualification Type</Text>
                      <Text fontWeight={600}>{q?.qualificationType ?? q?.type ?? '-'}</Text>
                    </Box>
                    <Box >
                      <Text fontSize="xs" color="gray.600">PRN / Registration Number</Text>
                      <Text fontWeight={600}>{prn}</Text>
                    </Box>
                    <Box>
                      <Text fontSize="xs" color="gray.600">Course Status</Text>
                      <Text fontWeight={600}>{q?.passedAppeared ?? q?.courseStatus ?? '-'}</Text>
                    </Box>

                    <Box>
                      <Text fontSize="xs" color="gray.600">Final Marks / Grade</Text>
                      <Text fontWeight={600}>{q?.finalMarks ?? q?.marksObtained ?? q?.percentage ?? q?.grade ?? '-'}</Text>
                    </Box>

                    <Box>
                      <Text fontSize="xs" color="gray.600">Marking System</Text>
                      <Text fontWeight={600}>{q?.markingSystem ?? '-'}</Text>
                    </Box>

                    <Box>
                      <Text fontSize="xs" color="gray.600">CGPA</Text>
                      <Text fontWeight={600}>{q?.cgpaObtained ? `${q?.cgpaObtained}${q?.cgpaOutOf ? '/' + q?.cgpaOutOf : ''}` : '-'}</Text>
                    </Box>
                  </Grid>
                </Box>
              );
            })}
            {(!qualification || qualification.length === 0) && (
              <Text color="gray.500">No qualifications added</Text>
            )}
          </VStack>
        </Box>

        {/* ------------------------ BANK ------------------------ */}
        <Box border="1px solid" borderColor="gray.200" borderRadius="md" p={4}>
          <Flex justify="space-between" align="center" mb={4}>
            <Text fontSize="lg" fontWeight={700} color={"green.600"}>Bank Details</Text>
            <Button size="sm" onClick={() => onEditSection?.("bank")}>Edit</Button>
          </Flex>
          <Grid className="bank-grid" templateColumns={{ base: "1fr", md: "repeat(3,1fr)" }} gap={4}>
            <Field label="Bank Name" value={bank?.bankName} loading={isAnyLoading} />
            <Field label="Account Holder Name" value={bank?.accountHolderName} loading={isAnyLoading} />
            <Field label="Branch Name" value={bank?.branchName} loading={isAnyLoading} />
            <Field label="IFSC Code" value={bank?.ifsc} loading={isAnyLoading} />
            <Field label="Account Number" value={bank?.accountNumber} loading={isAnyLoading} />
          </Grid>
        </Box>

        {/* Photo & Signature moved into Personal Details (right column) */}

        {/* ------------------------ DOCUMENT LIST ------------------------ */}
        <Box border="1px solid" borderColor="gray.200" borderRadius="md" p={4}>
          <Flex justify="space-between" align="center" mb={4}>
            <Text fontSize="lg" fontWeight={700} color={"green.600"}>Document Details:</Text>
            <Button size="sm" onClick={() => onEditSection?.("documents")}>Edit</Button>
          </Flex>
          <Box overflowX="auto">
            <VStack gap={0} align="stretch">
              <HStack gap={0} p={3} fontWeight={600} fontSize="sm">
                <Box flex="1">Sr. No</Box>
                <Box flex="1">Document Name</Box>
                <Box flex="1">Uploaded On</Box>
                <Box flex="1">View</Box>
              </HStack>
              {(documents || []).map((d: any, i: number) => (
                <HStack key={i} gap={0} p={3} borderTopWidth="1px" borderTopColor="gray.200" fontSize="sm">
                  <Box flex="1">{i + 1}</Box>
                  <Box flex="1">{d?.name || '-'}</Box>
                  <Box flex="1">{d?.uploadedOn ?? d?.uploadedAt ?? d?.createdAt ?? '-'}</Box>
                  <Box flex="1">
                    <Link
                      color="brand.500"
                      href={d?.url ?? (d?.file ? URL.createObjectURL(d.file) : '#')}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      View
                    </Link>
                  </Box>
                </HStack>
              ))}

            </VStack>
          </Box>

        </Box>
      </Stack >
    </Box >
  );
}

/* ---------- Small helper field renderer ---------- */
function Field({ label, value, loading = false }: { label: string; value: any; loading?: boolean }) {
  return (
    <Box>
      <Text fontSize="sm" color="gray.600">
        {label}
      </Text>
      {loading ? (
        <SkeletonText noOfLines={1} />
      ) : (
        <Text fontWeight={600}>{value || "-"}</Text>
      )}
    </Box>
  );
}

function formatLabel(key: string) {
  return key
    .replace(/([A-Z])/g, " $1")
    .replace(/_/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}
