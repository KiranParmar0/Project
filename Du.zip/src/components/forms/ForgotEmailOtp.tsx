"use client";
import React, { useState, useEffect } from "react";
import { Box, Stack, Input, Button, Text, HStack, VStack, Center, Flex } from "@chakra-ui/react";
import { PinInput, PinInputField } from "@chakra-ui/pin-input";
import { FormControl, FormLabel, FormErrorMessage } from "@chakra-ui/form-control";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import NextImage from 'next/image';
import { FaArrowLeft } from "react-icons/fa";
import { toaster } from "../ui/toaster";
import { trpc } from "@/lib/trpc";

import Logo from '../../assets/logo.png';
import VerifyEmailModal from "./VerifyEmailModal";

type FormVals = { email: string; otp: string };

export default function ForgotEmailOtp({
  defaultEmail,
  onSend,
  onVerified,
}: {
  defaultEmail?: string;
  onSend?: (email: string) => void;
  onVerified?: (data: any) => void;
}) {
  const router = useRouter();
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<FormVals>({
    defaultValues: { email: defaultEmail ?? "", otp: "" },
  });

  const [requestId, setRequestId] = useState<string | null>(null);
  const [timer, setTimer] = useState<number>(0);
  const [sent, setSent] = useState(false);
  const [isVerifyModalOpen, setIsVerifyModalOpen] = useState(false);
  const [userEmail, setUserEmail] = useState("");

  const sendOtpMutation = trpc.auth.sendResetOTP.useMutation();
  const verifyOtpMutation = trpc.auth.verifyResetOTP.useMutation();

  useEffect(() => {
    let t: any;
    if (timer > 0) t = setTimeout(() => setTimer(timer - 1), 1000);
    return () => clearTimeout(t);
  }, [timer]);

  async function sendOtp(email?: string) {
    const e =
      email ??
      (document.querySelector('input[name="email"]') as HTMLInputElement)
        ?.value;
    if (!e) {
      toaster.create({ title: "Enter email", type: "warning", duration: 3000 });
      return;
    }

    try {
      await sendOtpMutation.mutateAsync({ email: e });

      setUserEmail(e);
      sessionStorage.setItem("resetEmail", e);
      setSent(true);
      setTimer(60);

      try { onSend?.(e); } catch (err) { /* ignore callback errors */ }

      toaster.create({
        title: "OTP sent",
        description: `A code was sent to ${e}`,
        type: "success",
        duration: 3000,
      });

      setIsVerifyModalOpen(true);
    } catch (err: any) {
      toaster.create({
        title: "Failed to send OTP",
        description: err?.message || "Unknown error",
        type: "error",
        duration: 5000,
      });
    }
  }

  async function submitOtp(vals: FormVals) {
    if (!vals.otp || vals.otp.length !== 6) {
      toaster.create({ title: "Enter a valid 6-digit OTP", type: "warning", duration: 3000 });
      return;
    }

    if (!vals.email) {
      toaster.create({ title: "Email is required", type: "warning", duration: 3000 });
      return;
    }

    try {
      const result = await verifyOtpMutation.mutateAsync({ email: vals.email, otp: vals.otp });

      toaster.create({ title: "OTP verified successfully", type: "success", duration: 3000 });

      try { onVerified?.(result); } catch (err) { /* ignore */ }

      // Store reset token and redirect to reset password page
      sessionStorage.setItem("resetToken", result.resetToken);
      router.push("/auth/reset");
    } catch (err: any) {
      toaster.create({
        title: "Verification failed",
        description: err?.message || "Invalid OTP",
        type: "error",
        duration: 5000,
      });
    }
  }

  return (
    <Center py={8}>
      <Box w="full" maxW="520px" px={6}>
        <Stack gap={6}>
          <Center>
            <NextImage src={Logo} alt="logo" width={110} height={32} />
          </Center>

          <Text fontSize="16px" fontWeight={700} textAlign="center" lineHeight={1.5}>
            Vasantrao Naik Marathwada Krishi Vidyapeeth,
            <br />
            Parbhani - 431 402 (Maharashtra)
          </Text>

          <VStack gap={6} mt={4}>
            {/* Title */}
            <Text fontSize="24px" fontWeight={700} textAlign="center">
              Forgot your Password?
            </Text>

            {/* Description */}
            <Text fontSize="14px" color="gray.600" textAlign="center" lineHeight={1.6}>
              No worries, enter your user account’s email, we will send an OTP.
            </Text>
            <Text fontSize="14px" color="gray.600" textAlign="center" lineHeight={1.6}>
              Please enter the OTP below to reset the password
            </Text>

            <form style={{ width: "100%" }}
              onSubmit={(e) => {
                e.preventDefault();
                submitOtp({
                  email:
                    (
                      document.querySelector(
                        'input[name="email"]'
                      ) as HTMLInputElement
                    )?.value || "",
                  otp:
                    (
                      document.querySelector(
                        'input[name="otp"]'
                      ) as HTMLInputElement
                    )?.value || "",
                });
              }}
            >
              <Stack gap={4} width="100%">
                <FormControl>
                  <Input
                    {...register("email")}
                    placeholder="Email Address *"
                    borderRadius="full"
                    height="48px"
                    width="100%"
                    defaultValue={defaultEmail}
                  />
                </FormControl>

                <Button
                  onClick={() => sendOtp()}
                  borderRadius="full"
                  bgColor="green.700"
                  color="white"
                  _hover={{ bg: "green.800" }}
                  height="48px"
                  width="100%"
                  fontSize="16px"
                  fontWeight={500}
                >
                  Send OTP
                </Button>

                <Button
                  onClick={() => router.push("/auth/signin")}
                  variant="ghost"
                  color="green.700"
                  fontWeight={500}
                  _hover={{ bg: "green.50" }}
                >
                  <Flex align="center" gap={2}>
                    <FaArrowLeft size={16} />
                    <Text>Back to Login Page</Text>
                  </Flex>
                </Button>
              </Stack>
            </form>
          </VStack>
        </Stack>
      </Box>

      {/* Verify Email Modal */}
      <VerifyEmailModal
        isOpen={isVerifyModalOpen}
        onClose={() => setIsVerifyModalOpen(false)}
        email={userEmail}
        onVerify={async (otp) => {
          try {
            const result = await verifyOtpMutation.mutateAsync({ email: userEmail, otp });

            toaster.create({ title: "OTP verified successfully", type: "success", duration: 3000 });
            setIsVerifyModalOpen(false);

            try { onVerified?.(result); } catch (err) { /* ignore */ }

            // Store reset token and redirect to reset password page
            sessionStorage.setItem("resetToken", result.resetToken);
            router.push("/auth/reset");
          } catch (err: any) {
            toaster.create({
              title: "Verification failed",
              description: err?.message || "Invalid OTP",
              type: "error",
              duration: 5000,
            });
          }
        }}
      />
    </Center>
  );
}
