"use client";
import React, { useState, useRef, useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import {
	Box,
	Stack,
	Button,
	Text,
	HStack,
	Input,
} from "@chakra-ui/react";
import {
	DialogRoot,
	DialogContent,
	DialogHeader,
	DialogBody,
	DialogFooter,
	DialogTitle,
	DialogBackdrop,
} from "@chakra-ui/react";
import { toaster, Toaster } from "@/components/ui/toaster";
import { trpc } from "@/lib/trpc";

interface VerifyEmailModalProps {
	isOpen: boolean;
	onClose: () => void;
	email?: string;
	onVerify?: (otp: string) => void;
	onResend?: () => void;
}

export default function VerifyEmailModal({
	isOpen,
	onClose,
	email: initialEmail,
	onVerify,
	onResend,
}: VerifyEmailModalProps) {
	const router = useRouter();
	const pathname = usePathname();
	const [otp, setOtp] = useState(["", "", "", "", "", ""]);
	const [isVerifying, setIsVerifying] = useState(false);
	const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

	const email = initialEmail || (typeof window !== 'undefined' ? sessionStorage.getItem("verifyEmail") || "" : "");
	const verifyEmailMutation = trpc.auth.verifyEmail.useMutation();

	// Reset OTP when modal opens
	useEffect(() => {
		if (isOpen) {
			setOtp(["", "", "", "", "", ""]);
			setTimeout(() => {
				inputRefs.current[0]?.focus();
			}, 100);
		}
	}, [isOpen]);

	const handleChange = (index: number, value: string) => {
		if (!/^\d*$/.test(value)) return; // Only allow digits

		const newOtp = [...otp];
		newOtp[index] = value.slice(-1); // Take only the last digit
		setOtp(newOtp);

		// Auto-focus next input
		if (value && index < 5) {
			inputRefs.current[index + 1]?.focus();
		}
	};

	const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
		if (e.key === "Backspace" && !otp[index] && index > 0) {
			inputRefs.current[index - 1]?.focus();
		}
	};

	const handlePaste = (e: React.ClipboardEvent) => {
		e.preventDefault();
		const pastedData = e.clipboardData.getData("text").slice(0, 6);
		const digits = pastedData.split("").filter(char => /\d/.test(char));

		const newOtp = [...otp];
		digits.forEach((digit, index) => {
			if (index < 6) {
				newOtp[index] = digit;
			}
		});
		setOtp(newOtp);

		// Focus the next empty input or the last one
		const nextEmptyIndex = newOtp.findIndex(val => !val);
		if (nextEmptyIndex !== -1) {
			inputRefs.current[nextEmptyIndex]?.focus();
		} else {
			inputRefs.current[5]?.focus();
		}
	};

	const handleVerify = async () => {
		const otpString = otp.join("");

		if (otpString.length !== 6) {
			toaster.create({
				title: "Incomplete OTP",
				description: "Please enter all 6 digits of the OTP to continue.",
				type: "error",
				duration: 5000,
			});
			return;
		}

		setIsVerifying(true);

		try {
			// If parent provides onVerify callback, use that instead of default API
			if (onVerify) {
				try {
					await onVerify(otpString);
					setIsVerifying(false);
				} catch (e) {
					setIsVerifying(false);
					// Error handling is done in the parent's onVerify callback
				}
				return;
			}

			// Default behavior: Call the verify-email API for signup flow
			const result = await verifyEmailMutation.mutateAsync({
				otp: otpString,
				email: email,
			});

			// Show success toast
			toaster.create({
				title: "Email Verified Successfully!",
				description: result.message || "Your email has been verified.",
				type: "success",
				duration: 2000,
			});

			setIsVerifying(false);

			// After a short delay, close modal and redirect
			setTimeout(() => {
				try { onClose(); } catch (e) { /* ignore */ }

				// Default: go to signin
				router.push("/auth/signin");
			}, 600);
		} catch (err: any) {
			setIsVerifying(false);

			toaster.create({
				title: "Verification Failed",
				description: err?.message || "The OTP you entered is incorrect. Please try again.",
				type: "error",
				duration: 5000,
			});

			// Clear inputs on error
			setOtp(["", "", "", "", "", ""]);
			setTimeout(() => {
				inputRefs.current[0]?.focus();
			}, 100);
		}
	};

	return (
		<DialogRoot
			open={isOpen}
			onOpenChange={(details) => !details.open && onClose()}
			placement="center"
			motionPreset="slide-in-bottom"

		>
			<Toaster />
			<DialogBackdrop />
			<DialogContent
				{...({
					maxW: { base: "95%", sm: "400px", md: "750px" },
					width: "100%",
					minH: { base: "auto", md: "500px" },
					maxH: { base: "90vh", md: "auto" },
					borderRadius: "16px",
					p: { base: 3, md: 6 },
					position: "fixed",
					top: "50%",
					left: "50%",
					transform: "translate(-50%, -50%)",
					zIndex: 1400,
					overflowY: "auto",
				} as any)}
			>
				<DialogHeader display="flex" justifyContent="space-around">
					<Text
						as="h2"
						fontSize={{ base: "20px", md: "24px" }}
						fontWeight={600}
					>
						Two Step Authentication
					</Text>
				</DialogHeader>

				<DialogBody py={4}>
					<Stack gap={6} alignItems="center">
						<Stack gap={3} textAlign="center" maxW="600px">
							<Text fontSize={{ base: "13px", md: "14px" }} color="gray.600" lineHeight={1.6}>
								A One-Time Password (OTP) has been sent to your registered email address:
							</Text>

							<Text fontSize={{ base: "13px", md: "14px" }} fontWeight={600} color="gray.800">
								{email || "your email"}
							</Text>

							<Text fontSize={{ base: "13px", md: "14px" }} color="gray.600">
								Please enter the 6-digit OTP below to complete the verification.
							</Text>
						</Stack>

						<HStack
							gap={{ base: 2, md: 3 }}
							justify="center"
							mt={10}
							flexWrap="nowrap"
						>
							{otp.map((digit, index) => (
								<React.Fragment key={index}>
									<Box>
										<Input
											ref={(el) => { inputRefs.current[index] = el; }}
											type="text"
											inputMode="numeric"
											maxLength={1}
											value={digit}
											onChange={(e) => handleChange(index, e.target.value)}
											onKeyDown={(e) => handleKeyDown(index, e)}
											onPaste={index === 0 ? handlePaste : undefined}
											aria-label={`OTP digit ${index + 1}`}
											width={{ base: "40px", md: "52px" }}
											height={{ base: "40px", md: "52px" }}
											textAlign="center"
											fontSize={{ base: "18px", md: "20px" }}
											fontWeight={600}
											borderWidth="1px"
											borderColor="gray.300"
											borderRadius="8px"
											_focus={{
												borderColor: "green.700",
												boxShadow: "0 0 0 1px #2D7A3E",
											}}
										/>
									</Box>
									{index === 2 && (
										<Text fontSize={{ base: "20px", md: "24px" }} fontWeight={600} color="gray.400">
											—
										</Text>
									)}
								</React.Fragment>
							))}
						</HStack>
					</Stack>
				</DialogBody>

				<DialogFooter pt={4}>
					<Box
						w="full"
						display="flex"
						justifyContent="space-around"
						alignItems="center"
					>
						<Button
							variant="outline"
							borderRadius="full"
							borderWidth="2px"
							borderColor="gray.300"
							color="gray.700"
							_hover={{ bg: "gray.50" }}
							onClick={onClose}
							width={{ base: "45%", md: "200px" }}
							height={{ base: "44px", md: "52px" }}
							fontSize={{ base: "14px", md: "16px" }}
						>
							Cancel
						</Button>

						<Button
							borderRadius="full"
							bgColor="green.700"
							color="white"
							_hover={{ bg: "green.800" }}
							onClick={handleVerify}
							width={{ base: "45%", md: "200px" }}
							height={{ base: "44px", md: "52px" }}
							fontSize={{ base: "14px", md: "16px" }}
							loading={isVerifying}
							disabled={isVerifying}
						>
							Verify Email
						</Button>
					</Box>
				</DialogFooter>
			</DialogContent>
		</DialogRoot>
	);
}
