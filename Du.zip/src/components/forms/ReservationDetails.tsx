"use client";

import DynamicForm from "../ui/DynamicForm";
import { reservationDetailsConfig } from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";
import { useMemo, useState, useEffect } from "react";

export default function ReservationDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  // Fields that should be forced to 'no' when domicile is outside Maharashtra
  const forcedNoFields = [
    "defensePersonnel",
    "freedomFighter",
    "governmentProject",
    "IsSports",
    "sportsDetails",
    "nccStudent",
    "nssMember",
    "agricultureFamily",
    "minorityCommunity",
    "isReligiousMinorityYes",
    "religiousMinority",
    "linguisticMinority",
    "haveCasteCertificate",
    "haveNCLCertificate",
    "haveEWSCertificate",
    "haveCasteValidity",
    "haveCasteValidityReceipt",
    "areOrphan",
    "physicallyDisabled"
  ];

  const [initialValues, setInitialValues] = useState<Record<string, any>>(defaultValues || {});
  const [formKey, setFormKey] = useState(0);

  // Fetch existing reservation details
  const { data: existingData, isLoading } = trpc.student.getReservationDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  const utils = trpc.useContext();
  const mutation = trpc.student.saveReservationDetails.useMutation({
    onSuccess: () => {
      console.log("Reservation details saved successfully");
      utils.student.getReservationDetails.invalidate();
      onNext?.();
    },
    onError: (error) => {
      console.error("Failed to save reservation details:", error);
    },
  });

  // Map DB data to form default values
  useEffect(() => {
    if (existingData) {
      const mappedData: Record<string, any> = {
        domicileState: existingData.DomicileType || "",
        category: existingData.CategoryID ? String(existingData.CategoryID) : "",
        religion: existingData.ReligionID ? String(existingData.ReligionID) : "",

        caste: existingData.Caste || "",
        haveCasteCertificate: existingData.HasCasteCertificate ? "yes" : "no",
        haveNCLCertificate: existingData.HasNCLCertificate ? "yes" : "no",
        haveEWSCertificate: existingData.HasEWSCertificate ? "yes" : "no",
        haveCasteValidity: existingData.HasCasteValidity ? "yes" : "no",
        haveCasteValidityReceipt: existingData.HasCasteValidityReceipt ? "yes" : "no",

        areOrphan: existingData.IsOrphan ? "yes" : "no",

        physicallyDisabled: existingData.isPH ? "yes" : "no",
        disabilityDetails: existingData.PHDetails || "",

        defensePersonnel: existingData.IsExServiceman ? "yes" : "no",
        freedomFighter: existingData.IsFreedomFighter ? "yes" : "no",
        governmentProject: existingData.IsProjectAffected ? "yes" : "no",

        IsSports: existingData.SportDetails ? "yes" : "no",
        sportsDetails: existingData.SportDetails || "",

        nccStudent: existingData.IsNCC ? "yes" : "no",
        nssMember: existingData.IsNSS ? "yes" : "no",
        agricultureFamily: existingData.IsAgriculture ? "yes" : "no",
        minorityCommunity: existingData.IsMinority ? "yes" : "no",

        religiousMinority: existingData.ReligiousMinorityID ? String(existingData.ReligiousMinorityID) : "",
        linguisticMinority: existingData.LinguisticMinorityID ? String(existingData.LinguisticMinorityID) : "",
      };

      // Handle the derived yes/no fields for minorities
      if (existingData.ReligiousMinorityID || existingData.LinguisticMinorityID) {
        if (existingData.ReligiousMinorityID && existingData.LinguisticMinorityID) mappedData.isReligiousMinorityYes = "3";
        else if (existingData.LinguisticMinorityID) mappedData.isReligiousMinorityYes = "2";
        else if (existingData.ReligiousMinorityID) mappedData.isReligiousMinorityYes = "1";
      }

      setInitialValues((prev) => ({ ...prev, ...mappedData }));
      setFormKey((k) => k + 1);
    }
  }, [existingData]);

  const handleSubmit = (data: Record<string, any>) => {
    // If domicile is outside Maharashtra, ensure forced fields are 'no' in payload
    if (data.domicileState === "O") {
      forcedNoFields.forEach((f) => {
        if (data[f] === undefined || data[f] === "" || data[f] === null) data[f] = "no";
      });
    }

    // If category is General (open), force caste-related fields to 'no' / empty
    if (data.category === "1") {
      ["caste", "haveCasteCertificate", "haveNCLCertificate", "haveEWSCertificate", "haveCasteValidity", "haveCasteValidityReceipt"].forEach((f) => {
        if (data[f] === undefined || data[f] === "" || data[f] === null) {
          // caste (select) set to empty string, others set to 'no'
          data[f] = f === "caste" ? "" : "no";
        }
      });
    }

    // Transform form data to match API schema
    const payload = {
      domicileStateId: data.domicileState === "M" ? 1 : 2, // Assuming 1=Maharashtra based on typical logic, or just mapping boolean? Schema says ID. Wait, form has "M"/"O".
      // Let's check master_state content if possible, but standard is usually 1 for MH. 
      // Actually, let's look at schema. Master_State.
      // For now, I'll assume M -> 1 (Maharashtra), O -> 2 (Outside) or similar. 
      // safer: Use domicileType for 'M'/'O' char, and maybe skip ID if unsure?
      // Schema has `DomicileStateID` AND `DomicileType`.
      // I will map `domicileType` = data.domicileState.

      domicileType: data.domicileState,
      categoryId: data.category ? parseInt(data.category) : undefined,
      religionId: data.religion ? parseInt(data.religion) : undefined,

      // Mappings
      caste: data.caste,
      hasCasteCertificate: data.haveCasteCertificate === "yes",
      HasNCLCertificate: data.haveNCLCertificate === "yes", // NCL -> KKL
      HasEWSCertificate: data.haveEWSCertificate === "yes", // EWS -> WS
      hasCasteValidity: data.haveCasteValidity === "yes",
      hasCasteValidityReceipt: data.haveCasteValidityReceipt === "yes",

      isOrphan: data.areOrphan === "yes",
      isPH: data.physicallyDisabled === "yes", // Physically Disabled -> BJI
      PHDetails: data.disabilityDetails, // Disability Details -> PHDetails

      IsExServiceman: data.defensePersonnel === "yes",
      isFreedomFighter: data.freedomFighter === "yes",
      IsProjectAffected: data.governmentProject === "yes", // Project Affected -> Injury Affected

      // Sports
      sportDetails: data.sportsDetails, // Only if IsSports is yes? Backend handles storage.
      // But we should probably only send sportDetails if IsSports is yes to be clean?
      // existing logic forced "no" so fields might be empty anyway.

      isNCC: data.nccStudent === "yes",
      isNSS: data.nssMember === "yes",
      isAgriculture: data.agricultureFamily === "yes",
      isMinority: data.minorityCommunity === "yes",

      religiousMinorityId: data.religiousMinority && !isNaN(Number(data.religiousMinority)) ? parseInt(data.religiousMinority) : undefined,
      linguisticMinorityId: data.linguisticMinority && !isNaN(Number(data.linguisticMinority)) ? parseInt(data.linguisticMinority) : undefined,
    };

    console.log("Submitting payload:", payload);
    mutation.mutate(payload);
  };

  // onChange handler receives (name, value, setValue, getValues)
  const handleChange = (name: string, value: any, setValue?: (n: string, v: any) => void) => {
    if (name === "domicileState" && setValue) {
      if (value === "O") {
        // Set all affected fields to 'no' immediately
        forcedNoFields.forEach((f) => setValue(f, "no"));
      }
    }
    // When category is changed to General (1), hide caste-related fields by setting defaults to 'no'/'""'
    if (name === "category" && setValue) {
      if (value === "1") {
        ["caste", "haveCasteCertificate", "haveNCLCertificate", "haveEWSCertificate", "haveCasteValidity", "haveCasteValidityReceipt"].forEach((f) => {
          setValue(f, f === "caste" ? "" : "no");
        });
      }
    }
  };

  // Fetch master data for category & religion
  const { data: categories } = trpc.master.getCategories.useQuery();
  const { data: religions } = trpc.master.getReligions.useQuery();

  const dynamicSections = useMemo(() => {
    return reservationDetailsConfig.map((section) => ({
      ...section,
      fields: section.fields.map((field) => {
        if (field.name === "category") {
          return {
            ...field,
            options: (categories || []).map((c: any) => ({ value: String(c.id), label: c.name })),
          };
        }
        if (field.name === "religion") {
          return {
            ...field,
            options: (religions || []).map((r: any) => ({ value: String(r.id), label: r.name })),
          };
        }
        return field;
      }),
    }));
  }, [categories, religions]);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <DynamicForm
      key={formKey}
      sections={dynamicSections}
      onSubmit={handleSubmit}
      defaultValues={initialValues}
      onChange={(name, value, setValue) => handleChange(name, value, setValue)}
      previousButton={{
        label: "Previous",
        onClick: () => {
          onPrev?.();
        },
      }}
    />
  );
}
