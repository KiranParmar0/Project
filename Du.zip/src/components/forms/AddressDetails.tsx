"use client";

import { useEffect, useState, useMemo } from "react";
import DynamicForm from "../ui/DynamicForm";
import { addressDetailsConfig } from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../ui/toaster";
import { FormSection } from "../ui/DynamicForm";
import { useCurrentUser } from "@/hooks/useCurrentUser";

export default function AddressDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [initialValues, setInitialValues] = useState<Record<string, any>>({});
  const [formKey, setFormKey] = useState(0);
  const [selectedStateId, setSelectedStateId] = useState<number | null>(null);
  const [selectedDistrictId, setSelectedDistrictId] = useState<number | null>(null);
  const [selectedPStateId, setSelectedPStateId] = useState<number | null>(null);
  const [selectedPDistrictId, setSelectedPDistrictId] = useState<number | null>(null);
  const [nationality, setNationality] = useState<string>("");
  const [isSameAsCurrentAddress, setIsSameAsCurrentAddress] = useState<boolean>(false);
  const utils = trpc.useUtils();
  const { user } = useCurrentUser();

  // Fetch master data
  const { data: states } = trpc.student.getStates.useQuery();
  const { data: districts } = trpc.student.getDistricts.useQuery(
    { stateId: selectedStateId! },
    { enabled: !!selectedStateId }
  );
  const { data: talukas } = trpc.student.getTalukas.useQuery(
    { districtId: selectedDistrictId! },
    { enabled: !!selectedDistrictId }
  );
  const { data: pDistricts } = trpc.student.getDistricts.useQuery(
    { stateId: selectedPStateId! },
    { enabled: !!selectedPStateId }
  );
  const { data: pTalukas } = trpc.student.getTalukas.useQuery(
    { districtId: selectedPDistrictId! },
    { enabled: !!selectedPDistrictId }
  );

  // Fetch existing address details from database
  const { data: existingData, isLoading } = trpc.student.getAddressDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // Save address details mutation
  const saveAddressDetails = trpc.student.saveAddressDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Address details saved successfully",
        type: "success",
        duration: 3000,
      });
      utils.student.getAddressDetails.invalidate();
      utils.student.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save address details",
        type: "error",
        duration: 5000,
      });
    },
  });

  useEffect(() => {
    if (existingData) {
      setNationality(existingData.Nationality || "");
      setIsSameAsCurrentAddress(existingData.IsSameAsAddress || false);
      const mappedData = {
        nationality: existingData.Nationality || "",
        country: existingData.Country?.toString() || "",
        // Default to Maharashtra (21) when nationality is India and no state provided
        state: existingData.StateID?.toString() || (existingData.Nationality === 'I' ? '21' : ""),
        district: existingData.DistrictID?.toString() || "",
        tehsil: existingData.TalukaID?.toString() || "",
        village: existingData.VillageCity || "",
        address1: existingData.Address1 || "",
        address2: existingData.Address2 || "",
        pincode: existingData.PinCode || "",
        sameAsCurrentAddress: existingData.IsSameAsAddress || false,
        p_country: existingData.Country?.toString() || "", // Use same country as current
        p_state: existingData.PSStateID?.toString() || "",
        p_district: existingData.PSDistrictID?.toString() || "",
        p_tehsil: existingData.PSTalukaID?.toString() || "",
        p_village: existingData.PSVillage || "",
        p_address1: existingData.PAddress1 || "",
        p_address2: existingData.PAddress2 || "",
        p_pincode: existingData.PPinCode || "",
      };
      setInitialValues(mappedData);

      // Set selected IDs for cascading dropdowns - this will trigger the queries
      if (existingData.StateID) {
        setSelectedStateId(existingData.StateID);
      } else if (existingData.Nationality === 'I') {
        // Default to Maharashtra (21) for Indian nationality when backend didn't provide a state
        setSelectedStateId(21);
      }
      if (existingData.DistrictID) setSelectedDistrictId(existingData.DistrictID);
      if (existingData.PSStateID) setSelectedPStateId(existingData.PSStateID);
      if (existingData.PSDistrictID) setSelectedPDistrictId(existingData.PSDistrictID);

      // Delay formKey increment to allow queries to fetch data
      setTimeout(() => {
        setFormKey(prev => prev + 1);
      }, 100);
    }
  }, [existingData]);

  // Create dynamic config with fetched options
  const dynamicConfig: FormSection[] = useMemo(() => {
    return addressDetailsConfig.map((section) => ({
      ...section,
      fields: section.fields.map((field) => {
        if (field.name === "country") {
          return {
            ...field,
            disabled: nationality === "I",
            defaultValue: nationality === "I" ? "IN" : field.defaultValue,
          };
        }

        if (field.name === "p_country") {
          return {
            ...field,
            disabled: isSameAsCurrentAddress && nationality === "I",
            defaultValue: isSameAsCurrentAddress && nationality === "I" ? "IN" : field.defaultValue,
          };
        }

        if (field.name === "state" || field.name === "p_state") {
          const isPermanent = field.name === "p_state"; // true for permanent address field
          const defaultForIndia = "21"; // Maharashtra as default
          const computedDefault = isPermanent
            ? (isSameAsCurrentAddress && nationality === "I" ? defaultForIndia : field.defaultValue)
            : (nationality === "I" ? defaultForIndia : field.defaultValue);

          return {
            ...field,
            options: (states || []).map((s) => ({ value: String(s.value), label: s.label || "" })),
            defaultValue: computedDefault,
          };
        }

        if (field.name === "district") {
          return { ...field, options: (districts || []).map((d) => ({ value: String(d.value), label: d.label || "" })) };
        }

        if (field.name === "p_district") {
          return { ...field, options: (pDistricts || []).map((d) => ({ value: String(d.value), label: d.label || "" })) };
        }

        if (field.name === "tehsil") {
          return { ...field, options: (talukas || []).map((t) => ({ value: String(t.value), label: t.label || "" })) };
        }

        if (field.name === "p_tehsil") {
          return { ...field, options: (pTalukas || []).map((t) => ({ value: String(t.value), label: t.label || "" })) };
        }

        return field;
      }),
    }));
  }, [states, districts, talukas, pDistricts, pTalukas, nationality, isSameAsCurrentAddress]);

  const handleSubmit = (data: Record<string, any>) => {
    saveAddressDetails.mutate({
      nationality: data.nationality,
      country: data.country || undefined,
      stateId: data.state ? Number(data.state) : undefined,
      districtId: data.district ? Number(data.district) : undefined,
      talukaId: data.tehsil,
      villageCity: data.village,
      address1: data.address1,
      address2: data.address2,
      pinCode: data.pincode,
      isSameAsAddress: data.sameAsCurrentAddress,
      psCountry: data.p_country || undefined,
      psStateId: data.p_state ? Number(data.p_state) : undefined,
      psDistrictId: data.p_district ? Number(data.p_district) : undefined,
      psTalukaId: data.p_tehsil,
      psVillage: data.p_village,
      pAddress1: data.p_address1,
      pAddress2: data.p_address2,
      pPinCode: data.p_pincode,
    });
  };

  // Watch for changes in state/district to update cascading dropdowns
  const handleFormChange = (name: string, value: any, formSetValue?: (name: string, value: any) => void, formGetValues?: () => Record<string, any>) => {
    if (name === 'nationality') {
      setNationality(value);
      // If Indian is selected, set country to India; otherwise reset to empty
      if (formSetValue) {
        if (value === 'I') {
          formSetValue('country', 'IN');
          formSetValue('p_country', 'IN');
          // If no state is set in the form, default to Maharashtra (21)
          if (formGetValues) {
            const vals = formGetValues();
            if (!vals.state) {
              formSetValue('state', '21');
              setSelectedStateId(21);
              setSelectedDistrictId(null);
            }
            if (!vals.p_state) {
              formSetValue('p_state', '21');
              setSelectedPStateId(21);
              setSelectedPDistrictId(null);
            }
          }
        } else {
          formSetValue('country', '');
          // Clear state selections when nationality is not India
          formSetValue('state', '');
          formSetValue('p_state', '');
          setSelectedStateId(null);
          setSelectedDistrictId(null);
          setSelectedPStateId(null);
          setSelectedPDistrictId(null);
        }
      }
    } else if (name === 'state') {
      setSelectedStateId(value ? Number(value) : null);
      setSelectedDistrictId(null);
    } else if (name === 'district') {
      setSelectedDistrictId(value ? Number(value) : null);
    } else if (name === 'p_state') {
      setSelectedPStateId(value ? Number(value) : null);
      setSelectedPDistrictId(null);
    } else if (name === 'p_district') {
      setSelectedPDistrictId(value ? Number(value) : null);
    } else if (name === 'sameAsCurrentAddress' && formSetValue && formGetValues) {
      // Update state and copy address when checkbox is checked
      setIsSameAsCurrentAddress(value === true);

      if (value === true) {
        const values = formGetValues();
        formSetValue('p_country', values.country || '');
        formSetValue('p_state', values.state || '');
        formSetValue('p_district', values.district || '');
        formSetValue('p_tehsil', values.tehsil || '');
        formSetValue('p_village', values.village || '');
        formSetValue('p_address1', values.address1 || '');
        formSetValue('p_address2', values.address2 || '');
        formSetValue('p_pincode', values.pincode || '');

        // Update permanent address state IDs for cascading
        if (values.state) setSelectedPStateId(Number(values.state));
        if (values.district) setSelectedPDistrictId(Number(values.district));
      }
    }
  };

  // Show loading state while fetching data or waiting for user session
  if (isLoading || !user) {
    return <div>Loading...</div>;
  }

  return (
    <DynamicForm
      key={formKey}
      sections={dynamicConfig}
      onSubmit={handleSubmit}
      defaultValues={initialValues}
      isSubmitting={saveAddressDetails.isPending}
      onChange={handleFormChange}
      previousButton={{
        label: "Previous",
        onClick: () => {
          onPrev?.();
        },
      }}
    />
  );
}
