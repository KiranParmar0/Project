"use client";
import React, { useState } from "react";
import { Box, Stack, Input, Button, Text, VStack, Center, Flex } from "@chakra-ui/react";
import { FormControl, FormLabel, FormErrorMessage } from "@chakra-ui/form-control";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useRouter } from "next/navigation";
import NextImage from 'next/image';
import { FaArrowLeft } from "react-icons/fa";
import Logo from '../../assets/logo.png';
import { Toaster, toaster } from "@/components/ui/toaster";
import { trpc } from "@/lib/trpc";

const EyeIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

const EyeOffIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);

const ResetSchema = z.object({
  password: z.string().min(8, "At least 8 characters"),
  confirmPassword: z.string().min(8, "Confirm password"),
}).refine((d) => d.password === d.confirmPassword, { message: "Passwords must match", path: ["confirmPassword"] });

type ResetForm = z.infer<typeof ResetSchema>;

export default function ForgotResetPassword({ onReset }: { onReset?: () => void } = {}) {
  const router = useRouter();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<ResetForm>({
    resolver: zodResolver(ResetSchema),
    defaultValues: {
      password: "",
      confirmPassword: "",
    }
  });

  const resetPasswordMutation = trpc.auth.resetPassword.useMutation();

  const submit = async (vals: ResetForm) => {
    // Get reset token from session storage
    const resetToken = sessionStorage.getItem("resetToken");

    if (!resetToken) {
      toaster.create({
        title: "Missing Reset Token",
        description: "The password reset link is invalid or has expired. Please request a new password reset link.",
        type: "error",
        duration: 5000,
      });
      setTimeout(() => router.push("/auth/forgot/options"), 1500);
      return;
    }

    try {

      await resetPasswordMutation.mutateAsync({
        resetToken,
        newPassword: vals.password
      });

      try { onReset?.(); } catch (e) { /* ignore */ }

      // Clear reset token from session storage
      sessionStorage.removeItem("resetToken");
      sessionStorage.removeItem("resetEmail");

      toaster.create({
        title: "Password Reset Successful!",
        description: "Your password has been successfully reset. You can now login with your new password.",
        type: "success",
        duration: 3000,
      });

      setTimeout(() => router.push("/auth/signin"), 1500);
    } catch (err: any) {
      toaster.create({
        title: "Reset Failed",
        description: err?.message || "Unable to reset password. Please try again or request a new reset link.",
        type: "error",
        duration: 5000,
      });
    }
  };

  React.useEffect(() => {
    if (typeof window === 'undefined') return
    try {
      const p = new URLSearchParams(window.location.search)
      // setResetToken(p.get('token') ?? '')
    } catch (e) {
      // setResetToken('')
    }
  }, [])

  return (
    <Center  >
      <Toaster />
      <Box w="full" maxW="520px" px={6}>
        <Stack gap={6}>
          <Center>
            <NextImage src={Logo} alt="logo" width={110} height={32} />
          </Center>

          <Text fontSize="16px" fontWeight={700} textAlign="center" lineHeight={1.5}>
            Vasantrao Naik Marathwada Krishi Vidyapeeth,
            <br />
            Parbhani - 431 402 (Maharashtra)
          </Text>

          <Box as="form" width="100%" onSubmit={handleSubmit(submit)}>
            <VStack gap={6} mt={4}>
              {/* Title */}
              <Text fontSize="24px" fontWeight={700} textAlign="center">
                Set a New Password
              </Text>

              {/* Description */}
              <Text fontSize="14px" color="gray.600" textAlign="center" lineHeight={1.6}>
                Your new password must be different from previously used passwords
              </Text>

              <Stack gap={4} width="100%">
                <FormControl isInvalid={!!errors.password}>
                  <Box position="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      {...register("password")}
                      placeholder="Password *"
                      borderRadius="full"
                      height="48px"
                      pr="40px"
                    />
                    <Box
                      as="button"
                      onClick={() => setShowPassword((s) => !s)}
                      position="absolute"
                      right="12px"
                      top="50%"
                      transform="translateY(-50%)"
                      background="none"
                      border="none"
                      cursor="pointer"
                      display="flex"
                      alignItems="center"
                      justifyContent="center"
                      color="#999"
                      padding={0}
                    >
                      {showPassword ? <EyeOffIcon /> : <EyeIcon />}
                    </Box>
                  </Box>
                  <FormErrorMessage>{errors.password?.message}</FormErrorMessage>
                </FormControl>

                <FormControl isInvalid={!!errors.confirmPassword}>
                  <Box position="relative">
                    <Input
                      type={showConfirm ? "text" : "password"}
                      {...register("confirmPassword")}
                      placeholder="Confirm Password *"
                      borderRadius="full"
                      height="48px"
                      pr="40px"
                    />

                    <Box
                      as="button"
                      onClick={() => setShowConfirm((s) => !s)}
                      position="absolute"
                      right="12px"
                      top="50%"
                      transform="translateY(-50%)"
                      background="none"
                      border="none"
                      cursor="pointer"
                      display="flex"
                      alignItems="center"
                      justifyContent="center"
                      color="#999"
                      padding={0}
                    >
                      {showConfirm ? <EyeOffIcon /> : <EyeIcon />}
                    </Box>
                  </Box>
                  <FormErrorMessage>{errors.confirmPassword?.message}</FormErrorMessage>
                </FormControl>

                <Button
                  type="submit"
                  borderRadius="full"
                  bgColor="green.700"
                  color="white"
                  _hover={{ bg: "green.800" }}
                  height="48px"
                  width="100%"
                  fontSize="16px"
                  fontWeight={500}
                  loading={isSubmitting}
                >
                  Reset Password
                </Button>

                <Button
                  onClick={() => router.push("/auth/signin")}
                  variant="ghost"
                  color="green.700"
                  fontWeight={500}
                  _hover={{ bg: "green.50" }}
                >
                  <Flex align="center" gap={2}>
                    <FaArrowLeft size={16} />
                    <Text>Back to Login Page</Text>
                  </Flex>
                </Button>
              </Stack>
            </VStack>
          </Box>
        </Stack>
      </Box>
    </Center>
  );
}
