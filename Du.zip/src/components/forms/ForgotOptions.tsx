"use client";
import React from "react";
import { Box, Stack, Button, Text, VStack, Image, Flex, Center } from "@chakra-ui/react";
import { useRouter } from "next/navigation";
import { FaChevronRight, FaArrowLeft } from "react-icons/fa";
import NextImage from 'next/image';
import Logo from '../../assets/logo.png';

export default function ForgotOptions({
  email,
  onSelect,
}: {
  email?: string;
  onSelect?: (method: "email-otp" | "security") => void;
}) {
  const router = useRouter();

  const handleSelect = (method: "email-otp" | "security") => {
    if (onSelect) {
      onSelect(method);
    } else {
      // Default navigation
      if (method === "email-otp") {
        router.push("/auth/forgot/email-otp");
      } else {
        router.push("/auth/forgot/security-question");
      }
    }
  };

  return (
    <Center  >
      <Box w="full" maxW="520px" px={6}>
        <Stack gap={6}>
          <Center>
            <NextImage src={Logo} alt="logo" width={110} height={32} />
          </Center>

          <Text fontSize="16px" fontWeight={700} textAlign="center" lineHeight={1.5}>
            Vasantrao Naik Marathwada Krishi Vidyapeeth,
            <br />
            Parbhani - 431 402 (Maharashtra)
          </Text>

          <VStack gap={6} mt={4}>
            {/* Title */}
            <Text fontSize="24px" fontWeight={700} textAlign="center">
              Forgot your Password?
            </Text>

            {/* Description */}
            <Text fontSize="14px" color="gray.600" textAlign="center" lineHeight={1.6}>
              Select how you&apos;d like to reset your password: receive an OTP on your registered email or answer your security question.
            </Text>

            {/* Option Buttons */}
            <Stack gap={3} width="100%">
              <Button
                onClick={() => handleSelect("email-otp")}
                variant="outline"
                width="100%"
                height="56px"
                borderColor="gray.300"
                borderRadius="full"
                justifyContent="space-between"
                px={5}
                _hover={{ bg: "green.50", borderColor: "green.700" }}
                fontWeight={500}
                fontSize="15px"
              >
                <Text>Verify with Email OTP</Text>
                <FaChevronRight size={16} />
              </Button>

              <Button
                onClick={() => handleSelect("security")}
                variant="outline"
                width="100%"
                height="56px"
                borderColor="gray.300"
                borderRadius="full"
                justifyContent="space-between"
                px={5}
                _hover={{ bg: "green.50", borderColor: "green.700" }}
                fontWeight={500}
                fontSize="15px"
              >
                <Text>Verify with Security Question</Text>
                <FaChevronRight size={16} />
              </Button>
            </Stack>

            {/* Back to Login */}
            <Button
              onClick={() => router.push("/auth/signin")}
              variant="ghost"
              color="green.700"
              fontWeight={500}
              mt={2}
              _hover={{ bg: "green.50" }}
            >
              <Flex align="center" gap={2}>
                <FaArrowLeft size={14} />
                <Text>Back to Login Page</Text>
              </Flex>
            </Button>
          </VStack>
        </Stack>
      </Box>
    </Center>
  );
}
