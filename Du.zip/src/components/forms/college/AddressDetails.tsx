"use client";

import { useEffect, useState, useMemo } from "react";
import DynamicForm from "../../ui/DynamicForm";
import { addressDetailsConfig } from "@/config/forms/collegeRegistrationDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../../ui/toaster";
import { Box, Button, Text, VStack } from "@chakra-ui/react";
import { FormSection } from "../../ui/DynamicForm";

export default function AddressDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [initialValues, setInitialValues] = useState<Record<string, any>>({});
  const [formKey, setFormKey] = useState(0);
  const [mapLocation, setMapLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [locationLoading, setLocationLoading] = useState(false);
  const [selectedStateId, setSelectedStateId] = useState<number>(1); // Default to Maharashtra
  const utils = trpc.useUtils();

  // Fetch master data for college address_details (DistrictID from master_district table)
  const { data: districts } = trpc.student.getDistricts.useQuery(
    { stateId: selectedStateId },
    { enabled: !!selectedStateId }
  );

  const { data: existingData, isLoading } = trpc.college.getAddressDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  const saveAddressDetails = trpc.college.saveAddressDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Address details saved successfully",
        type: "success",
        duration: 3000,
      });
      utils.college.getAddressDetails.invalidate();
      utils.college.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save address details",
        type: "error",
        duration: 5000,
      });
    },
  });

  useEffect(() => {
    if (existingData) {
      setInitialValues(existingData);
      setFormKey(prev => prev + 1);
      
      // Set map location if lat/lng exist
      if ((existingData as any).latitude && (existingData as any).longitude) {
        setMapLocation({
          lat: parseFloat((existingData as any).latitude),
          lng: parseFloat((existingData as any).longitude)
        });
      }
    }
  }, [existingData]);
  
  // Update form configuration with dynamic district options
  const updatedSections = useMemo((): FormSection[] => {
    return addressDetailsConfig.map((section) => ({
      ...section,
      fields: section.fields.map((field) => {
        if (field.name === "district") {
          return {
            ...field,
            options: districts?.filter((d: any) => d?.value && d?.label).map((d: any) => ({
              value: d.value.toString(),
              label: d.label,
            })) || [],
          };
        }
        return field;
      }),
    }));
  }, [districts]);

  const handleGetLiveLocation = () => {
    if (!navigator.geolocation) {
      toaster.create({
        title: "Error",
        description: "Geolocation is not supported by your browser",
        type: "error",
        duration: 3000,
      });
      return;
    }

    setLocationLoading(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        
        setMapLocation({ lat, lng });
        setInitialValues(prev => ({
          ...prev,
          latitude: lat.toFixed(8),
          longitude: lng.toFixed(8),
        }));
        setFormKey(prev => prev + 1);
        setLocationLoading(false);
        
        toaster.create({
          title: "Success",
          description: "Location captured successfully",
          type: "success",
          duration: 3000,
        });
      },
      (error) => {
        setLocationLoading(false);
        toaster.create({
          title: "Error",
          description: error.message || "Failed to get location",
          type: "error",
          duration: 3000,
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  };

  const handleFormChange = (name: string, value: any, setValue?: any, getValues?: any) => {
    if (name === "latitude" || name === "longitude") {
      const values = getValues?.() || {};
      const lat = name === "latitude" ? parseFloat(value) : parseFloat(values.latitude || "0");
      const lng = name === "longitude" ? parseFloat(value) : parseFloat(values.longitude || "0");
      
      if (!isNaN(lat) && !isNaN(lng) && lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180) {
        setMapLocation({ lat, lng });
      }
    }
  };

  const handleSubmit = (data: Record<string, any>) => {
    // Skip backend save for now - just proceed to next step
    console.log('Address Details Form Data:', data);
    toaster.create({
      title: "Success",
      description: "Address details saved (local only)",
      type: "success",
      duration: 2000,
    });
    onNext?.();
    
    // TODO: Uncomment when backend is ready
    // saveAddressDetails.mutate({
    //   address1: data.address1,
    //   address2: data.address2,
    //   city: data.village,
    //   state: data.state || "",
    //   district: data.district,
    //   pincode: data.pincode,
    //   country: data.country || "India",
    //   tehsil: data.tehsil,
    //   nearestAirport: data.nearestAirport,
    //   nearestRailwayStation: data.nearestRailwayStation,
    //   nearestBusStand: data.nearestBusStand,
    //   latitude: data.latitude,
    //   longitude: data.longitude,
    // });
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <Box>
      {/* Live Location Button Section */}
      {/* <Box mb={4} p={4} bg="blue.50" borderRadius="md" borderWidth="1px" borderColor="blue.200">
        <VStack align="stretch" gap={2}>
          <Text fontSize="sm" fontWeight="medium" color="blue.900">
            📍 College Location Coordinates
          </Text>
          <Text fontSize="xs" color="gray.600">
            Use your device&apos;s GPS to automatically capture the exact location of your college, or enter coordinates manually below.
          </Text>
          <Button
            onClick={handleGetLiveLocation}
            loading={locationLoading}
            colorPalette="blue"
            size="sm"
            width="fit-content"
          >
            📍 Use Live Location
          </Button>
        </VStack>
      </Box> */}

      {/* Address Form */}
      <DynamicForm
        key={formKey}
        sections={updatedSections}
        onSubmit={handleSubmit}
        defaultValues={initialValues}
        submitButtonText="Save & Next"
        isSubmitting={saveAddressDetails.isPending}
        onChange={handleFormChange}
        previousButton={{
          label: "Previous",
          onClick: onPrev || (() => {}),
        }}
      />

      {/* Map Display */}
      {mapLocation && (
        <Box mt={6} borderWidth="1px" borderRadius="md" overflow="hidden">
          <iframe
            width="100%"
            height="400"
            style={{ border: 0 }}
            loading="lazy"
            src={`https://maps.google.com/maps?q=${mapLocation.lat},${mapLocation.lng}&z=15&output=embed`}
            title="College Location Map"
          />
          <Box p={3} bg="gray.50">
            <Text fontSize="sm" fontWeight="medium">
              📍 {initialValues.address1 || "Location"}, {initialValues.village || ""}, {initialValues.district || ""} {initialValues.pincode || ""}
            </Text>
          </Box>
        </Box>
      )}
    </Box>
  );
}
