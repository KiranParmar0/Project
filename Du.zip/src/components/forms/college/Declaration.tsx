"use client";
import React, { useState } from "react";
import {
  Box,
  Stack,
  Text,
  Button,
  Flex,
  Image,
  Separator,
  Grid,
} from "@chakra-ui/react";
import { collegeDeclarationConfig } from "@/config/forms/collegeRegistrationDetailsForm";
import "../Declaration.css";
import { trpc } from "@/lib/trpc";

type DeclarationForm = {
  accepted: boolean;
};

// Simple field display component
const DisplayField = ({ label, value }: { label: string; value: any }) => (
  <Box>
    <Text fontSize="xs" color="gray.600" mb={1}>
      {label}
    </Text>
    <Text fontSize="sm" fontWeight="medium">
      {value || "--"}
    </Text>
  </Box>
);

export default function Declaration({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Partial<DeclarationForm>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [accepted, setAccepted] = useState(defaultValues?.accepted || false);
  const [error, setError] = useState<string | null>(null);

  const utils = trpc.useUtils();

  // Fetch all college profile data
  const { data: basicData } = trpc.college.getBasicDetails.useQuery(undefined);
  const { data: addressData } = trpc.college.getAddressDetails.useQuery(undefined);
  const { data: contactData } = trpc.college.getContactDetails.useQuery(undefined);
  // photo/sign endpoint is not available on the TRPC router currently; use a placeholder until backend provides it
  const photoSignData: any = undefined;

  const saveDeclaration = trpc.college.saveDeclaration.useMutation({
    onSuccess: () => {
      utils.college.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      setError(error.message || "Failed to save declaration");
    },
  });

  const handleSubmit = (e: React.FormEvent) => {  
    e.preventDefault();

    if (!accepted) {
      setError("You must accept the declaration to continue");
      return;
    }

    const data: DeclarationForm = {
      accepted,
    };

    console.log("Declaration accepted:", data);
    onNext?.();
    
    // TODO: Uncomment when backend is ready
    // saveDeclaration.mutate(data);
  };

  return (
    <>
      {/* Header */}
      <Flex justify="space-between" align="center" mb={6}>
        <Text fontSize="xl" fontWeight="bold" color="orange.500">
          Declaration
        </Text>
      </Flex>

      {/* Basic Details Section */}
      <Box
        border="1px solid"
        borderColor="gray.200"
        borderRadius="md"
        p={4}
        mb={4}
        bg="white"
      >
        <Flex justify="space-between" align="center" mb={4}>
          <Text fontSize="md" fontWeight="bold" color="green.600">
            Basic Details:
          </Text>
          <Button size="sm" variant="ghost" colorPalette="blue">
            ✏ Edit
          </Button>
        </Flex>
        <Grid templateColumns="repeat(4, 1fr)" gap={4}>
          <DisplayField label="Parent Institution:" value={(basicData as any)?.parentInstitution} />
          <DisplayField label="College Name:" value={(basicData as any)?.collegeName} />
          <DisplayField label="College Short Name:" value={(basicData as any)?.collegeShortName} />
          <DisplayField label="College Establishment Year:" value={(basicData as any)?.establishmentYear} />
          <DisplayField label="Region:" value={(basicData as any)?.region} />
          <DisplayField label="College Type:" value={(basicData as any)?.collegeType} />
          <DisplayField label="College Category:" value={(basicData as any)?.collegeCategory} />
          <DisplayField label="Institution Type:" value={(basicData as any)?.institutionType} />
          <DisplayField label="Administrative Autonomy:" value={(basicData as any)?.administrativeAutonomy} />
          <DisplayField label="Minority Type:" value={(basicData as any)?.minorityType} />
          <DisplayField label="Affiliation No:" value={(basicData as any)?.affiliationNo} />
          <DisplayField label="Affiliation Type:" value={(basicData as any)?.affiliationType} />
          <DisplayField label="Affiliation Start Date:" value={(basicData as any)?.affiliationStartDate} />
          <DisplayField label="Affiliation End Date:" value={(basicData as any)?.affiliationEndDate} />
          <DisplayField label="College Status:" value={(basicData as any)?.collegeStatus} />
          <DisplayField label="Principal Name:" value={(basicData as any)?.principalName} />
        </Grid>
      </Box>

      {/* Address Details Section */}
      <Box
        border="1px solid"
        borderColor="gray.200"
        borderRadius="md"
        p={4}
        mb={4}
        bg="white"
      >
        <Flex justify="space-between" align="center" mb={4}>
          <Text fontSize="md" fontWeight="bold" color="green.600">
            Address Details:
          </Text>
          <Button size="sm" variant="ghost" colorPalette="blue">
            ✏ Edit
          </Button>
        </Flex>
        <Grid templateColumns="repeat(4, 1fr)" gap={4}>
          <DisplayField label="Country:" value={(addressData as any)?.country || "India"} />
          <DisplayField label="State:" value={(addressData as any)?.state || "Maharashtra"} />
          <DisplayField label="Address 1:" value={(addressData as any)?.address1} />
          <DisplayField label="Address 2:" value={(addressData as any)?.address2} />
          <DisplayField label="Village/ City:" value={(addressData as any)?.village} />
          <DisplayField label="Tehsil:" value={(addressData as any)?.tehsil} />
          <DisplayField label="District:" value={(addressData as any)?.district} />
          <DisplayField label="Pincode:" value={(addressData as any)?.pincode} />
          <DisplayField label="Nearest Airport:" value={(addressData as any)?.nearestAirport} />
          <DisplayField label="Nearest Railway Station:" value={(addressData as any)?.nearestRailwayStation} />
          <DisplayField label="Nearest Bus Stand:" value={(addressData as any)?.nearestBusStand} />
          <DisplayField label="Latitude:" value={(addressData as any)?.latitude} />
          <DisplayField label="Longitude:" value={(addressData as any)?.longitude} />
        </Grid>
      </Box>

      {/* Contact Details Section */}
      <Box
        border="1px solid"
        borderColor="gray.200"
        borderRadius="md"
        p={4}
        mb={4}
        bg="white"
      >
        <Flex justify="space-between" align="center" mb={4}>
          <Text fontSize="md" fontWeight="bold" color="green.600">
            Contact Details:
          </Text>
          <Button size="sm" variant="ghost" colorPalette="blue">
            ✏ Edit
          </Button>
        </Flex>

        <Box mb={4}>
          <Text fontSize="sm" fontWeight="bold" color="orange.500" mb={3}>
            College Contact Details:
          </Text>
          <Grid templateColumns="repeat(4, 1fr)" gap={4}>
            <DisplayField label="Email" value={(contactData as any)?.email} />
            <DisplayField label="Mobile Number" value={(contactData as any)?.mobileNumber} />
            <DisplayField label="Fax Number" value={(contactData as any)?.faxNumber} />
            <DisplayField label="Web URL" value={(contactData as any)?.webUrl} />
          </Grid>
        </Box>

        {(contactData as any)?.additionalMobiles && (contactData as any).additionalMobiles.length > 0 && (
          <Box mb={4}>
            <Text fontSize="sm" fontWeight="bold" color="orange.500" mb={3}>
              Additional Contact Numbers:
            </Text>
            {(contactData as any).additionalMobiles.map((mobile: string, index: number) => (
              <Grid key={index} templateColumns="repeat(2, 1fr)" gap={4} mb={2}>
                <DisplayField label="Mobile Number" value={mobile} />
                <DisplayField label="Landline Number" value={(contactData as any).additionalLandlines?.[index]} />
              </Grid>
            ))}
          </Box>
        )}

        {(contactData as any)?.contactPersons && (contactData as any).contactPersons.length > 0 && (
          <Box>
            <Text fontSize="sm" fontWeight="bold" color="orange.500" mb={3}>
              Contact Details:
            </Text>
            {(contactData as any).contactPersons.map((person: any, index: number) => (
              <Box key={index} borderWidth="1px" borderRadius="md" p={3} mb={3}>
                <Grid templateColumns="repeat(4, 1fr)" gap={4}>
                  <DisplayField label="Person Designation:" value={person.designation} />
                  <DisplayField label="Full Name:" value={person.fullName} />
                  <DisplayField label="Email Address:" value={person.email} />
                  <DisplayField label="Mobile Number:" value={person.mobile} />
                </Grid>
              </Box>
            ))}
          </Box>
        )}
      </Box>

      {/* Qualification Details Section */}
      <Box
        border="1px solid"
        borderColor="gray.200"
        borderRadius="md"
        p={4}
        mb={6}
        bg="white"
      >
        <Flex justify="space-between" align="center" mb={4}>
          <Text fontSize="md" fontWeight="bold" color="green.600">
            Qualification Details:
          </Text>
          <Button size="sm" variant="ghost" colorPalette="blue">
            ✏ Edit
          </Button>
        </Flex>

        <Box mb={4}>
          <Text fontSize="sm" fontWeight="bold" color="orange.500" mb={3}>
            Diploma Courses:
          </Text>
          <Box overflowX="auto">
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ backgroundColor: "#f7f7f7" }}>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Sr. No</th>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Course Name</th>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Course Pattern</th>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Duration</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>1.</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Diploma in Agriculture</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Annual</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>2 Years</td>
                </tr>
                <tr>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>2.</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Diploma in Agriculture</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Semester</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>2 Years</td>
                </tr>
              </tbody>
            </table>
          </Box>
        </Box>

        <Box>
          <Text fontSize="sm" fontWeight="bold" color="orange.500" mb={3}>
            Under Graduate Courses:
          </Text>
          <Box overflowX="auto">
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ backgroundColor: "#f7f7f7" }}>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Sr. No</th>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Course Name</th>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Course Pattern</th>
                  <th style={{ padding: "8px", textAlign: "left", fontSize: "12px", borderBottom: "1px solid #ddd" }}>Duration</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>1.</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Diploma in Agriculture</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Annual</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>2 Years</td>
                </tr>
                <tr>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>2.</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Diploma in Agriculture</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>Semester</td>
                  <td style={{ padding: "8px", fontSize: "12px", borderBottom: "1px solid #eee" }}>2 Years</td>
                </tr>
              </tbody>
            </table>
          </Box>
        </Box>
      </Box>

      {/* Declaration Form */}
      <Box
        as="form"
        onSubmit={handleSubmit}
        bg="white"
        borderRadius="12px"
        p={{ base: 2, md: 4 }}
        boxShadow="sm"
        border="1px solid"
        borderColor="gray.100"
      >
        <Stack gap={3}>
          {/* Instruction Text */}
          <Text fontSize="sm" color="blue.600" mb={3}>
            {collegeDeclarationConfig.instructionText}
          </Text>

          <Flex gap={8} align="flex-start">
            {/* Left side - Declaration Text with Checkbox */}
            <Box flex={1}>
              {/* Declaration Points */}
              <Box mb={4}>
                {collegeDeclarationConfig.declarations.map((declaration, index) => (
                  <Text key={index} fontSize="sm" mb={2}>
                    {index + 1}. {declaration}
                  </Text>
                ))}
              </Box>

              {/* Acceptance Checkbox */}
              {collegeDeclarationConfig.acceptance.showCheckbox && (
                <Box>
                  <Flex gap={2} align="flex-start">
                    <label htmlFor="declaration-accept" className="declaration-label">
                      <input
                        id="declaration-accept"
                        type="checkbox"
                        checked={accepted}
                        onChange={(e) => {
                          setAccepted(e.target.checked);
                          setError(null);
                        }}
                        className="declaration-checkbox"
                        title="Accept declaration"
                      />
                      <Text as="span" fontSize="sm" color="green.700" ml={2}>
                        I accept the above declaration and affirm that all information
                        provided is true.
                      </Text>
                    </label>
                  </Flex>
                  {error && (
                    <Text color="red.500" fontSize="sm" mt={2}>
                      {error}
                    </Text>
                  )}
                </Box>
              )}
            </Box>

            {/* Right side - Signature Image */}
            <Box>
              <Text fontSize="sm" fontWeight="medium" mb={2}>
                Signature ({collegeDeclarationConfig.signatureLabel})
              </Text>
              <Box
                borderWidth={1}
                borderColor="gray.300"
                borderRadius="md"
                p={4}
                bg="gray.50"
                width="200px"
                height="100px"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                {photoSignData?.SignURL ? (
                  <Image
                    src={photoSignData.SignURL}
                    alt="Signature"
                    maxH="100%"
                    maxW="100%"
                    objectFit="contain"
                  />
                ) : (
                  <Image
                    src="/placeholder-signature.png"
                    alt="Signature Placeholder"
                    maxH="100%"
                    maxW="100%"
                    objectFit="contain"
                    opacity={0.5}
                  />
                )}
              </Box>
            </Box>
          </Flex>

          {/* Action Buttons */}
          <Flex gap={4} justify="space-between" mt={4}>
            <Button variant="outline" colorPalette="gray" type="button" onClick={() => onPrev?.()}>
              {collegeDeclarationConfig.previousButtonText}
            </Button>
            <Button colorPalette="orange" type="submit">
              {collegeDeclarationConfig.submitButtonText}
            </Button>
          </Flex>
        </Stack>
      </Box>
    </>
  );
}

