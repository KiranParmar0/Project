"use client";
import React, { useState } from "react";
import {
  Box,
  Flex,
  Text,
  Button,
  Stack,
  Table,
  Dialog,
  IconButton,
} from "@chakra-ui/react";
import { MdDelete } from "react-icons/md";
import DynamicForm, { FormSection } from "../../ui/DynamicForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../../ui/toaster";

interface Hostel {
  hostelName: string;
  hostelType: string;
  accommodationType: string;
  limit: string;
  fee: string;
}

interface HostelDetailsProps {
  defaultValues?: { hostels?: Hostel[] };
  onNext?: () => void;
  onPrev?: () => void;
}

export default function HostelDetails({
  defaultValues,
  onNext,
  onPrev,
}: HostelDetailsProps) {
  const [hostels, setHostels] = useState<Hostel[]>(
    defaultValues?.hostels || []
  );
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [hasHostel, setHasHostel] = useState<string>("yes");

  // tRPC Hooks
  const utils = trpc.useUtils();
  const { data: fetchedHostels, isLoading } = trpc.college.getHostelDetails.useQuery();
  const saveMutation = trpc.college.saveHostelDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Hostel details saved successfully",
        type: "success",
        duration: 3000,
      });
      utils.college.getHostelDetails.invalidate();
      utils.college.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save hostel details",
        type: "error",
        duration: 5000,
      });
    }
  });

  // Populate state from fetched data
  React.useEffect(() => {
    if (fetchedHostels) {
      if ((fetchedHostels as any)?.hostels && Array.isArray((fetchedHostels as any).hostels)) {
        setHostels((fetchedHostels as any).hostels);
      }
      if ((fetchedHostels as any)?.hasHostel) {
        setHasHostel((fetchedHostels as any).hasHostel);
      }
    }
  }, [fetchedHostels]);

  const hostelModalConfig: FormSection[] = [
    {
      title: "Hostel Information",
      fields: [
        {
          name: "hostelName",
          label: "Hostel Name",
          type: "text",
          placeholder: "Enter hostel name",
          required: true,
        },
        {
          name: "hostelType",
          label: "Hostel Type",
          type: "select",
          placeholder: "Select Type",
          required: true,
          options: [
            { value: "Type 1", label: "Type 1" },
            { value: "Type 2", label: "Type 2" },
            { value: "Type 3", label: "Type 3" },
          ],
        },
        {
          name: "accommodationType",
          label: "Accommodation Type",
          type: "select",
          placeholder: "Select Type",
          required: true,
          options: [
            { value: "Type 1", label: "Type 1" },
            { value: "Type 2", label: "Type 2" },
            { value: "Type 3", label: "Type 3" },
            { value: "Type 4", label: "Type 4" },
          ],
        },
        {
          name: "limit",
          label: "Limit",
          type: "text",
          placeholder: "Enter capacity",
          required: true,
          inputMode: "numeric",
          restrictInput: "numeric",
        },
        {
          name: "fee",
          label: "Fee",
          type: "text",
          placeholder: "Enter fee amount",
          required: true,
          inputMode: "numeric",
          restrictInput: "numeric",
        },
      ],
    },
  ];

  const handleAddHostel = (data: Record<string, any>) => {
    const newHostel: Hostel = {
      hostelName: data.hostelName,
      hostelType: data.hostelType,
      accommodationType: data.accommodationType,
      limit: data.limit,
      fee: data.fee,
    };

    if (editingIndex !== null) {
      const updated = [...hostels];
      updated[editingIndex] = newHostel;
      setHostels(updated);
      setEditingIndex(null);
    } else {
      setHostels([...hostels, newHostel]);
    }

    setIsModalOpen(false);
  };

  const handleDelete = (index: number) => {
    setHostels(hostels.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (hasHostel === "yes" && hostels.length === 0) {
      toaster.create({
        title: "Warning",
        description: "Please add at least one hostel",
        type: "warning",
        duration: 3000,
      });
      return;
    }

    const payload = {
      hasHostel,
      hostels: hasHostel === "yes" ? hostels : [],
    };

    toaster.create({
      title: "Success",
      description: "Hostel details saved (local only)",
      type: "success",
      duration: 2000,
    });
    onNext?.();

    // TODO: Uncomment when backend is ready
    // saveMutation.mutate(payload);
  };

  return (
    <>
      <Box as="form" onSubmit={handleSubmit} bg="white" borderRadius="lg" p={{ base: 2, md: 4 }} boxShadow="sm">
        <Stack gap={6}>
          {/* Radio Button for Hostel Availability */}
          <Box>
            <Text fontSize="md" fontWeight="600" color="orange.500" mb={3}>
              Hostel Details:
            </Text>
            <Text fontSize="sm" fontWeight={500} mb={2}>
              Does the college have hostel accommodation available? <Text as="span" color="red.500">*</Text>
            </Text>
            <Flex gap={6}>
              <Flex as="label" align="center" gap={2} cursor="pointer">
                <input
                  type="radio"
                  value="yes"
                  checked={hasHostel === "yes"}
                  onChange={(e) => setHasHostel(e.target.value)}
                  aria-label="Yes, hostel available"
                />
                <Text fontSize="sm">Yes</Text>
              </Flex>
              <Flex as="label" align="center" gap={2} cursor="pointer">
                <input
                  type="radio"
                  value="no"
                  checked={hasHostel === "no"}
                  onChange={(e) => setHasHostel(e.target.value)}
                  aria-label="No, hostel not available"
                />
                <Text fontSize="sm">No</Text>
              </Flex>
            </Flex>
          </Box>

          {/* Table Section - Only show if hasHostel is Yes */}
          {hasHostel === "yes" && (
            <>
              <Flex justify="space-between" align="center">
                <Text fontSize="sm" fontWeight={500}>
                  Hostel List
                </Text>
                <Button
                  size="sm"
                  bg="orange.500"
                  color="white"
                  _hover={{ bg: "orange.600" }}
                  disabled={isLoading || saveMutation.isPending}
                  onClick={() => {
                    setEditingIndex(null);
                    setIsModalOpen(true);
                  }}
                >
                  + Add New Hostel
                </Button>
              </Flex>

              {/* Table */}
              {hostels.length > 0 ? (
                <Box overflowX="auto">
                  <Table.Root size="sm" variant="line">
                    <Table.Header>
                      <Table.Row bg="gray.50">
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Sr. No</Table.ColumnHeader>
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Hostel Name</Table.ColumnHeader>
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Hostel Type</Table.ColumnHeader>
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Accommodation Type</Table.ColumnHeader>
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Limit</Table.ColumnHeader>
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Fee</Table.ColumnHeader>
                        <Table.ColumnHeader fontSize="sm" fontWeight={600}>Delete</Table.ColumnHeader>
                      </Table.Row>
                    </Table.Header>
                    <Table.Body>
                      {hostels.map((hostel, index) => (
                        <Table.Row key={index}>
                          <Table.Cell>{index + 1}</Table.Cell>
                          <Table.Cell>{hostel.hostelName}</Table.Cell>
                          <Table.Cell>{hostel.hostelType}</Table.Cell>
                          <Table.Cell>{hostel.accommodationType}</Table.Cell>
                          <Table.Cell>{hostel.limit}</Table.Cell>
                          <Table.Cell>{hostel.fee}/ Month</Table.Cell>
                          <Table.Cell>
                            <IconButton
                              size="xs"
                              variant="ghost"
                              colorPalette="red"
                              onClick={() => handleDelete(index)}
                              aria-label="Delete hostel"
                            >
                              <MdDelete size={16} />
                            </IconButton>
                          </Table.Cell>
                        </Table.Row>
                      ))}
                    </Table.Body>
                  </Table.Root>
                </Box>
              ) : (
                <Box
                  p={8}
                  textAlign="center"
                  borderWidth="1px"
                  borderStyle="dashed"
                  borderColor="gray.300"
                  borderRadius="md"
                >
                  <Text color="gray.500" fontSize="sm">
                    {isLoading ? "Loading hostels..." : "No hostels added yet. Click 'Add New Hostel' to get started."}
                  </Text>
                </Box>
              )}
            </>
          )}

          {/* Footer Buttons */}
          <Box borderTop="1px solid" borderColor="gray.200" pt={6} mt={2}>
            <Flex justify="space-between" align="center">
              <Button
                variant="outline"
                size="md"
                borderColor="gray.300"
                color="gray.700"
                onClick={() => onPrev?.()}
              >
                Previous
              </Button>
              <Button
                type="submit"
                size="md"
                bg="black"
                color="white"
                loading={saveMutation.isPending}
                _hover={{ bg: "gray.800" }}
              >
                Save & Next
              </Button>
            </Flex>
          </Box>
        </Stack>
      </Box>

      {/* Add/Edit Hostel Modal */}
      <Dialog.Root
        open={isModalOpen}
        onOpenChange={(details: any) => setIsModalOpen(!!details?.open)}
        placement="center"
        size="lg"
      >
        <Dialog.Backdrop />
        <Dialog.Positioner>
          <Dialog.Content>
            <Dialog.Header>
              <Dialog.Title>
                {editingIndex !== null ? "Edit Hostel" : "Add New Hostel"}
              </Dialog.Title>
              <Dialog.CloseTrigger />
            </Dialog.Header>
            <Dialog.Body>
              <DynamicForm
                sections={hostelModalConfig}
                onSubmit={handleAddHostel}
                submitButtonText={editingIndex !== null ? "Update Hostel" : "Add Hostel"}
                cancelButtonText="Cancel"
                showPreviousButton={false}
                defaultValues={
                  editingIndex !== null ? hostels[editingIndex] : undefined
                }
              />
            </Dialog.Body>
          </Dialog.Content>
        </Dialog.Positioner>
      </Dialog.Root>
    </>
  );
}

