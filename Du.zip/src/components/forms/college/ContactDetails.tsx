"use client";

import { useEffect, useState } from "react";
import DynamicForm from "../../ui/DynamicForm";
import { collegeContactDetailsConfig } from "@/config/forms/collegeRegistrationDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../../ui/toaster";

export default function ContactDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [initialValues, setInitialValues] = useState<Record<string, any>>({
    mobileNumbers: [""],
    landlineNumbers: [""],
  });
  const [formKey, setFormKey] = useState(0);
  const [initialSectionCounts, setInitialSectionCounts] = useState<Record<number, number>>({});
  const utils = trpc.useUtils();

  const { data: existingData, isLoading } = trpc.college.getContactDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  const saveContactDetails = trpc.college.saveContactDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Contact details saved successfully",
        type: "success",
        duration: 3000,
      });
      utils.college.getContactDetails.invalidate();
      utils.college.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save contact details",
        type: "error",
        duration: 5000,
      });
    },
  });

  useEffect(() => {
    if (existingData && typeof existingData === 'object') {
      const formattedData: any = {
        ...(existingData as Record<string, any>),
        mobileNumbers: (existingData as any)?.mobileNumbers || [""],
        landlineNumbers: (existingData as any)?.landlineNumbers || [""],
      };
      
      // Load contact persons into repeatable fields
      const contactPersons = (existingData as any)?.contactPersons || [];
      contactPersons.forEach((person: any, index: number) => {
        formattedData[`designation_${index}`] = person.designation;
        formattedData[`contactPersonName_${index}`] = person.fullName;
        formattedData[`contactPersonEmail_${index}`] = person.email;
        formattedData[`contactPersonMobile_${index}`] = person.mobile;
      });
      
      // Set the initial section count for the repeatable section (index 2 is Contact Person Details)
      if (contactPersons.length > 0) {
        setInitialSectionCounts({ 2: contactPersons.length });
      }
      
      setInitialValues(formattedData);
      setFormKey(prev => prev + 1);
    }
  }, [existingData]);

  const handleSubmit = async (data: any) => {
    console.log("Contact details submitted:", data);

    // Collect contact persons from repeatable fields
    const contactPersons: any[] = [];
    let instanceIndex = 0;
    while (data[`designation_${instanceIndex}`] !== undefined) {
      contactPersons.push({
        designation: data[`designation_${instanceIndex}`],
        fullName: data[`contactPersonName_${instanceIndex}`],
        email: data[`contactPersonEmail_${instanceIndex}`],
        mobile: data[`contactPersonMobile_${instanceIndex}`],
      });
      instanceIndex++;
    }

    const fullData = {
      email: data.email,
      mobileNumber: data.mobileNumber,
      faxNumber: data.faxNumber,
      webUrl: data.webUrl,
      mobileNumbers: data.mobileNumbers?.filter((n: string) => n.trim()) || [],
      landlineNumbers: data.landlineNumbers?.filter((n: string) => n.trim()) || [],
      contactPersons,
    };

    console.log("Full contact data with persons:", fullData);

    toaster.create({
      title: "Success",
      description: "Contact details saved (local only)",
      type: "success",
      duration: 2000,
    });
    onNext?.();
    
    // TODO: Uncomment when backend is ready
    // saveContactDetails.mutate(fullData);
  };

  if (isLoading) return <div>Loading...</div>;

  return (
    <DynamicForm
      key={formKey}
      sections={collegeContactDetailsConfig}
      onSubmit={handleSubmit}
      defaultValues={initialValues}
      initialRepeatableSectionCounts={initialSectionCounts}
      submitButtonText="Save & Next"
      isSubmitting={saveContactDetails.isPending}
      previousButton={{
        label: "Previous",
        onClick: onPrev || (() => {}),
      }}
    />
  );
}

