"use client";

import { useEffect, useState } from "react";
import DynamicForm from "../../ui/DynamicForm";
import { personalDetailsConfig } from "@/config/forms/collegeRegistrationDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../../ui/toaster";

export default function BasicDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [initialValues, setInitialValues] = useState<Record<string, any>>({});
  const [formKey, setFormKey] = useState(0);
  const utils = trpc.useUtils();

  // Fetch existing basic details from database
  const { data: existingData, isLoading } = trpc.college.getBasicDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // Save basic details mutation
  const saveBasicDetails = trpc.college.saveBasicDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Basic details saved successfully",
        type: "success",
        duration: 3000,
      });
      utils.college.getBasicDetails.invalidate();
      utils.college.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save basic details",
        type: "error",
        duration: 5000,
      });
    },
  });

  useEffect(() => {
    if (existingData) {
      const mappedData: any = {
        firstName: (existingData as any).firstName || "",
        middleName: (existingData as any).middleName || "",
        lastName: (existingData as any).lastName || "",
        fullName: (existingData as any).fullName || "",
        gender: (existingData as any).gender || "",
        dob: (existingData as any).dob || "",
        bloodGroup: (existingData as any).bloodGroup || "",
        fatherName: (existingData as any).fatherName || "",
        fatherOccupation: (existingData as any).fatherOccupation || "",
        motherName: (existingData as any).motherName || "",
        motherOccupation: (existingData as any).motherOccupation || "",
        annualIncome: (existingData as any).annualIncome || "",
        motherTongue: (existingData as any).motherTongue || "",
        aadharNumber: (existingData as any).aadharNumber || "",
        abcId: (existingData as any).abcId || "",
        emailAddress: (existingData as any).emailAddress || "",
        mobileNumber: (existingData as any).mobileNumber || "",
        whatsappNumber: (existingData as any).whatsappNumber || "",
      };
      setInitialValues(mappedData);
      setFormKey(prev => prev + 1);
    }
  }, [existingData]);

  const handleSubmit = (data: Record<string, any>) => {
    // Skip backend save for now - just proceed to next step
    console.log('Basic Details Form Data:', data);
    toaster.create({
      title: "Success",
      description: "Basic details saved (local only)",
      type: "success",
      duration: 2000,
    });
    onNext?.();
    
    // TODO: Uncomment when backend is ready
    // saveBasicDetails.mutate(data);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <DynamicForm
      key={formKey}
      sections={personalDetailsConfig}
      onSubmit={handleSubmit}
      defaultValues={initialValues}
      submitButtonText="Save & Next"
      isSubmitting={saveBasicDetails.isPending}
      previousButton={{
        label: "Previous",
        onClick: onPrev || (() => {}),
      }}
    />
  );
}
