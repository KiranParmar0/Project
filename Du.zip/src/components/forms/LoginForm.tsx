"use client";
import React, { useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import { signIn, useSession } from "next-auth/react";
import { Toaster, toaster } from "../ui/toaster";
import NextImage from 'next/image';
import Logo from '../../assets/logo.png';
import {
  Box,
  Stack,
  Input,
  Button,
  Text,
  Link,
  Center,
  HStack,
  VStack,
  Spinner,
} from "@chakra-ui/react";
import {
  FormControl,
  FormErrorMessage,
  FormLabel,
} from "@chakra-ui/form-control";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import VisualCaptcha from "@/components/ui/VisualCaptcha";

const EyeIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

const EyeOffIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);

const RefreshIcon = () => (
  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
    <polyline points="23 4 23 10 17 10" />
    <path d="M20.49 15a9 9 0 1 1-2-8.83" />
  </svg>
);

const LoginSchema = z.object({
  email: z.string().min(1, "Email or College code is required"),
  password: z.string().min(1, "Password is required"),
  captcha: z.string().min(1, "Captcha is required"),
});

type LoginFormType = z.infer<typeof LoginSchema>;

type LoginFormLabels = {
  title?: string;
  emailLabel?: string;
  emailPlaceholder?: string;
  passwordLabel?: string;
  passwordPlaceholder?: string;
  captchaLabel?: string;
  loginButtonLabel?: string;
  forgotPasswordHref?: string;
  signupHref?: string;
};

type LoginFormProps = {
  labels?: LoginFormLabels;
  onSubmit?: (data: LoginFormType) => Promise<void> | void;
};

export default function LoginForm({ labels, onSubmit }: LoginFormProps) {
  const router = useRouter();
  const { data: session, status } = useSession();
  const [showPassword, setShowPassword] = useState(false);
  const [captcha, setCaptcha] = useState(generateCaptcha());
  const pathname = usePathname();
  const isCollegeLogin =
    !!pathname && (pathname.includes("college-login") || pathname.includes("college-signin"));

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
    getValues,
    setValue,
    watch,
  } = useForm<LoginFormType>({
    resolver: zodResolver(LoginSchema),
    defaultValues: {
      email: "",
      password: "",
      captcha: "",
    },
  });

  if (status === "loading" || status === "authenticated") {
    return (
      <Center minH="100vh">
        <Spinner size="xl" color="blue.500" />
      </Center>
    );
  }

  const refreshCaptcha = () => {
    setCaptcha(generateCaptcha());
  };

  const submit = async (data: LoginFormType) => {
    try {
      // Validate captcha
      if (data.captcha.toUpperCase() !== captcha.toUpperCase()) {
        toaster.create({
          title: "Invalid Captcha",
          description: "Please enter the correct captcha",
          type: "error",
          duration: 5000,
        });
        setValue("captcha", "");
        refreshCaptcha();
        return;
      }

      if (onSubmit) {
        await onSubmit(data);
      } else {
        // Default behavior: Use NextAuth signIn
        const result = await signIn("credentials", {
          email: data.email,
          password: data.password,
          redirect: false,
        });

        if (result?.error) {
          toaster.create({
            title: "Login failed",
            description: result.error,
            type: "error",
            duration: 5000,
          });

          // Refresh captcha on failed login
          setValue("captcha", "");
          refreshCaptcha();
          return;
        }

        if (result?.ok) {
          toaster.create({
            title: "Login successful",
            description: "Welcome back!",
            type: "success",
            duration: 3000,
          });

          router.replace("/dashboard");
        }
      }
    } catch (err: any) {
      console.error("[LOGIN ERROR]", err);
      toaster.create({
        title: "Network error",
        description: "Unable to connect to server. Please try again.",
        type: "error",
        duration: 5000,
      });

      // Refresh captcha on error
      setValue("captcha", "");
      refreshCaptcha();
    }
  }; return (
    <Center>
      <Toaster />
      <Box w="full" maxW="520px" px={6}>
        <Stack gap={6}>
          <Center>
              <NextImage src={Logo} alt="logo" width={110} height={32} />
          </Center>

            <Text fontSize="16px" fontWeight={700} textAlign="center" lineHeight={1.5}>
              {labels?.title ?? "Vasantrao Naik Marathwada Krishi Vidyapeeth,\nParbhani - 431 402 (Maharashtra)"}
            </Text>

          <Box as="form" width="100%" onSubmit={handleSubmit(submit)}>
            <Stack gap={4}>
              <FormControl isInvalid={!!errors.email}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>{labels?.emailLabel ?? "Email Address"}</FormLabel>
                <Input
                  type={isCollegeLogin ? "text" : "email"}
                  placeholder={
                    labels?.emailPlaceholder ?? (isCollegeLogin ? "College Code *" : "Email Address *")
                  }
                  borderRadius="25px"
                  {...register("email")}
                />
                <FormErrorMessage>{errors.email?.message}</FormErrorMessage>
              </FormControl>

              <FormControl isInvalid={!!errors.password}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>{labels?.passwordLabel ?? "Password"}</FormLabel>
                <Box position="relative">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Password *"
                    borderRadius="25px"
                    pr="40px"
                    {...register("password")}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((s) => !s)}
                    style={{
                      position: "absolute",
                      right: "12px",
                      top: "50%",
                      transform: "translateY(-50%)",
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      color: "#999",
                      padding: 0,
                    }}
                  >
                    {showPassword ? <EyeOffIcon /> : <EyeIcon />}
                  </button>
                </Box>
                <FormErrorMessage>{errors.password?.message}</FormErrorMessage>
              </FormControl>

              <FormControl isInvalid={!!errors.captcha}>

                <VStack gap={3} align="stretch">
                  <Stack direction={{ base: "column", sm: "row" }} gap={3} align="center" justifyContent="space-around">
                    <Box flex="1" maxW={{ base: "100%", sm: "240px" }}>
                      <VisualCaptcha
                        captchaText={captcha}
                        width={240}
                        height={40}
                      />
                    </Box>
                    <Button
                      type="button"
                      onClick={refreshCaptcha}
                      variant="ghost"
                      size="sm"
                      color="green.700"
                      _hover={{ bg: "green.50" }}
                      width={{ base: "100%", sm: "auto" }}
                    >
                      <HStack gap={1}>
                        <RefreshIcon />
                        <Text>Refresh Captcha </Text>
                      </HStack>
                    </Button>
                  </Stack>
                </VStack>
              </FormControl>

              <FormControl isInvalid={!!errors.captcha}>
                <FormLabel fontSize="sm" fontWeight={600} mb={2}>{labels?.captchaLabel ?? "Enter Captcha"}</FormLabel>
                <Input
                  placeholder="Enter Captcha *"
                  borderRadius="25px"
                  {...register("captcha")}
                  value={watch("captcha") ?? ""}
                  onChange={(e) => setValue("captcha", (e.target as HTMLInputElement).value.toUpperCase(), { shouldValidate: true, shouldDirty: true })}
                  inputMode="text"
                  autoComplete="off"
                />
                <FormErrorMessage>{errors.captcha?.message}</FormErrorMessage>
              </FormControl>

              <Button
                borderRadius="full"
                bgColor="green.700"
                color="white"
                _hover={{ bg: "green.800" }}
                type="submit"
                width="100%"
                loading={isSubmitting}
                height="48px"
              >
                {labels?.loginButtonLabel ?? "Log In"}
              </Button>

              <Center>
                <Link href={labels?.forgotPasswordHref ?? "/auth/forgot/options"} color="gray.600" fontSize="sm">
                  {"Forgot Password?"}
                </Link>
              </Center>

              {!isCollegeLogin && (
                <Center>
                  <Text fontSize="sm">
                    Don&apos;t have an Account?{' '}
                    <Link href={labels?.signupHref ?? "/auth/signup"} color="red.500" fontWeight={600}>
                      Register Here
                    </Link>
                  </Text>
                </Center>
              )}
            </Stack>
          </Box>
        </Stack>
      </Box>
    </Center>
  );
}

function generateCaptcha(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}
