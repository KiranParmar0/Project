"use client";
import React, { useState, useEffect } from "react";
import {
  Box,
  Stack,
  Button,
  Text,
  Flex,
  Table,
  Separator,
  Spinner,
} from "@chakra-ui/react";
import { MdFileUpload, MdClose, MdCheckCircle, MdVisibility } from "react-icons/md";
import { documentDetailsConfig } from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "@/components/ui/toaster";

type DocumentItem = {
  id: number; // DocumentID
  name: string;
  isRequired: boolean;
  fileType: string;
  file: File | null;
  error?: string | null;
  isUploaded: boolean;
  docUrl?: string; // Existing URL
};

const MAX_FILE_SIZE = documentDetailsConfig.validation.maxFileSizeBytes;
const ALLOWED_TYPES = documentDetailsConfig.validation.allowedTypes;

export default function DocumentDetails({
  onNext,
  onPrev,
}: {
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [documents, setDocuments] = useState<DocumentItem[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Fetch Master Documents
  const { data: masterDocs, isLoading: isLoadingMaster } = trpc.master.getDocuments.useQuery();

  // Fetch Uploaded Documents
  const { data: uploadedDocs, isLoading: isLoadingUploaded, refetch: refetchUploaded } = trpc.student.getRequiredDocuments.useQuery();

  const uploadMutation = trpc.student.uploadDocument.useMutation();

  // Combine Data
  useEffect(() => {
    if (masterDocs) {
      const merged: DocumentItem[] = masterDocs.map((md) => {
        const existing = uploadedDocs?.find((ud) => ud.documentId === md.id);

        // Preserve current file selection if any, when re-merging (though usually we won't re-merge often unless data changes)
        // Ideally we only initialize once or when relevant data changes.
        // For simplicity, we'll reset file selection if master docs reload, but we should be careful.
        // Better: Find if we already have this doc in state.
        const currentInState = documents.find(d => d.id === md.id);

        return {
          id: md.id,
          name: md.name,
          isRequired: md.isRequired ?? false,
          fileType: md.fileType,
          file: currentInState?.file || null,
          error: currentInState?.error || null,
          isUploaded: !!existing?.isUploaded,
          docUrl: existing?.docUrl || undefined,
        };
      });
      setDocuments(merged);
    }
  }, [masterDocs, uploadedDocs]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
    });
  };

  const handleFileUpload = (docId: number) => {
    const docConfig = documents.find((d) => d.id === docId);
    if (!docConfig) return;

    const input = document.createElement("input");
    input.type = "file";
    // input.accept = docConfig.fileType; // Use types from DB or config
    input.accept = ALLOWED_TYPES.join(",");

    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      // Validate file type
      if (!ALLOWED_TYPES.includes(file.type)) {
        setDocuments((prev) =>
          prev.map((doc) =>
            doc.id === docId
              ? { ...doc, error: "Only PDF/JPG/PNG files are allowed" }
              : doc
          )
        );
        return;
      }

      // Validate file size
      if (file.size > MAX_FILE_SIZE) {
        setDocuments((prev) =>
          prev.map((doc) =>
            doc.id === docId
              ? {
                ...doc,
                error: `File too large. Max ${MAX_FILE_SIZE / 1024 / 1024} MB`,
              }
              : doc
          )
        );
        return;
      }

      // Set file
      setDocuments((prev) =>
        prev.map((doc) =>
          doc.id === docId ? { ...doc, file, error: null } : doc
        )
      );
    };

    input.click();
  };

  const handleRemoveFile = (docId: number) => {
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === docId ? { ...doc, file: null, error: null } : doc
      )
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate required documents
    const hasErrors = documents.some((doc) => {
      // Required if marked required AND (not uploaded AND no file selected)
      return doc.isRequired && !doc.isUploaded && !doc.file;
    });

    if (hasErrors) {
      setDocuments((prev) =>
        prev.map((doc) => {
          if (doc.isRequired && !doc.isUploaded && !doc.file) {
            return { ...doc, error: `${doc.name} is required` };
          }
          return doc;
        })
      );
      toaster.create({
        title: "Validation Error",
        description: "Please upload all required documents",
        type: "error",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Find docs that have new files
      const filesToUpload = documents.filter(d => d.file);

      // Upload sequentially or parallel
      for (const doc of filesToUpload) {
        if (!doc.file) continue;
        const base64 = await fileToBase64(doc.file);
        await uploadMutation.mutateAsync({
          documentId: doc.id,
          fileBase64: base64,
          fileName: doc.file.name,
        });
      }

      toaster.create({
        title: "Success",
        description: "Documents saved successfully",
        type: "success",
      });

      // Refetch to ensure state is synced
      await refetchUploaded();

      onNext?.();
    } catch (error) {
      console.error("Upload error:", error);
      toaster.create({
        title: "Error",
        description: "Failed to upload documents. Please try again.",
        type: "error",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoadingMaster || isLoadingUploaded) {
    return <Flex justify="center" p={10}><Spinner /></Flex>;
  }

  return (
    <Box as="form" onSubmit={handleSubmit} bg="white" borderRadius="lg" p={6} boxShadow="sm">
      <Stack gap={3}>
        {/* Title */}
        <Text fontSize="md" fontWeight="600" color="orange.500" mb={0}>
          {documentDetailsConfig.title}
        </Text>

        <Separator mt={0} mb={4} />

        {/* Instructions */}
        <Box>
          {documentDetailsConfig.instructions.map((instruction, index) => (
            <Text key={index} fontSize="sm" color="blue.600" mb={1}>
              {index + 1}. {instruction}
            </Text>
          ))}
        </Box>

        {/* Document Table */}
        <Box overflowX="auto">
          <Table.Root size="sm" variant="outline">
            <Table.Header>
              <Table.Row bg="gray.50">
                <Table.ColumnHeader fontSize="sm" fontWeight={600} color="gray.700">
                  {documentDetailsConfig.tableHeaders.documentName}
                </Table.ColumnHeader>
                <Table.ColumnHeader fontSize="sm" fontWeight={600} color="gray.700">
                  {documentDetailsConfig.tableHeaders.fileType}
                </Table.ColumnHeader>
                <Table.ColumnHeader fontSize="sm" fontWeight={600} color="gray.700" textAlign="right">
                  {documentDetailsConfig.tableHeaders.uploadedFile}
                </Table.ColumnHeader>
              </Table.Row>
            </Table.Header>
            <Table.Body>
              {documents.map((doc) => (
                <Table.Row key={doc.id}>
                  <Table.Cell fontSize="sm" color="gray.700">
                    <Flex align="center" gap={2}>
                      {doc.name}
                      {doc.isRequired && <Text color="red.500">*</Text>}
                    </Flex>
                  </Table.Cell>
                  <Table.Cell fontSize="sm" color="green.600">
                    {doc.fileType}
                  </Table.Cell>
                  <Table.Cell textAlign="right">
                    <Flex align="center" justify="flex-end" gap={2}>
                      {/* If uploaded on server */}
                      {doc.isUploaded && !doc.file && (
                        <Button
                          size="xs"
                          variant="subtle"
                          colorPalette="blue"
                          onClick={() => {
                            if (doc.docUrl) window.open(doc.docUrl, "_blank");
                          }}
                        >
                          <MdVisibility /> View Uploaded
                        </Button>
                      )}

                      {/* If new file selected */}
                      {doc.file && (
                        <Text fontSize="xs" color="blue.600" truncate maxW="150px">
                          {doc.file.name}
                        </Text>
                      )}

                      {/* Remove selected file button */}
                      {doc.file && (
                        <Button
                          size="xs"
                          variant="ghost"
                          colorPalette="red"
                          onClick={() => handleRemoveFile(doc.id)}
                          p={1}
                        >
                          <MdClose />
                        </Button>
                      )}

                      {/* Upload button (if not selected) */}
                      {!doc.file && (
                        <Button
                          size="sm"
                          variant={doc.isUploaded ? "ghost" : "outline"}
                          onClick={() => handleFileUpload(doc.id)}
                          borderColor={doc.isUploaded ? "transparent" : "gray.300"}
                        >
                          <MdFileUpload /> {doc.isUploaded ? "Replace" : "Upload"}
                        </Button>
                      )}
                    </Flex>
                    {doc.error && (
                      <Text color="red.500" fontSize="xs" mt={1}>
                        {doc.error}
                      </Text>
                    )}
                  </Table.Cell>
                </Table.Row>
              ))}
            </Table.Body>
          </Table.Root>
        </Box>

        {/* Footer Buttons */}
        <Box borderTop="1px solid" borderColor="gray.200" pt={6} mt={4}>
          <Flex justify="space-between" align="center">
            <Button
              variant="outline"
              size="md"
              borderColor="gray.300"
              color="gray.700"
              onClick={() => onPrev?.()}
              disabled={isSubmitting}
            >
              Previous
            </Button>
            <Button
              type="submit"
              size="md"
              bg="black"
              color="white"
              _hover={{ bg: "gray.800" }}
              loading={isSubmitting}
            >
              Save & Next
            </Button>
          </Flex>
        </Box>
      </Stack>
    </Box>
  );
}
