"use client";
import React, { useState, useEffect } from "react";
import { Box, Stack, Input, Button, Text, VStack, Center, Flex } from "@chakra-ui/react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { FormControl, FormLabel, FormErrorMessage } from "@chakra-ui/form-control";
import NextImage from 'next/image';
import { FaArrowLeft, FaChevronDown } from "react-icons/fa";
import Logo from '../../assets/logo.png';

import { Toaster, toaster } from "../ui/toaster";
import { trpc } from "@/lib/trpc";

export default function ForgotSecurityQuestion({
  question = "What is your pet's name?",
  onVerified,
}: {
  question?: string;
  onVerified?: () => void;
}) {
  const router = useRouter();
  const { register, handleSubmit, formState: { isSubmitting } } = useForm<{ email: string; question: string; answer: string }>({
    defaultValues: { email: "", question: "", answer: "" }
  });

  const { data: questions = [], isLoading: isLoadingQuestions } = trpc.master.getSecurityQuestions.useQuery();
  const verifySecurityMutation = trpc.auth.verifySecurityQuestion.useMutation();

  const submit = async (vals: { email: string; question: string; answer: string }) => {
    if (!vals.email) {
      toaster.create({
        title: "Email is required",
        type: "error",
        duration: 3000,
      });
      return;
    }

    if (!vals.question) {
      toaster.create({
        title: "Please select a security question",
        type: "error",
        duration: 3000,
      });
      return;
    }

    if (!vals.answer) {
      toaster.create({
        title: "Please enter your answer",
        type: "error",
        duration: 3000,
      });
      return;
    }

    try {
      const result = await verifySecurityMutation.mutateAsync({
        email: vals.email,
        questionId: Number(vals.question),
        answer: vals.answer
      });

      toaster.create({
        title: "Verification successful",
        type: "success",
        duration: 3000,
      });

      onVerified?.();

      // Store reset token and redirect to reset password page
      sessionStorage.setItem("resetToken", result.resetToken);
      router.push("/auth/reset");
    } catch (err: any) {
      toaster.create({
        title: "Verification failed",
        description: err?.message || "Invalid security answer",
        type: "error",
        duration: 5000,
      });
    }
  };

  return (
    <Center  >
      <Toaster />
      <Box w="full" maxW="520px" px={6}>
        <Stack gap={6}>
          <Center>
            <NextImage src={Logo} alt="logo" width={110} height={32} />
          </Center>

          <Text fontSize="16px" fontWeight={700} textAlign="center" lineHeight={1.5}>
            Vasantrao Naik Marathwada Krishi Vidyapeeth,
            <br />
            Parbhani - 431 402 (Maharashtra)
          </Text>

          <Box as="form" width="100%" onSubmit={handleSubmit(submit)}>
            <VStack gap={6} mt={4}>
              {/* Title */}
              <Text fontSize="24px" fontWeight={700} textAlign="center">
                Forgot your Password?
              </Text>

              {/* Description */}
              <Text fontSize="14px" color="gray.600" textAlign="center" lineHeight={1.6}>
                Select how you&apos;d like to reset your password: receive an OTP on your registered email or answer your security question.
              </Text>

              <Stack gap={4} width="100%">
                <FormControl>
                  <Input
                    {...register("email")}
                    type="email"
                    placeholder="Email Address *"
                    borderRadius="full"
                    height="48px"
                    width="100%"
                  />
                </FormControl>

                <FormControl position="relative">
                  <FormLabel htmlFor="security-question" srOnly>Security Question</FormLabel>
                  <Box position="relative">
                    <select
                      {...register("question")}
                      id="security-question"
                      aria-label="Security Question"
                      title="Security Question"
                      style={{
                        borderRadius: "25px",
                        height: "48px",
                        width: "100%",
                        paddingLeft: "16px",
                        paddingRight: "48px",
                        borderWidth: "1px",
                        borderStyle: "solid",
                        borderColor: "#e2e8f0",
                        backgroundColor: "white",
                        cursor: "pointer",
                        fontSize: "16px",
                        appearance: "none",
                        WebkitAppearance: "none",
                        MozAppearance: "none",
                        outline: "none",
                      }}
                      onFocus={(e) => {
                        e.target.style.borderColor = "#2d7a3e";
                        e.target.style.boxShadow = "0 0 0 1px #2d7a3e";
                      }}
                      onBlur={(e) => {
                        e.target.style.borderColor = "#e2e8f0";
                        e.target.style.boxShadow = "none";
                      }}
                    >
                      <option value="">
                        {isLoadingQuestions ? "Loading questions..." : "Select Security Question"}
                      </option>
                      {questions.map((q: any) => (
                        <option key={q.id} value={q.id}>
                          {q.question}
                        </option>
                      ))}
                    </select>
                    <Box
                      position="absolute"
                      right="16px"
                      top="50%"
                      transform="translateY(-50%)"
                      pointerEvents="none"
                      color="gray.500"
                    >
                      <FaChevronDown size={14} />
                    </Box>
                  </Box>
                </FormControl>

                <FormControl>
                  <Input
                    {...register("answer")}
                    placeholder="Security Answer *"
                    borderRadius="full"
                    height="48px"
                    width="100%"
                  />
                </FormControl>

                <Button
                  type="submit"
                  borderRadius="full"
                  bgColor="green.700"
                  color="white"
                  _hover={{ bg: "green.800" }}
                  height="48px"
                  width="100%"
                  fontSize="16px"
                  fontWeight={500}
                  loading={isSubmitting}
                >
                  Verify
                </Button>

                <Button
                  onClick={() => router.push("/auth/signin")}
                  variant="ghost"
                  color="green.700"
                  fontWeight={500}
                  _hover={{ bg: "green.50" }}
                >
                  <Flex align="center" gap={2}>
                    <FaArrowLeft size={16} />
                    <Text>Back to Login Page</Text>
                  </Flex>
                </Button>
              </Stack>
            </VStack>
          </Box>
        </Stack>
      </Box>
    </Center>
  );
}
