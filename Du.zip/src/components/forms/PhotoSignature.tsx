"use client";
import React, { useState, useEffect } from "react";
import {
  Box,
  Stack,
  Button,
  Image,
  Text,
  Flex,
  HStack,
  Separator,
} from "@chakra-ui/react";
import { MdFileUpload } from "react-icons/md";
import { toaster } from "@/components/ui/toaster";
import { photoSignConfig } from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";

type FormValues = {
  photo?: File | null;
  signature?: File | null;
  confirmation: boolean;
};

const MAX_SIZE_BYTES = photoSignConfig.photo.maxSizeKB * 1024;
const ALLOWED_TYPES = photoSignConfig.photo.acceptedFormats;

export default function PhotoSignature({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: { photo?: File | null; signature?: File | null; confirmation?: boolean };
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [photoFile, setPhotoFile] = useState<File | null>(defaultValues?.photo || null);
  const [signatureFile, setSignatureFile] = useState<File | null>(defaultValues?.signature || null);
  const [photoPreview, setPhotoPreview] = useState<string | null>(
    defaultValues?.photo ? URL.createObjectURL(defaultValues.photo) : null
  );
  const [signaturePreview, setSignaturePreview] = useState<string | null>(
    defaultValues?.signature ? URL.createObjectURL(defaultValues.signature) : null
  );
  const [confirmation, setConfirmation] = useState(defaultValues?.confirmation || false);
  const [errors, setErrors] = useState<{ photo?: string; signature?: string; confirmation?: string }>({});
  const [isLoading, setIsLoading] = useState(false);

  // Fetch existing photo/signature data
  const { data: existingData } = trpc.student.getPhotoSignDetails.useQuery();
  const savePhotoSign = trpc.student.savePhotoSign.useMutation();

  // Load existing images if available
  useEffect(() => {
    if (existingData && !photoPreview) {
      if (existingData.PhotoURL) {
        setPhotoPreview(existingData.PhotoURL);
      }
      if (existingData.SignURL) {
        setSignaturePreview(existingData.SignURL);
      }
    }
  }, [existingData, photoPreview, signaturePreview]);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        // Remove the data URL prefix to get just the base64 string
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
    });
  };

  const handleFileUpload = (kind: "photo" | "signature") => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ALLOWED_TYPES.join(",");

    input.onchange = async (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (!file) return;

      // Clear previous error
      setErrors((prev) => ({ ...prev, [kind]: undefined }));

      // Validate file type
      if (!ALLOWED_TYPES.includes(file.type)) {
        setErrors((prev) => ({ ...prev, [kind]: "Only JPG/JPEG/PNG files are allowed" }));
        return;
      }

      // Validate file size
      if (file.size > MAX_SIZE_BYTES) {
        setErrors((prev) => ({ ...prev, [kind]: `File must be ${photoSignConfig.photo.maxSizeKB} KB or smaller` }));
        return;
      }

      // Set file and preview
      const preview = URL.createObjectURL(file);
      if (kind === "photo") {
        setPhotoFile(file);
        setPhotoPreview(preview);
      } else {
        setSignatureFile(file);
        setSignaturePreview(preview);
      }
    };

    input.click();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate confirmation
    if (photoSignConfig.confirmation.required && !confirmation) {
      setErrors((prev) => ({ ...prev, confirmation: "Please confirm that the uploaded files are correct" }));
      return;
    }

    // Validate that at least one file is provided
    if (!photoFile && !signatureFile) {
      toaster.create({
        title: "Validation Error",
        description: "Please upload at least a photo or signature",
        type: "error",
        duration: 3000,
      });
      return;
    }

    setIsLoading(true);

    try {
      let photoBase64: string | undefined;
      let photoName: string | undefined;
      let signatureBase64: string | undefined;
      let signatureName: string | undefined;

      // Convert files to base64
      if (photoFile) {
        photoBase64 = await fileToBase64(photoFile);
        photoName = photoFile.name;
      }

      if (signatureFile) {
        signatureBase64 = await fileToBase64(signatureFile);
        signatureName = signatureFile.name;
      }

      // Call tRPC mutation
      await savePhotoSign.mutateAsync({
        photoBase64,
        photoName,
        signatureBase64,
        signatureName,
      });

      toaster.create({
        title: "Success",
        description: "Photo and signature uploaded successfully",
        type: "success",
        duration: 3000,
      });

      onNext?.();
    } catch (error) {
      console.error("Error uploading files:", error);
      toaster.create({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to upload files",
        type: "error",
        duration: 3000,
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Box as="form" onSubmit={handleSubmit} bg="white" borderRadius="lg" p={6} boxShadow="sm">
      <Stack gap={3}>
        {/* Title */}
        <Text fontSize="md" fontWeight="600" color="orange.500" mb={0}>
          {photoSignConfig.title}
        </Text>

        <Separator mt={0} mb={4} />

        {/* Photo and Signature Upload Section */}
        <HStack gap={8} align="flex-start">
          {/* Photo Upload */}
          <Stack gap={3} flex={1}>
            <Text fontSize="sm" fontWeight={500} color="gray.700">
              {photoSignConfig.photo.label}
            </Text>

            <Flex
              direction="column"
              align="center"
              justify="center"
              borderWidth="1px"
              borderColor="gray.200"
              borderRadius="md"
              p={6}
              bg="gray.50"
              minH="200px"
              position="relative"
            >
              {photoPreview ? (
                <Image
                  src={photoPreview}
                  alt="Photo preview"
                  maxH="180px"
                  maxW="180px"
                  objectFit="contain"
                />
              ) : (
                <Flex direction="column" align="center" gap={2} color="gray.400">
                  <Box
                    w="60px"
                    h="60px"
                    borderRadius="full"
                    bg="gray.200"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                  >
                    <Box
                      w="30px"
                      h="30px"
                      borderRadius="full"
                      bg="gray.300"
                    />
                  </Box>
                  <Box
                    w="40px"
                    h="40px"
                    bg="gray.200"
                    borderRadius="md"
                  />
                </Flex>
              )}
            </Flex>

            <Button
              size="sm"
              variant="outline"
              onClick={() => handleFileUpload("photo")}
              borderColor="gray.300"
              disabled={isLoading}
            >
              <MdFileUpload /> {photoSignConfig.photo.uploadButtonText}
            </Button>

            {errors.photo && (
              <Text color="red.500" fontSize="xs">{errors.photo}</Text>
            )}
          </Stack>

          {/* Signature Upload */}
          <Stack gap={3} flex={1}>
            <Text fontSize="sm" fontWeight={500} color="gray.700">
              {photoSignConfig.signature.label}
            </Text>

            <Flex
              direction="column"
              align="center"
              justify="center"
              borderWidth="1px"
              borderColor="gray.200"
              borderRadius="md"
              p={6}
              bg="gray.50"
              minH="200px"
              position="relative"
            >
              {signaturePreview ? (
                <Image
                  src={signaturePreview}
                  alt="Signature preview"
                  maxH="120px"
                  maxW="180px"
                  objectFit="contain"
                />
              ) : (
                <Flex direction="column" align="center" gap={2} color="gray.400">
                  <Box
                    w="60px"
                    h="60px"
                    borderRadius="full"
                    bg="gray.200"
                    display="flex"
                    alignItems="center"
                    justifyContent="center"
                  >
                    <Box
                      w="30px"
                      h="30px"
                      borderRadius="full"
                      bg="gray.300"
                    />
                  </Box>
                  <Box
                    w="40px"
                    h="40px"
                    bg="gray.200"
                    borderRadius="md"
                  />
                </Flex>
              )}
            </Flex>

            <Button
              size="sm"
              variant="outline"
              onClick={() => handleFileUpload("signature")}
              borderColor="gray.300"
              disabled={isLoading}
            >
              <MdFileUpload /> {photoSignConfig.signature.uploadButtonText}
            </Button>

            {errors.signature && (
              <Text color="red.500" fontSize="xs">{errors.signature}</Text>
            )}
          </Stack>
        </HStack>

        {/* Confirmation Checkbox */}
        <Flex align="center" gap={2} mt={2}>
          <label style={{ display: "flex", alignItems: "center", gap: "8px", cursor: "pointer" }}>
            <input
              type="checkbox"
              checked={confirmation}
              onChange={(e) => {
                setConfirmation(e.target.checked);
                setErrors((prev) => ({ ...prev, confirmation: undefined }));
              }}
              style={{
                width: "18px",
                height: "18px",
                accentColor: "#48BB78",
              }}
              disabled={isLoading}
            />
            <Text fontSize="sm" color="gray.700">
              {photoSignConfig.confirmation.text}
            </Text>
          </label>
        </Flex>

        {errors.confirmation && (
          <Text color="red.500" fontSize="xs" ml={6}>{errors.confirmation}</Text>
        )}

        {/* Footer Buttons */}
        <Box borderTop="1px solid" borderColor="gray.200" pt={6} mt={4}>
          <Flex justify="space-between" align="center">
            <Button
              variant="outline"
              size="md"
              borderColor="gray.300"
              color="gray.700"
              onClick={() => onPrev?.()}
              disabled={isLoading}
            >
              Previous
            </Button>
            <Button
              type="submit"
              size="md"
              bg="black"
              color="white"
              _hover={{ bg: "gray.800" }}
              loading={isLoading}
            >
              Save & Next
            </Button>
          </Flex>
        </Box>
      </Stack>
    </Box>
  );
}
