"use client";
import React, { useState } from "react";
import {
  Box,
  Stack,
  Text,
  Button,
  Flex,
  Image,
  Separator,
} from "@chakra-ui/react";
import { declarationConfig } from "@/config/forms/studentPersonalDetailsForm";
import "./Declaration.css";
import ProfileSummary from "@/components/forms/ProfileSummary";
import { trpc } from "@/lib/trpc";

type DeclarationForm = {
  accepted: boolean;
};

export default function Declaration({
  defaultValues,
  onSubmit,
  onNext,
  onPrev,
}: {
  defaultValues?: Partial<DeclarationForm>;
  onSubmit?: (data: DeclarationForm) => void;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [accepted, setAccepted] = useState(defaultValues?.accepted || false);
  const [error, setError] = useState<string | null>(null);

  const { data: photoSignData } = trpc.student.getPhotoSignDetails.useQuery(undefined);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!accepted) {
      setError("You must accept the declaration to continue");
      return;
    }

    const data: DeclarationForm = {
      accepted,
    };

    console.log("Declaration accepted:", data);
    onSubmit?.(data);
  };

  return (

    <>
      <ProfileSummary title="Declaration" showPrint={false} data={undefined} />

      <Box as="form" onSubmit={handleSubmit} bg="white"
        borderRadius="12px"
        p={{ base: 2, md: 4 }}
        boxShadow="sm"
        border="1px solid"
        borderColor="gray.100">
        <Stack gap={3}>
          {/* Title */}
          <Text fontSize="md" fontWeight="bold" color="orange.500">
            {declarationConfig.title}
          </Text>

          <Separator mt={0} mb={4} />

          {/* Instruction Text */}
          <Text fontSize="sm" color="blue.600">
            {declarationConfig.instructionText}
          </Text>

          <Flex gap={8} align="flex-start">
            {/* Left side - Declaration Text with Checkbox */}
            <Box flex={1}>
              {/* Declaration Points */}
              <Box mb={4}>
                {declarationConfig.declarations.map((declaration, index) => (
                  <Text key={index} fontSize="sm" mb={2}>
                    {index + 1}. {declaration}
                  </Text>
                ))}
              </Box>

              {/* Acceptance Checkbox */}
              {declarationConfig.acceptance.showCheckbox && (
                <Box>
                  <Flex gap={2} align="flex-start">
                    <label htmlFor="declaration-accept" className="declaration-label">
                      <input
                        id="declaration-accept"
                        type="checkbox"
                        checked={accepted}
                        onChange={(e) => {
                          setAccepted(e.target.checked);
                          setError(null);
                        }}
                        className="declaration-checkbox"
                        title="Accept declaration"
                      />
                      <Text as="span" fontSize="sm" color="green.700" ml={2}>
                        I accept the above declaration and affirm that all information
                        provided is true.
                      </Text>
                    </label>
                  </Flex>
                  {error && (
                    <Text color="red.500" fontSize="sm" mt={2}>
                      {error}
                    </Text>
                  )}
                </Box>
              )}
            </Box>

            {/* Right side - Signature Image */}
            <Box>
              <Text fontSize="sm" fontWeight="medium" mb={2}>
                Signature ({declarationConfig.signatureLabel})
              </Text>
              <Box
                borderWidth={1}
                borderColor="gray.300"
                borderRadius="md"
                p={4}
                bg="gray.50"
                width="200px"
                height="100px"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                {photoSignData?.SignURL ? (
                  <Image
                    src={photoSignData.SignURL}
                    alt="Signature"
                    maxH="100%"
                    maxW="100%"
                    objectFit="contain"
                  />
                ) : (
                  <Image
                    src="/placeholder-signature.png"
                    alt="Signature Placeholder"
                    maxH="100%"
                    maxW="100%"
                    objectFit="contain"
                    opacity={0.5}
                  />
                )}
              </Box>
            </Box>
          </Flex>

          {/* Action Buttons */}
          <Flex gap={4} justify="space-between" mt={4}>
            <Button variant="outline" colorPalette="gray" type="button" onClick={() => onPrev?.()}>
              {declarationConfig.previousButtonText}
            </Button>
            <Button colorPalette="orange" type="submit">
              {declarationConfig.submitButtonText}
            </Button>
          </Flex>
        </Stack>
      </Box>
    </>
  );
}
