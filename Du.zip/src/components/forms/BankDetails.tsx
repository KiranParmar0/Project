"use client";

import { useEffect, useState } from "react";
import DynamicForm from "../ui/DynamicForm";
import { bankDetailsConfig } from "@/config/forms/studentPersonalDetailsForm";
import { trpc } from "@/lib/trpc";
import { toaster } from "../ui/toaster";
import { useCurrentUser } from "@/hooks/useCurrentUser";

// Client-side IFSC validation function
function validateIFSC(code: string): boolean {
  if (!code || code.length !== 11) return false;
  // IFSC format: First 4 alpha, 5th is 0, last 6 alphanumeric
  const ifscRegex = /^[A-Z]{4}0[A-Z0-9]{6}$/;
  return ifscRegex.test(code.toUpperCase());
}

export default function BankDetails({
  defaultValues,
  onNext,
  onPrev,
}: {
  defaultValues?: Record<string, any>;
  onNext?: () => void;
  onPrev?: () => void;
}) {
  const [initialValues, setInitialValues] = useState<Record<string, any>>({});
  const [formKey, setFormKey] = useState(0);
  const utils = trpc.useUtils();
  const { user } = useCurrentUser();

  // Fetch existing bank details from database
  const { data: existingData, isLoading } = trpc.student.getBankDetails.useQuery(undefined, {
    refetchOnMount: true,
    refetchOnWindowFocus: false,
  });

  // Save bank details mutation
  const saveBankDetails = trpc.student.saveBankDetails.useMutation({
    onSuccess: () => {
      toaster.create({
        title: "Success",
        description: "Bank details saved successfully",
        type: "success",
        duration: 3000,
      });
      utils.student.getBankDetails.invalidate();
      utils.student.getProfileStatus.invalidate();
      onNext?.();
    },
    onError: (error) => {
      toaster.create({
        title: "Error",
        description: error.message || "Failed to save bank details",
        type: "error",
        duration: 5000,
      });
    },
  });

  useEffect(() => {
    if (existingData) {
      const mappedData = {
        accountNo: existingData.AccountNo || "",
        confirmAccountNo: existingData.AccountNo || "",
        ifscCode: existingData.IFSCCode || "",
        bankName: existingData.BankName || "",
        branchName: existingData.BranchName || "",
        holderName: existingData.HolderName || "",
      };
      setInitialValues(mappedData);
      setFormKey(prev => prev + 1);
    }
  }, [existingData]);

  const handleSubmit = (data: Record<string, any>) => {
    // Validate that account numbers match
    if (data.accountNo !== data.confirmAccountNo) {
      toaster.create({
        title: "Validation Error",
        description: "Account numbers do not match!",
        type: "error",
        duration: 3000,
      });
      return;
    }

    // Validate IFSC code
    if (!validateIFSC(data.ifscCode)) {
      toaster.create({
        title: "Invalid IFSC Code",
        description: "Please enter a valid IFSC code",
        type: "error",
        duration: 3000,
      });
      return;
    }

    saveBankDetails.mutate({
      accountNo: data.accountNo,
      ifscCode: data.ifscCode?.toUpperCase(),
      bankName: data.bankName,
      branchName: data.branchName,
      holderName: data.holderName,
    });
  };

  const handleFormChange = async (name: string, value: any, formSetValue?: (name: string, value: any) => void) => {
    if (name === 'ifscCode' && value && value.length === 11 && formSetValue) {
      const ifscCode = value.toUpperCase();

      // Validate IFSC code format
      if (validateIFSC(ifscCode)) {
        try {
          // Fetch bank details from IFSC API
          const response = await fetch(`https://ifsc.razorpay.com/${ifscCode}`);
          if (response.ok) {
            const bankData = await response.json();
            formSetValue('bankName', bankData.BANK || '');
            formSetValue('branchName', bankData.BRANCH || '');
            toaster.create({
              title: "Bank Details Updated",
              description: `${bankData.BANK} - ${bankData.BRANCH}`,
              type: "success",
              duration: 3000,
            });
          } else {
            toaster.create({
              title: "IFSC Not Found",
              description: "Could not fetch bank details for this IFSC code",
              type: "error",
              duration: 2000,
            });
          }
        } catch (error) {
          console.error('Error fetching bank details:', error);
          toaster.create({
            title: "Error",
            description: "Failed to fetch bank details",
            type: "error",
            duration: 2000,
          });
        }
      } else {
        toaster.create({
          title: "Invalid IFSC Code",
          description: "Please enter a valid IFSC code",
          type: "error",
          duration: 2000,
        });
      }
    }
  };

  // Show loading state while fetching data or waiting for user session
  if (isLoading || !user) {
    return <div>Loading...</div>;
  }

  return (
    <DynamicForm
      key={formKey}
      sections={bankDetailsConfig}
      onSubmit={handleSubmit}
      defaultValues={initialValues}
      isSubmitting={saveBankDetails.isPending}
      onChange={handleFormChange}
      previousButton={{
        label: "Previous",
        onClick: () => {
          onPrev?.();
        },
      }}
    />
  );
}
