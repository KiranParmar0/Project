"use client";
import React, { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import {
  Box,
  Stack,
  Button,
  Text,
  Center,
  HStack,
  Input,
} from "@chakra-ui/react";
import { toaster } from "@/components/ui/toaster";

const CORRECT_OTP = "123456";

export default function VerifyEmail({
  email: initialEmail,
  onVerify,
  onResend,
}: {
  email?: string;
  onVerify?: (otp: string) => void;
  onResend?: () => void;
} = {}) {
  const router = useRouter();
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  const [email, setEmail] = useState<string>(() => {
    if (initialEmail) return initialEmail
    // If rendering on server, avoid accessing sessionStorage
    if (typeof window === 'undefined') return "***me@gmail.com"
    return sessionStorage.getItem("verifyEmail") || "***me@gmail.com"
  })

  // If initialEmail changes after mount, update
  React.useEffect(() => {
    if (initialEmail) setEmail(initialEmail)
  }, [initialEmail])

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return; // Only allow digits

    const newOtp = [...otp];
    newOtp[index] = value.slice(-1); // Take only the last digit
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").slice(0, 6);
    const digits = pastedData.split("").filter(char => /\d/.test(char));
    
    const newOtp = [...otp];
    digits.forEach((digit, index) => {
      if (index < 6) {
        newOtp[index] = digit;
      }
    });
    setOtp(newOtp);
    
    // Focus the next empty input or the last one
    const nextEmptyIndex = newOtp.findIndex(val => !val);
    if (nextEmptyIndex !== -1) {
      inputRefs.current[nextEmptyIndex]?.focus();
    } else {
      inputRefs.current[5]?.focus();
    }
  };

  const handleVerify = () => {
    const otpString = otp.join("");
    
    if (otpString.length !== 6) {
      toaster.create({
        title: "Incomplete OTP",
        description: "Please enter all 6 digits of the OTP to continue.",
        type: "error",
        duration: 5000,
      });
      return;
    }

    if (otpString === CORRECT_OTP) {
      toaster.create({
        title: "Email Verified Successfully!",
        description: "Your email has been verified. You will be redirected to the login page.",
        type: "success",
        duration: 3000,
      });
      
      setTimeout(() => {
        if (onVerify) {
          onVerify(otpString);
        } else {
          router.push("/auth/signin");
        }
      }, 1000);
    } else {
      toaster.create({
        title: "Invalid OTP",
        description: "The OTP you entered is incorrect. Please try again.",
        type: "error",
        duration: 5000,
      });
      
      // Clear inputs on error
      setOtp(["", "", "", "", "", ""]);
      setTimeout(() => {
        inputRefs.current[0]?.focus();
      }, 100);
    }
  };

  const handleCancel = () => {
    router.push("/auth/signup");
  };

  return (
    <Center minH="70vh" py={8}>
      <Box w="full" maxW="700px" px={6}>
        <Stack gap={12}>
        
          <Stack gap={4} textAlign="center">
            <Text fontSize="24px" fontWeight={600}>
              Two Step Authentication
            </Text>
            
            <Text fontSize="14px" color="gray.600" lineHeight={1.6} maxW="600px" mx="auto">
              A One-Time Password (OTP) has been sent to your registered email address:
            </Text>
            
            <Text fontSize="14px" fontWeight={600} color="gray.800">
              {email}
            </Text>
            
            <Text fontSize="14px" color="gray.600">
              Please enter the 6-digit OTP below to complete the verification.
            </Text>
          </Stack>
          <HStack gap={3} justify="center" mt={4}>
            {otp.map((digit, index) => (
              <React.Fragment key={index}>
                <Box>
                  <Input
                    ref={(el) => { inputRefs.current[index] = el; }}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleChange(index, e.target.value)}
                    onKeyDown={(e) => handleKeyDown(index, e)}
                    onPaste={index === 0 ? handlePaste : undefined}
                    aria-label={`OTP digit ${index + 1}`}
                    width="50px"
                    height="50px"
                    textAlign="center"
                    fontSize="20px"
                    fontWeight={600}
                    borderWidth="1px"
                    borderColor="gray.300"
                    borderRadius="8px"
                    _focus={{
                      borderColor: "green.700",
                      boxShadow: "0 0 0 1px #2D7A3E",
                    }}
                  />
                </Box>
                {index === 2 && (
                  <Text fontSize="24px" fontWeight={600} color="gray.400">
                    —
                  </Text>
                )}
              </React.Fragment>
            ))}
          </HStack>
          <HStack gap={4} mt={6}>
            <Button
              variant="outline"
              borderRadius="full"
              borderWidth="2px"
              borderColor="gray.300"
              color="gray.700"
              _hover={{ bg: "gray.50" }}
              onClick={handleCancel}
              flex={1}
              height="48px"
            >
              Cancel
            </Button>
            
            <Button
              borderRadius="full"
              bgColor="green.700"
              color="white"
              _hover={{ bg: "green.800" }}
              onClick={handleVerify}
              flex={1}
              height="48px"
            >
              Verify Email
            </Button>
          </HStack>
        </Stack>
      </Box>
    </Center>
  );
}
