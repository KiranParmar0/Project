"use client";

import { trpc } from "@/lib/trpc";
import ProfileWizard, { StepConfig } from "./ProfileWizard";
import PersonalDetails from "../forms/PersonalDetails";
import AddressDetails from "../forms/AddressDetails";
import ReservationDetails from "../forms/ReservationDetails";
import QualificationDetails from "../forms/QualificationDetails";
import BankDetails from "../forms/BankDetails";
import PhotoSignature from "../forms/PhotoSignature";
import DocumentDetails from "../forms/DocumentDetails";
import Declaration from "../forms/Declaration";

const STUDENT_STEPS: StepConfig[] = [
  { id: "personal", label: "Personal Details", component: PersonalDetails },
  { id: "address", label: "Address Details", component: AddressDetails },
  { id: "reservation", label: "Reservation Details", component: ReservationDetails },
  { id: "qualification", label: "Qualification Details", component: QualificationDetails },
  { id: "bank", label: "Bank Details", component: BankDetails },
  { id: "photoSign", label: "Photo & Signature", component: PhotoSignature },
  { id: "document", label: "Document Upload", component: DocumentDetails },
  { id: "declaration", label: "Declaration", component: Declaration },
];

export default function StudentProfileWizard() {
  const { data: profileStatus, isLoading, refetch } = trpc.student.getProfileStatus.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });

  return (
    <ProfileWizard
      steps={STUDENT_STEPS}
      getProfileStatus={() => profileStatus}
      isLoading={isLoading}
      refetchStatus={refetch}
      returnRoute="/dashboard"
    />
  );
}
