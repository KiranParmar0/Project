"use client";

import { trpc } from "@/lib/trpc";
import ProfileWizard from "./ProfileWizard";
import { COLLEGE_STEPS } from "@/config/forms/collegeSteps";

export default function CollegeProfileWizard() {
  const { data: profileStatus, isLoading, refetch } = trpc.college.getProfileStatus.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });

  return (
    <ProfileWizard
      steps={COLLEGE_STEPS}
      getProfileStatus={() => profileStatus}
      isLoading={isLoading}
      refetchStatus={refetch}
      returnRoute="/dashboard/college"
    />
  );
}
