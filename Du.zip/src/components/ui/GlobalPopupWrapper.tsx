"use client";
import { usePopup } from "@/contexts/PopupContext";
import GlobalPopup from "./GlobalPopup";

export default function GlobalPopupWrapper() {
  const { popupState, hidePopup } = usePopup();
  
  const handleConfirm = () => {
    hidePopup();
    popupState.onConfirm();
  };

  const handleCancel = () => {
    hidePopup();
    if (popupState.onCancel) {
      popupState.onCancel();
    }
  };
  
  return (
    <GlobalPopup
      isOpen={popupState.isOpen}
      type={popupState.type}
      title={popupState.title}
      message={popupState.message}
      showCancel={popupState.showCancel}
      onConfirm={handleConfirm}
      onCancel={handleCancel}
      componentName={popupState.componentName}
    />
  );
}
