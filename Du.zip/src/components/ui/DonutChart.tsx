"use client";
import React from "react";
import { Box } from "@chakra-ui/react";

type DonutChartProps = {
  value: number; // 0-100
  size?: number; // px
  strokeWidth?: number;
  segments?: number;
  gapDegrees?: number;
  filledColor?: string;
  emptyColor?: string;
};

function polarToCartesian(cx: number, cy: number, r: number, angleInDegrees: number) {
  const angleInRadians = ((angleInDegrees - 90) * Math.PI) / 180.0;
  return {
    x: cx + r * Math.cos(angleInRadians),
    y: cy + r * Math.sin(angleInRadians),
  };
}

function describeArc(cx: number, cy: number, r: number, startAngle: number, endAngle: number) {
  const start = polarToCartesian(cx, cy, r, endAngle);
  const end = polarToCartesian(cx, cy, r, startAngle);
  const largeArcFlag = endAngle - startAngle <= 180 ? "0" : "1";
  return [`M ${start.x} ${start.y}`, `A ${r} ${r} 0 ${largeArcFlag} 0 ${end.x} ${end.y}`].join(" ");
}

export default function DonutChart({
  value,
  size = 56,
  strokeWidth = 10,
  segments = 8,
  gapDegrees = 6,
  filledColor = "#E8921D",
  emptyColor = "#C7D2C6",
}: DonutChartProps) {
  const cx = size / 2;
  const cy = size / 2;
  const r = (size - strokeWidth) / 2;
  const segmentAngle = 360 / segments;
  const sweep = segmentAngle - gapDegrees;
  const filledSegments = Math.round((value / 100) * segments);

  return (
    <Box as="div" display="inline-block">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} aria-hidden="true">
        {Array.from({ length: segments }).map((_, i) => {
          const startAngle = i * segmentAngle + gapDegrees / 2;
          const endAngle = startAngle + sweep;
          const path = describeArc(cx, cy, r, startAngle, endAngle);
          const isFilled = i < filledSegments;
          return (
            <path
              key={i}
              d={path}
              stroke={isFilled ? filledColor : emptyColor}
              strokeWidth={strokeWidth}
              fill="none"
              strokeLinecap="round"
            />
          );
        })}

        <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fontSize={size * 0.28} fontWeight={700} fill="#1A202C">{`${value}%`}</text>
      </svg>
    </Box>
  );
}
