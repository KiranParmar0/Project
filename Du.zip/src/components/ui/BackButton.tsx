"use client";
import React from "react";
import { useRouter } from "next/navigation";
import { Button, Box, HStack, Text } from "@chakra-ui/react";
import { FaArrowLeft } from "react-icons/fa";

interface BackButtonProps {
  label?: string;
  fallbackPath?: string;
}

export default function BackButton({ 
  label = "Back to Home Page", 
  fallbackPath = "/" 
}: BackButtonProps) {
  const router = useRouter();

  const handleBack = () => {
    // Always go to the fallback path (home page by default)
    router.push(fallbackPath);
  };

  return (
    <Button
      variant="ghost"
      onClick={handleBack}
      color="#2D7A3E"
      _hover={{ bg: "transparent", opacity: 0.8 }}
      fontSize="lg"
      fontWeight={500}
      px={0}
      py={2}
      h="auto"
    >
      <HStack gap={2}>
        <FaArrowLeft size={20} />
        <Text>{label}</Text>
      </HStack>
    </Button>
  );
}
