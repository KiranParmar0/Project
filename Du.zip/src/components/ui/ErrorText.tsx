import { Text, TextProps } from "@chakra-ui/react";

interface ErrorTextProps extends TextProps {
  children: React.ReactNode;
}

/**
 * Global error text component with consistent styling across the application.
 * Uses the global error color defined in ChakraProviders.
 */
export default function ErrorText({ children, ...props }: ErrorTextProps) {
  return (
    <Text
      color="var(--error-color)"
      fontSize="0.875rem"
      lineHeight="1.25rem"
      {...props}
    >
      {children}
    </Text>
  );
}
