"use client";

import {
  Box,
  Text
} from "@chakra-ui/react";
import { forwardRef } from "react";

export interface FieldProps {
  label?: React.ReactNode;
  helperText?: React.ReactNode;
  errorText?: React.ReactNode;
  invalid?: boolean;
  children: React.ReactNode;
}

export const Field = forwardRef<HTMLDivElement, FieldProps>(
  function Field(props, ref) {
    const { label, children, helperText, errorText, invalid, ...rest } = props;

    return (
      <Box ref={ref} {...rest}>
        {label && (
          <Text
            as="label"
            fontSize="xs"
            fontWeight="500"
            mb="1.5"
            display="block"
            color="gray.700"
          >
            {label}
          </Text>
        )}
        {children}
        {helperText && (
          <Text fontSize="sm" color="gray.600" mt="1">
            {helperText}
          </Text>
        )}
        {invalid && errorText && (
          <Text fontSize="sm" color="red.500" mt="1">
            {errorText}
          </Text>
        )}
      </Box>
    );
  }
);
