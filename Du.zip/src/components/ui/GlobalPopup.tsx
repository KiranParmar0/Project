"use client";
import React from "react";
import {
  Box,
  Button,
  HStack,
  Text,
  VStack,
} from "@chakra-ui/react";
import { FaCheckCircle, FaTimesCircle, FaTimes } from "react-icons/fa";

interface GlobalPopupProps {
  isOpen: boolean;
  type: "success" | "error";
  title: string;
  message: string;
  showCancel?: boolean;
  onConfirm: () => void;
  onCancel?: () => void;
  componentName?: string;
}

export default function GlobalPopup({
  isOpen,
  type,
  title,
  message,
  showCancel = false,
  onConfirm,
  onCancel,
  componentName,
}: GlobalPopupProps) {
  // Log which component opened the popup (for debugging)
  React.useEffect(() => {
    if (isOpen && componentName) {
      console.log(`[GlobalPopup] Opened by: ${componentName}`);
    }
  }, [isOpen, componentName]);

  const isSuccess = type === "success";
  const iconColor = isSuccess ? "#2D7A3E" : "#DC2626";
  const IconComponent = isSuccess ? FaCheckCircle : FaTimesCircle;

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <Box
        position="fixed"
        top={0}
        left={0}
        right={0}
        bottom={0}
        bg="blackAlpha.600"
        zIndex={9998}
        onClick={onCancel || onConfirm}
      />

      {/* Popup Modal */}
      <Box
        position="fixed"
        top="50%"
        left="50%"
        transform="translate(-50%, -50%)"
        bg="white"
        borderRadius="16px"
        boxShadow="0 20px 50px rgba(0, 0, 0, 0.3)"
        p={8}
        maxW="480px"
        w="90%"
        zIndex={9999}
      >
        {/* Close Button */}
        {onCancel && (
          <Box
            position="absolute"
            top={4}
            right={4}
            cursor="pointer"
            color="gray.400"
            _hover={{ color: "gray.600" }}
            onClick={onCancel}
          >
            <FaTimes size={20} />
          </Box>
        )}

        <VStack gap={6} align="center">
          {/* Icon */}
          <Box
            w="80px"
            h="80px"
            borderRadius="full"
            bg={isSuccess ? "green.50" : "red.50"}
            display="flex"
            alignItems="center"
            justifyContent="center"
          >
            <IconComponent size={40} color={iconColor} />
          </Box>

          {/* Title */}
          <Text
            fontSize="24px"
            fontWeight={700}
            color="gray.800"
            textAlign="center"
          >
            {title}
          </Text>

          {/* Message */}
          <Text
            fontSize="16px"
            color="gray.600"
            textAlign="center"
            lineHeight={1.6}
          >
            {message}
          </Text>

          {/* Buttons */}
          <HStack gap={4} w="full" mt={2}>
            {showCancel && onCancel && (
              <Button
                variant="outline"
                borderRadius="full"
                borderWidth="2px"
                borderColor="gray.300"
                color="gray.700"
                _hover={{ bg: "gray.50" }}
                onClick={onCancel}
                flex={1}
                height="48px"
                fontSize="16px"
                fontWeight={600}
              >
                Cancel
              </Button>
            )}

            <Button
              borderRadius="full"
              bg={isSuccess ? "green.700" : "red.600"}
              color="white"
              _hover={{ bg: isSuccess ? "green.800" : "red.700" }}
              onClick={onConfirm}
              flex={1}
              height="48px"
              fontSize="16px"
              fontWeight={600}
            >
              {isSuccess ? "Continue" : "Try Again"}
            </Button>
          </HStack>
        </VStack>
      </Box>
    </>
  );
}
