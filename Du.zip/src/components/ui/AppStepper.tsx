"use client";

import { Box, Steps } from "@chakra-ui/react";

export interface StepItem {
  id: string;
  label: string;
  description?: string;
}

interface AppStepperProps {
  steps: StepItem[];
  activeStep: number;
  completedStepIndices?: number[];
  orientation?: "horizontal" | "vertical";
}

export default function AppStepper({
  steps,
  activeStep,
  completedStepIndices,
  orientation = "horizontal",
}: AppStepperProps) {
  return (
    <Box
      w="full"
      py={4}
      px={4}
      css={{
        // Custom styling to match Figma design
        "& [data-scope='steps'][data-part='root']": {
          width: "100%",
        },
        "& [data-scope='steps'][data-part='list']": {
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: 0,
        },
        "& [data-scope='steps'][data-part='item']": {
          flex: 1,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          position: "relative",
        },
        "& [data-scope='steps'][data-part='trigger']": {
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: "6px",
          background: "transparent",
          border: "none",
          cursor: "default",
          padding: 0,
        },
        "& [data-scope='steps'][data-part='indicator']": {
          width: "36px",
          height: "36px",
          borderRadius: "50%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          fontSize: "14px",
          fontWeight: "600",
          position: "relative",
          zIndex: 2,
          transition: "all 0.2s",
        },
        // Incomplete state (gray outline, gray number)
        "& [data-scope='steps'][data-part='indicator'][data-incomplete]": {
          border: "2px solid",
          borderColor: "#D1D5DB", // gray-300
          backgroundColor: "white",
          color: "#9CA3AF", // gray-400
        },
        // Current/Active state (green outline, green number, white background)
        "& [data-scope='steps'][data-part='indicator'][data-current]": {
          border: "2px solid",
          borderColor: "#10B981", // green-500
          backgroundColor: "white",
          color: "#10B981", // green-500
        },
        // Completed state (filled green, white number, with glow)
        "& [data-scope='steps'][data-part='indicator'][data-complete]": {
          border: "2px solid",
          borderColor: "#10B981", // green-500
          backgroundColor: "#10B981", // green-500
          color: "white",
          boxShadow: "0 0 0 4px rgba(16, 185, 129, 0.15)", // green glow
        },
        "& [data-scope='steps'][data-part='separator']": {
          position: "absolute",
          top: "18px",
          left: "50%",
          width: "100%",
          height: "3px",
          zIndex: 0,
          transform: "translateY(-50%)",
        },
        "& [data-scope='steps'][data-part='item']:last-child [data-part='separator']": {
          display: "none",
        },
        "& [data-scope='steps'][data-part='title']": {
          fontSize: "12px",
          fontWeight: "500",
          color: "#374151", // gray-700
          textAlign: "center",
          lineHeight: "1.3",
          maxWidth: "100px",
          marginTop: "2px",
        },
        "& [data-scope='steps'][data-part='item'][data-current] [data-part='title']": {
          fontWeight: "600",
          color: "#111827", // gray-900
        },
        "& [data-scope='steps'][data-part='item'][data-complete] [data-part='title']": {
          fontWeight: "500",
          color: "#374151", // gray-700
        },
      }}
    >
      <Steps.Root
        step={activeStep}
        count={steps.length}
        orientation={orientation}
        colorPalette="green"
        size="sm"
      >
        <Steps.List>
          {steps.map((step, index) => {
            // Determine if this step's separator line should be green
            // The line should be green if the current step (index) is completed
            const isStepComplete = index < activeStep;
            const separatorColor = isStepComplete ? "#10B981" : "#E5E7EB";

            return (
              <Steps.Item key={step.id} index={index}>
                <Steps.Trigger>
                  <Steps.Indicator>
                    <Steps.Status
                      complete={<Box fontWeight="600">{index + 1}</Box>}
                      incomplete={<Box fontWeight="600">{index + 1}</Box>}
                      current={<Box fontWeight="600">{index + 1}</Box>}
                    />
                  </Steps.Indicator>
                  <Box flexShrink={0}>
                    <Steps.Title>{step.label}</Steps.Title>
                    {step.description && <Steps.Description>{step.description}</Steps.Description>}
                  </Box>
                </Steps.Trigger>
                <Steps.Separator
                  style={{ backgroundColor: separatorColor }}
                />
              </Steps.Item>
            );
          })}
        </Steps.List>
      </Steps.Root>
    </Box>
  );
}
