"use client";
import React, { useEffect, useRef } from "react";
import { Box } from "@chakra-ui/react";

interface VisualCaptchaProps {
  captchaText: string;
  width?: number;
  height?: number;
}

export default function VisualCaptcha({ 
  captchaText, 
  width = 240, 
  height = 40 
}: VisualCaptchaProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Set canvas internal resolution to match display size
    canvas.width = width;
    canvas.height = height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Light background with subtle texture
    ctx.fillStyle = "#f7f7f7";
    ctx.fillRect(0, 0, width, height);

    // Add subtle gray noise/dots (monochrome)
    for (let i = 0; i < Math.max(30, Math.floor(width * height / 1000)); i++) {
      const gray = Math.floor(100 + Math.random() * 100);
      ctx.fillStyle = `rgba(${gray}, ${gray}, ${gray}, ${0.06 + Math.random() * 0.08})`;
      const size = 1 + Math.random() * 2;
      ctx.fillRect(Math.random() * width, Math.random() * height, size, size);
    }

    // Draw captcha text as a single word in black with a blurred layer
    const characters = captchaText.split("");
    const charCount = Math.max(1, characters.length);
    const charSpacing = width / (charCount + 1);

    // Draw blurred layer (slightly larger, lower opacity) beneath
    ctx.save();
    ctx.globalAlpha = 0.55;
    ctx.filter = "blur(1.6px)";
    characters.forEach((char, index) => {
      ctx.save();
      const x = charSpacing * (index + 1) + (Math.random() * 6 - 3);
      const y = height / 2 + (Math.random() * 6 - 3);
      const fontSize = height * (0.7 + Math.random() * 0.08);
      ctx.font = `700 ${fontSize}px Arial, Helvetica, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "#000";
      ctx.translate(x, y);
      ctx.rotate((Math.random() - 0.5) * 0.08);
      ctx.fillText(char, 0, 0);
      ctx.restore();
    });
    ctx.restore();

    // Draw sharp black text on top
    characters.forEach((char, index) => {
      ctx.save();
      const x = charSpacing * (index + 1) + (Math.random() * 4 - 2);
      const y = height / 2 + (Math.random() * 4 - 2);
      const fontSize = height * (0.72 + Math.random() * 0.06);
      ctx.font = `700 ${fontSize}px Arial, Helvetica, sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillStyle = "#000";
      // subtle inner shadow effect using shadow properties with very small blur
      ctx.shadowColor = "rgba(0,0,0,0.15)";
      ctx.shadowBlur = 0.8;
      ctx.shadowOffsetX = 0.6;
      ctx.shadowOffsetY = 0.6;
      ctx.translate(x, y);
      ctx.rotate((Math.random() - 0.5) * 0.06);
      ctx.fillText(char, 0, 0);
      ctx.restore();
    });

    // Add a bold strikethrough / scribble line across the word to mimic the reference
    ctx.save();
    ctx.globalAlpha = 0.95;
    ctx.strokeStyle = "rgba(0,0,0,0.85)";
    ctx.lineWidth = Math.max(2, Math.floor(height * 0.12));
    ctx.lineJoin = "round";
    ctx.beginPath();
    const yLine = height * 0.45 + (Math.random() * 6 - 3);
    ctx.moveTo(width * 0.05, yLine - (Math.random() * 6 - 3));
    // draw a slightly curvy line across
    ctx.bezierCurveTo(width * 0.25, yLine - 6, width * 0.55, yLine + 6, width * 0.95, yLine - 2);
    ctx.stroke();
    ctx.restore();

    // Add a couple of faint thin scratches for texture
    for (let i = 0; i < 2; i++) {
      ctx.strokeStyle = `rgba(0,0,0,${0.06 + Math.random() * 0.06})`;
      ctx.lineWidth = 1;
      ctx.beginPath();
      const sy = height * (0.2 + Math.random() * 0.6);
      ctx.moveTo(Math.random() * width, sy);
      ctx.lineTo(Math.random() * width, sy + (Math.random() * 10 - 5));
      ctx.stroke();
    }

  }, [captchaText, width, height]);

  return (
    <Box
      as="canvas"
      ref={canvasRef}
      width={`${width}px`}
      height={`${height}px`}
      maxW="100%"
      style={{
        border: "1px solid #e2e8f0",
        borderRadius: "6px",
        cursor: "default",
        userSelect: "none",
      }}
    />
  );
}
