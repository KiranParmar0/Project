import { z } from 'zod';
import { createTRPCRouter, publicProcedure } from '../trpc';
import {
  master_security_question,
  master_category,
  master_religion,
  master_qualification,
  master_program,
  master_university,
  master_board,
  master_minority,
  master_document,
} from '@/db/schema';
import { eq, asc } from 'drizzle-orm';

export const masterRouter = createTRPCRouter({
  // Get all security questions
  getSecurityQuestions: publicProcedure.query(async ({ ctx }) => {
    const questions = await ctx.db
      .select()
      .from(master_security_question)
      .where(eq(master_security_question.IsActive, true));

    return questions.map((q) => ({
      id: q.SecurityQuestionID!,
      question: q.SecurityQuestion!,
    }));
  }),
  // Get all active categories
  getCategories: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_category)
      .where(eq(master_category.IsActive, true));

    return rows.map((r) => ({ id: r.CategoryID!, name: r.CategoryName! }));
  }),

  // Get all active religions
  getReligions: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_religion)
      .where(eq(master_religion.IsActive, true));

    return rows.map((r) => ({ id: r.ReligionID!, name: r.ReligionName! }));
  }),

  // Get all qualifications sorted by SeqNo
  getQualifications: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_qualification)
      .where(eq(master_qualification.IsActive, true))
      .orderBy(asc(master_qualification.SeqNo));

    return rows.map((r) => ({ id: r.QualificationID!, name: r.Qualification!, seqNo: r.SeqNo ?? null }));
  }),

  // Get all active boards
  getBoards: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_board)
      .where(eq(master_board.IsActive, true))
      .orderBy(asc(master_board.Board));

    return rows.map((r) => ({ id: r.BoardID!, name: r.Board! }));
  }),

  // Get all active universities
  getUniversities: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_university)
      .where(eq(master_university.IsActive, true))
      .orderBy(asc(master_university.UniversityName));

    return rows.map((r) => ({ id: r.UniversityID!, name: r.UniversityName! }));
  }),

  // Get programs that belong to a qualification
  getProgramsByQualification: publicProcedure
    .input(z.number())
    .query(async ({ ctx, input }) => {
      const rows = await ctx.db
        .select()
        .from(master_program)
        .where(eq(master_program.QualificationID, input))
        .orderBy(asc(master_program.ProgramName));

      return rows.map((r) => ({ id: r.ProgramID!, name: r.ProgramName! }));
    }),

  // Get minorities
  getMinorities: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_minority)
      .where(eq(master_minority.IsActive, true));

    return rows.map((r) => ({ id: r.MinorityID!, name: r.Minority, category: r.MinorityCategory }));
  }),

  // Get all active documents
  getDocuments: publicProcedure.query(async ({ ctx }) => {
    const rows = await ctx.db
      .select()
      .from(master_document)
      .where(eq(master_document.IsActive, true))
      .orderBy(asc(master_document.SeqNo));

    return rows.map((r) => ({
      id: r.DocumentID!,
      name: r.Document!,
      isRequired: r.IsCompulsory!,
      fileType: '.pdf, .jpg, .jpeg, .png', // Defaulting as not in DB
    }));
  }),
});
