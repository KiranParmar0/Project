import { z } from 'zod';
import { createTRPCRouter, protectedProcedure, publicProcedure } from '../trpc';
import { db } from '@/lib/drizzle';
import {
  registration_details,
  personal_details,
  address_details,
  reservation_and_other_details,
  qualification_details,
  candidate_bank_details,
  photo_sign,
  required_document,
  profile_status,
  master_state,
  master_district,
  master_taluka,
  master_qualification,
  master_program,
  master_board,
  master_university,
  master_category,
  master_religion,
  master_minority,
} from '@/db/schema';
import { eq, and, getTableColumns, sql } from 'drizzle-orm';
import { alias } from 'drizzle-orm/pg-core';
import { uploadFileToAzure, deleteFileFromAzure } from '@/lib/azure-storage';

// Helper function to get candidate ID from email
async function getCandidateId(email: string): Promise<bigint | null> {
  const registration = await db
    .select()
    .from(registration_details)
    .where(eq(registration_details.CandidateEmailID, email))
    .limit(1);

  return registration.length > 0 ? registration[0].CandidateID : null;
}

// Helper function to get or create registration
async function getOrCreateRegistration(email: string, name: string, mobile: string, ipAddress: string): Promise<bigint> {
  let candidateId = await getCandidateId(email);

  if (!candidateId) {
    // Create new registration
    const newRegistration = await db
      .insert(registration_details)
      .values({
        CandidateName: name,
        CandidateEmailID: email,
        CandidateMobileNo: mobile,
        CreatedByID: email,
        CreatedIPAddress: ipAddress,
      })
      .returning();

    candidateId = newRegistration[0].CandidateID;
  }

  return candidateId;
}

export const studentRouter = createTRPCRouter({
  // Get profile status and progress
  getProfileStatus: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;
    if (!email) throw new Error('Email not found in session');

    const candidateId = await getCandidateId(email);
    if (!candidateId) {
      return {
        profileProgress: 0,
        completedSections: [],
        currentSection: 'personal',
      };
    }

    const completedSections: string[] = [];

    // Check each section
    const personal = await db.select().from(personal_details).where(eq(personal_details.CandidateID, candidateId)).limit(1);
    if (personal.length > 0) completedSections.push('personal');

    const address = await db.select().from(address_details).where(eq(address_details.CandidateID, candidateId)).limit(1);
    if (address.length > 0) completedSections.push('address');

    const reservation = await db.select().from(reservation_and_other_details).where(eq(reservation_and_other_details.CandidateID, candidateId)).limit(1);
    if (reservation.length > 0) completedSections.push('reservation');

    const qualification = await db.select().from(qualification_details).where(eq(qualification_details.CandidateID, candidateId)).limit(1);
    if (qualification.length > 0) completedSections.push('qualification');

    const bank = await db.select().from(candidate_bank_details).where(eq(candidate_bank_details.CandidateID, candidateId)).limit(1);
    if (bank.length > 0) completedSections.push('bank');

    const photo = await db.select().from(photo_sign).where(eq(photo_sign.CandidateID, candidateId)).limit(1);
    if (photo.length > 0) completedSections.push('photo');

    const documents = await db.select().from(required_document).where(eq(required_document.CandidateID, candidateId)).limit(1);
    if (documents.length > 0) completedSections.push('documents');

    const totalSections = 8; // Total number of sections
    const profileProgress = (completedSections.length / totalSections) * 100;

    return {
      profileProgress,
      completedSections,
      currentSection: completedSections.length === 0 ? 'personal' : completedSections[completedSections.length - 1],
    };
  }),

  // Save Personal Details
  savePersonalDetails: protectedProcedure
    .input(z.object({
      firstName: z.string(),
      middleName: z.string().optional(),
      lastName: z.string(),
      fullName: z.string(),
      gender: z.string(),
      dob: z.string(),
      bloodGroup: z.string().optional(),
      fatherName: z.string(),
      fatherOccupation: z.string().optional(),
      motherName: z.string(),
      motherOccupation: z.string().optional(),
      annualIncome: z.string().optional(),
      motherTongue: z.string().optional(),
      aadharNumber: z.string().optional(),
      abcId: z.string().optional(),
      emailAddress: z.string().email(),
      mobileNumber: z.string(),
      whatsappNumber: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const email = ctx.session.user.email;
      if (!email) throw new Error('Email not found in session');

      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'Unknown';
      const candidateId = await getOrCreateRegistration(
        email,
        input.fullName,
        input.mobileNumber,
        ipAddress
      );

      // Check if personal details already exist
      const existing = await db
        .select()
        .from(personal_details)
        .where(eq(personal_details.CandidateID, candidateId))
        .limit(1);

      if (existing.length > 0) {
        // Update existing
        await db
          .update(personal_details)
          .set({
            FirstName: input.firstName,
            MiddleName: input.middleName,
            LastName: input.lastName,
            FullName: input.fullName,
            Gender: input.gender as any,
            DOB: input.dob,
            BloodGroup: input.bloodGroup,
            FatherName: input.fatherName,
            FatherOccupation: input.fatherOccupation,
            MotherName: input.motherName,
            MotherOccupation: input.motherOccupation,
            AnnualIncome: input.annualIncome,
            MotherTongue: input.motherTongue,
            AadharNo: input.aadharNumber,
            ABCID: input.abcId,
            EmailID: input.emailAddress,
            MobileNo: input.mobileNumber,
            WhatappMobileNo: input.whatsappNumber,
            ModifiedByID: email,
            ModifiedOnDate: new Date(),
            ModifiedIPAddress: ipAddress,
          })
          .where(eq(personal_details.CandidateID, candidateId));
      } else {
        // Insert new
        await db.insert(personal_details).values({
          CandidateID: candidateId,
          FirstName: input.firstName,
          MiddleName: input.middleName,
          LastName: input.lastName,
          FullName: input.fullName,
          Gender: input.gender as any,
          DOB: input.dob,
          BloodGroup: input.bloodGroup,
          FatherName: input.fatherName,
          FatherOccupation: input.fatherOccupation,
          MotherName: input.motherName,
          MotherOccupation: input.motherOccupation,
          AnnualIncome: input.annualIncome,
          MotherTongue: input.motherTongue,
          AadharNo: input.aadharNumber,
          ABCID: input.abcId,
          EmailID: input.emailAddress,
          MobileNo: input.mobileNumber,
          WhatappMobileNo: input.whatsappNumber,
          CreatedByID: email,
          CreatedOnDate: new Date(),
          CreatedIPAddress: ipAddress,
        });
      }

      return { success: true, message: 'Personal details saved successfully' };
    }),

  // Get Personal Details
  getPersonalDetails: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;
    if (!email) throw new Error('Email not found in session');

    const candidateId = await getCandidateId(email);
    if (!candidateId) return null;

    const details = await db
      .select()
      .from(personal_details)
      .where(eq(personal_details.CandidateID, candidateId))
      .limit(1);

    return details.length > 0 ? details[0] : null;
  }),

  // Save Address Details
  saveAddressDetails: protectedProcedure
    .input(z.object({
      nationality: z.string(),
      country: z.string().optional(),
      stateId: z.number().optional(),
      districtId: z.number().optional(),
      talukaId: z.string().optional(),
      villageCity: z.string().optional(),
      address1: z.string(),
      address2: z.string().optional(),
      pinCode: z.string(),
      isSameAsAddress: z.boolean().optional(),
      psCountry: z.string().optional(),
      psStateId: z.number().optional(),
      psDistrictId: z.number().optional(),
      psTalukaId: z.string().optional(),
      psVillage: z.string().optional(),
      pAddress1: z.string().optional(),
      pAddress2: z.string().optional(),
      pPinCode: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const email = ctx.session.user.email;
      if (!email) throw new Error('Email not found in session');

      const candidateId = await getCandidateId(email);
      if (!candidateId) throw new Error('Registration not found. Please complete personal details first.');

      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'Unknown';

      const existing = await db
        .select()
        .from(address_details)
        .where(eq(address_details.CandidateID, candidateId))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(address_details)
          .set({
            Nationality: input.nationality as any,
            Country: input.country,
            StateID: input.stateId,
            DistrictID: input.districtId,
            TalukaID: input.talukaId,
            VillageCity: input.villageCity,
            Address1: input.address1,
            Address2: input.address2,
            PinCode: input.pinCode,
            IsSameAsAddress: input.isSameAsAddress,
            PSCountry: input.psCountry,
            PSStateID: input.psStateId,
            PSDistrictID: input.psDistrictId,
            PSTalukaID: input.psTalukaId,
            PSVillage: input.psVillage,
            PAddress1: input.pAddress1,
            PAddress2: input.pAddress2,
            PPinCode: input.pPinCode,
            ModifiedByID: email,
            ModifiedOnDate: new Date(),
            ModifiedIPAddress: ipAddress,
          })
          .where(eq(address_details.CandidateID, candidateId));
      } else {
        await db.insert(address_details).values({
          CandidateID: candidateId,
          Nationality: input.nationality as any,
          Country: input.country,
          StateID: input.stateId,
          DistrictID: input.districtId,
          TalukaID: input.talukaId,
          VillageCity: input.villageCity,
          Address1: input.address1,
          Address2: input.address2,
          PinCode: input.pinCode,
          IsSameAsAddress: input.isSameAsAddress,
          PSCountry: input.psCountry,
          PSStateID: input.psStateId,
          PSDistrictID: input.psDistrictId,
          PSTalukaID: input.psTalukaId,
          PSVillage: input.psVillage,
          PAddress1: input.pAddress1,
          PAddress2: input.pAddress2,
          PPinCode: input.pPinCode,
          CreatedByID: email,
          CreatedOnDate: new Date(),
          CreatedIPAddress: ipAddress,
        });
      }

      return { success: true, message: 'Address details saved successfully' };
    }),

  // Get Address Details
  getAddressDetails: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;
    if (!email) throw new Error('Email not found in session');

    const candidateId = await getCandidateId(email);
    if (!candidateId) return null;

    // Aliases for Permanent Address joins
    const psState = alias(master_state, "psState");
    const psDistrict = alias(master_district, "psDistrict");
    const psTaluka = alias(master_taluka, "psTaluka");

    const details = await db
      .select({
        ...getTableColumns(address_details),
        StateName: master_state.StateName,
        DistrictName: master_district.DistrictName,
        TalukaName: master_taluka.TalukaName,
        PSStateName: psState.StateName,
        PSDistrictName: psDistrict.DistrictName,
        PSTalukaName: psTaluka.TalukaName,
      })
      .from(address_details)
      .leftJoin(master_state, eq(address_details.StateID, master_state.StateID))
      .leftJoin(master_district, eq(address_details.DistrictID, master_district.DistrictID))
      // Note: TalukaID in address is varchar, but in master is int. 
      // Drizzle's eq() might complain if types don't match. 
      // We will cast master_taluka.TalukaID to string for comparison or vice versa.
      // Easiest is to not join if IDs mismatch, but let's assume they are stored as stringified numbers.
      // Drizzle SQL operator: sql`${address_details.TalukaID} = ${master_taluka.TalukaID}::varchar`
      // Or just try standard join and see if it works (JS runtime lenient, but SQL strict).
      // Postgres: cannot compare integer and character varying.
      // So I need to cast.
      // .leftJoin(master_taluka, eq(address_details.TalukaID, master_taluka.TalukaID)) // This will fail if types differ.
      // I will skip Taluka join for now as it risks errors, OR, I will try to cast.
      // But for now, let's just fix the spread error.
      .leftJoin(master_taluka, sql`CAST(${address_details.TalukaID} AS INTEGER) = ${master_taluka.TalukaID}`)
      .leftJoin(psState, eq(address_details.PSStateID, psState.StateID))
      .leftJoin(psDistrict, eq(address_details.PSDistrictID, psDistrict.DistrictID))
      .leftJoin(psTaluka, sql`CAST(${address_details.PSTalukaID} AS INTEGER) = ${psTaluka.TalukaID}`)
      .where(eq(address_details.CandidateID, candidateId))
      .limit(1);

    return details.length > 0 ? details[0] : null;
  }),

  // Save Bank Details
  saveBankDetails: protectedProcedure
    .input(z.object({
      accountNo: z.string(),
      ifscCode: z.string(),
      bankName: z.string(),
      branchName: z.string(),
      holderName: z.string(),
    }))
    .mutation(async ({ ctx, input }) => {
      const email = ctx.session.user.email;
      if (!email) throw new Error('Email not found in session');

      const candidateId = await getCandidateId(email);
      if (!candidateId) throw new Error('Registration not found');

      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'Unknown';

      const existing = await db
        .select()
        .from(candidate_bank_details)
        .where(eq(candidate_bank_details.CandidateID, candidateId))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(candidate_bank_details)
          .set({
            AccountNo: input.accountNo,
            IFSCCode: input.ifscCode,
            BankName: input.bankName,
            BranchName: input.branchName,
            HolderName: input.holderName,
            ModifiedByID: email,
            ModifiedOnDate: new Date(),
            ModifiedIPAddress: ipAddress,
          })
          .where(eq(candidate_bank_details.CandidateID, candidateId));
      } else {
        await db.insert(candidate_bank_details).values({
          CandidateID: candidateId,
          AccountNo: input.accountNo,
          IFSCCode: input.ifscCode,
          BankName: input.bankName,
          BranchName: input.branchName,
          HolderName: input.holderName,
          CreatedByID: email,
          CreatedOnDate: new Date(),
          CreatedIPAddress: ipAddress,
        });
      }

      return { success: true, message: 'Bank details saved successfully' };
    }),

  // Get Bank Details
  getBankDetails: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;
    if (!email) throw new Error('Email not found in session');

    const candidateId = await getCandidateId(email);
    if (!candidateId) return null;

    const details = await db
      .select()
      .from(candidate_bank_details)
      .where(eq(candidate_bank_details.CandidateID, candidateId))
      .limit(1);

    return details.length > 0 ? details[0] : null;
  }),

  // Get all states
  getStates: publicProcedure.query(async () => {
    const states = await db
      .select({
        value: master_state.StateID,
        label: master_state.StateName,
      })
      .from(master_state)
      .where(eq(master_state.IsActive, true))
      .orderBy(master_state.StateName);

    return states;
  }),

  // Get districts by state
  getDistricts: publicProcedure
    .input(z.object({
      stateId: z.number(),
    }))
    .query(async ({ input }) => {
      const districts = await db
        .select({
          value: master_district.DistrictID,
          label: master_district.DistrictName,
        })
        .from(master_district)
        .where(eq(master_district.StateID, input.stateId))
        .orderBy(master_district.DistrictName);

      return districts;
    }),

  // Get talukas by district
  getTalukas: publicProcedure
    .input(z.object({
      districtId: z.number(),
    }))
    .query(async ({ input }) => {
      const talukas = await db
        .select({
          value: master_taluka.TalukaID,
          label: master_taluka.TalukaName,
        })
        .from(master_taluka)
        .where(eq(master_taluka.DistrictID, input.districtId))
        .orderBy(master_taluka.TalukaName);

      return talukas;
    }),

  // Get existing photo and signature URLs
  getPhotoSignDetails: protectedProcedure.query(async ({ ctx }) => {
    const candidateId = await getCandidateId(ctx.session.user.email!);
    if (!candidateId) throw new Error('Candidate not found');

    const photoSignData = await db
      .select()
      .from(photo_sign)
      .where(eq(photo_sign.CandidateID, candidateId))
      .limit(1);

    return photoSignData[0] || null;
  }),

  // Upload photo/signature and save to database
  savePhotoSign: protectedProcedure
    .input(
      z.object({
        photoBase64: z.string().optional().describe('Base64 encoded photo'),
        photoName: z.string().optional().describe('Photo file name'),
        signatureBase64: z.string().optional().describe('Base64 encoded signature'),
        signatureName: z.string().optional().describe('Signature file name'),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const candidateId = await getCandidateId(ctx.session.user.email!);
      if (!candidateId) throw new Error('Candidate not found');

      let photoUrl: string | undefined;
      let signatureUrl: string | undefined;

      try {
        // Upload photo if provided
        if (input.photoBase64 && input.photoName) {
          const photoBuffer = Buffer.from(input.photoBase64, 'base64');
          photoUrl = await uploadFileToAzure(photoBuffer, input.photoName, 'photos');
        }

        // Upload signature if provided
        if (input.signatureBase64 && input.signatureName) {
          const signatureBuffer = Buffer.from(input.signatureBase64, 'base64');
          signatureUrl = await uploadFileToAzure(
            signatureBuffer,
            input.signatureName,
            'signatures'
          );
        }

        // Get existing photo sign record if any
        const existingRecord = await db
          .select()
          .from(photo_sign)
          .where(eq(photo_sign.CandidateID, candidateId))
          .limit(1);

        // Delete old files if they exist and new ones are being uploaded
        if (existingRecord[0]) {
          if (photoUrl && existingRecord[0].PhotoURL) {
            try {
              await deleteFileFromAzure(existingRecord[0].PhotoURL, 'photos');
            } catch (error) {
              console.error('Error deleting old photo:', error);
              // Continue even if deletion fails
            }
          }

          if (signatureUrl && existingRecord[0].SignURL) {
            try {
              await deleteFileFromAzure(existingRecord[0].SignURL, 'signatures');
            } catch (error) {
              console.error('Error deleting old signature:', error);
              // Continue even if deletion fails
            }
          }

          // Update existing record
          await db
            .update(photo_sign)
            .set({
              PhotoURL: photoUrl || existingRecord[0].PhotoURL,
              SignURL: signatureUrl || existingRecord[0].SignURL,
              ModifiedByID: ctx.session.user.email,
              ModifiedOnDate: new Date(),
              ModifiedIPAddress: ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown',
            })
            .where(eq(photo_sign.CandidateID, candidateId));
        } else {
          // Insert new record
          if (!photoUrl || !signatureUrl) {
            throw new Error('Both photo and signature are required for new submission');
          }

          await db.insert(photo_sign).values({
            CandidateID: candidateId,
            PhotoURL: photoUrl,
            SignURL: signatureUrl,
            CreatedByID: ctx.session.user.email,
            CreatedOnDate: new Date(),
            CreatedIPAddress: ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown',
            ModifiedByID: ctx.session.user.email,
            ModifiedOnDate: new Date(),
            ModifiedIPAddress: ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'unknown',
          });
        }

        return { success: true, photoUrl, signatureUrl };
      } catch (error) {
        console.error('Error saving photo/signature:', error);
        throw new Error(`Failed to save photo/signature: ${error}`);
      }
    }),

  // Save Reservation Details
  saveReservationDetails: protectedProcedure
    .input(z.object({
      domicileStateId: z.number().optional(),
      domicileType: z.string().optional(),
      categoryId: z.number().optional(),
      finalCategoryId: z.number().optional(),
      religionId: z.number().optional(),
      caste: z.string().optional(),
      hasCasteCertificate: z.boolean().optional(),
      HasNCLCertificate: z.boolean().optional(),
      HasEWSCertificate: z.boolean().optional(),
      hasCasteValidity: z.boolean().optional(),
      hasCasteValidityReceipt: z.boolean().optional(),
      isOrphan: z.boolean().optional(),
      isPH: z.boolean().optional(),
      PHDetails: z.string().optional(),
      IsExServiceman: z.boolean().optional(),
      isFreedomFighter: z.boolean().optional(),
      IsProjectAffected: z.boolean().optional(),
      isTransgender: z.boolean().optional(),
      sportDetails: z.string().optional(),
      isNCC: z.boolean().optional(),
      isNSS: z.boolean().optional(),
      isAgriculture: z.boolean().optional(),
      isMinority: z.boolean().optional(),
      religiousMinorityId: z.number().optional(),
      linguisticMinorityId: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const email = ctx.session.user.email;
      if (!email) throw new Error('Email not found in session');

      const candidateId = await getCandidateId(email);
      if (!candidateId) throw new Error('Registration not found. Please complete personal details first.');

      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'Unknown';

      const existing = await db
        .select()
        .from(reservation_and_other_details)
        .where(eq(reservation_and_other_details.CandidateID, candidateId))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(reservation_and_other_details)
          .set({
            DomicileStateID: input.domicileStateId,
            DomicileType: input.domicileType as any,
            CategoryID: input.categoryId as any,
            FinalCategoryID: input.finalCategoryId as any,
            ReligionID: input.religionId as any,
            Caste: input.caste,
            HasCasteCertificate: input.hasCasteCertificate,
            HasNCLCertificate: input.HasNCLCertificate,
            HasEWSCertificate: input.HasEWSCertificate,
            HasCasteValidity: input.hasCasteValidity,
            HasCasteValidityReceipt: input.hasCasteValidityReceipt,
            IsOrphan: input.isOrphan,
            isPH: input.isPH,
            PHDetails: input.PHDetails,
            IsExServiceman: input.IsExServiceman,
            IsFreedomFighter: input.isFreedomFighter,
            IsProjectAffected: input.IsProjectAffected,
            IsTransgender: input.isTransgender,
            SportDetails: input.sportDetails,
            IsNCC: input.isNCC,
            IsNSS: input.isNSS,
            IsAgriculture: input.isAgriculture,
            IsMinority: input.isMinority,
            ReligiousMinorityID: input.religiousMinorityId as any,
            LinguisticMinorityID: input.linguisticMinorityId as any,
            ModifiedByID: email,
            ModifiedOnDate: new Date(),
            ModifiedIPAddress: ipAddress,
          })
          .where(eq(reservation_and_other_details.CandidateID, candidateId));
      } else {
        await db.insert(reservation_and_other_details).values({
          CandidateID: candidateId,
          DomicileStateID: input.domicileStateId,
          DomicileType: input.domicileType as any,
          CategoryID: input.categoryId as any,
          FinalCategoryID: input.finalCategoryId as any,
          ReligionID: input.religionId as any,
          Caste: input.caste,
          HasCasteCertificate: input.hasCasteCertificate,
          HasNCLCertificate: input.HasNCLCertificate,
          HasEWSCertificate: input.HasEWSCertificate,
          HasCasteValidity: input.hasCasteValidity,
          HasCasteValidityReceipt: input.hasCasteValidityReceipt,
          IsOrphan: input.isOrphan,
          isPH: input.isPH,
          PHDetails: input.PHDetails,
          IsExServiceman: input.IsExServiceman,
          IsFreedomFighter: input.isFreedomFighter,
          IsProjectAffected: input.IsProjectAffected,
          IsTransgender: input.isTransgender,
          SportDetails: input.sportDetails,
          IsNCC: input.isNCC,
          IsNSS: input.isNSS,
          IsAgriculture: input.isAgriculture,
          IsMinority: input.isMinority,
          ReligiousMinorityID: input.religiousMinorityId as any,
          LinguisticMinorityID: input.linguisticMinorityId as any,
          OwnedByID: email,
          CreatedOnDate: new Date(),
          CreatedIPAddress: ipAddress,
        });
      }

      return { success: true, message: 'Reservation details saved successfully' };
    }),

  // Get Reservation Details
  getReservationDetails: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;
    if (!email) throw new Error('Email not found in session');

    const candidateId = await getCandidateId(email);
    if (!candidateId) return null;

    const details = await db
      .select({
        ...getTableColumns(reservation_and_other_details),
        DomicileStateName: master_state.StateName,
        CategoryName: master_category.CategoryName,
        ReligionName: master_religion.ReligionName,
        ReligiousMinorityName: master_minority.Minority,
      })
      .from(reservation_and_other_details)
      .leftJoin(master_state, eq(reservation_and_other_details.DomicileStateID, master_state.StateID))
      .leftJoin(master_category, eq(reservation_and_other_details.CategoryID, master_category.CategoryID))
      .leftJoin(master_religion, eq(reservation_and_other_details.ReligionID, master_religion.ReligionID))
      .leftJoin(master_minority, eq(reservation_and_other_details.ReligiousMinorityID, master_minority.MinorityID))
      .where(eq(reservation_and_other_details.CandidateID, candidateId))
      .limit(1);

    return details.length > 0 ? details[0] : null;
  }),

  // Get Qualification Details
  getQualificationDetails: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;
    if (!email) throw new Error('Email not found in session');

    const candidateId = await getCandidateId(email);
    if (!candidateId) return [];

    const details = await db
      .select({
        qualificationType: qualification_details.QualificationID,
        qualificationTypeLabel: master_qualification.Qualification,
        qualificationName: qualification_details.ProgramID,
        qualificationNameLabel: master_program.ProgramName,
        boardUniversity: qualification_details.UniversityBoardID,
        boardLabel: master_board.Board,
        universityLabel: master_university.UniversityName,
        resultType: qualification_details.ResultStatus,
        percentage: qualification_details.MarkPercentage,
        grade: qualification_details.Grade,
        passingMonth: qualification_details.PassingMonth,
        passingYear: qualification_details.PassingYear,
        marksObtained: qualification_details.MarksObtained,
        marksOutOf: qualification_details.MarksOutOf,
        cgpa: qualification_details.CGPA,
        cgpaOutOf: qualification_details.CGPAOutOf,
        seatNo: qualification_details.SeatNo,
        prnNo: qualification_details.PRNNo,
      })
      .from(qualification_details)
      .leftJoin(master_qualification, eq(qualification_details.QualificationID, master_qualification.QualificationID))
      .leftJoin(master_program, eq(qualification_details.ProgramID, master_program.ProgramID))
      .leftJoin(master_board, eq(qualification_details.UniversityBoardID, master_board.BoardID))
      .leftJoin(master_university, eq(qualification_details.UniversityBoardID, master_university.UniversityID))
      .where(eq(qualification_details.CandidateID, candidateId))
      .orderBy(qualification_details.PassingYear);

    return details.map(d => ({
      ...d,
      // Combine Board/University label logic
      boardUniversityLabel: d.boardLabel || d.universityLabel || "",
    }));
  }),

  // Save Qualification Details (Bulk)
  saveQualificationDetails: protectedProcedure
    .input(z.array(z.object({
      qualificationType: z.string(), // ID as string from form
      qualificationName: z.string().optional(), // ProgramID
      boardUniversity: z.string().optional(), // UniversityBoardID
      resultType: z.string().optional(),
      percentage: z.string().optional(), // "90.5"
      grade: z.string().optional(),
      passingMonth: z.string().optional(), // "05"
      passingYear: z.string().optional(), // "2020"
      marksObtained: z.string().optional(),
      marksOutOf: z.string().optional(),
      cgpa: z.string().optional(),
      cgpaOutOf: z.string().optional(),
      seatNo: z.string().optional(), // Roll Number/SeatNo?
      prnNo: z.string().optional(),
    })))
    .mutation(async ({ ctx, input }) => {
      const email = ctx.session.user.email;
      if (!email) throw new Error('Email not found in session');

      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'Unknown';
      const candidateId = await getCandidateId(email);
      if (!candidateId) throw new Error('Registration not found. Please complete personal details first.');

      // 1. Delete existing qualifications for this user (Full Sync Approach)
      await db.delete(qualification_details).where(eq(qualification_details.CandidateID, candidateId));

      // 2. Insert new qualifications
      if (input.length > 0) {
        const valuesToInsert = input.map(qual => ({
          CandidateID: candidateId,
          QualificationID: parseInt(qual.qualificationType),
          ProgramID: qual.qualificationName ? parseInt(qual.qualificationName) : null,
          UniversityBoardID: qual.boardUniversity ? parseInt(qual.boardUniversity) : null,
          ResultStatus: qual.resultType,
          MarkPercentage: qual.percentage ? qual.percentage : null, // Drizzle handles numeric/decimal string? It's defined as numeric.
          Grade: qual.grade,
          PassingMonth: qual.passingMonth ? parseInt(qual.passingMonth) : null,
          PassingYear: qual.passingYear ? parseInt(qual.passingYear) : null,
          MarksObtained: qual.marksObtained ? parseInt(qual.marksObtained) : null,
          MarksOutOf: qual.marksOutOf ? parseInt(qual.marksOutOf) : null,
          CGPA: qual.cgpa ? qual.cgpa : null,
          CGPAOutOf: qual.cgpaOutOf ? qual.cgpaOutOf : null,
          SeatNo: qual.seatNo, // Assuming 'passedAppeared' roll number maps here if applicable or just ignored? 
          // Wait, 'passedAppeared' is status ("passed", "appeared"). 
          // Form config has `passedAppeared` radio.
          // Form also has `PRNNumber` -> `prnNo`.
          PRNNo: qual.prnNo,

          CreatedByID: email,
          CreatedOnDate: new Date(),
          CreatedIPAddress: ipAddress,
          ModifiedByID: email,
          ModifiedOnDate: new Date(),
          ModifiedIPAddress: ipAddress
        }));

        await db.insert(qualification_details).values(valuesToInsert as any);
      }

      return { success: true, message: 'Qualification details saved successfully' };
    }),

  // Get Required Documents
  getRequiredDocuments: protectedProcedure.query(async ({ ctx }) => {
    const candidateId = await getCandidateId(ctx.session.user.email!);
    if (!candidateId) return [];

    const docs = await db
      .select()
      .from(required_document)
      .where(eq(required_document.CandidateID, candidateId));

    return docs.map((d) => ({
      documentId: d.DocumentID,
      isUploaded: d.IsDocumentUpload,
      docUrl: d.DocumentUploadURL,
      uploadedOn: d.UploadedOnDate,
      // FileName is not in schema, so we can't return it. 
      // Frontend might need to derive it from URL or just show "Uploaded"
    }));
  }),

  // Upload Document
  uploadDocument: protectedProcedure
    .input(
      z.object({
        documentId: z.number(),
        fileBase64: z.string(),
        fileName: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const email = ctx.session.user.email;
      if (!email) throw new Error('Email not found in session');

      const candidateId = await getCandidateId(email);
      if (!candidateId) throw new Error('Registration not found');

      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] || 'Unknown';

      // Upload to Azure
      const buffer = Buffer.from(input.fileBase64, 'base64');
      const docUrl = await uploadFileToAzure(buffer, input.fileName, 'documents');

      // Check if document record exists
      const existing = await db
        .select()
        .from(required_document)
        .where(
          and(
            eq(required_document.CandidateID, candidateId),
            eq(required_document.DocumentID, input.documentId)
          )
        )
        .limit(1);

      if (existing.length > 0) {
        // Update
        // Data cleaning: delete old file if url changed? (Optional optimization)

        await db
          .update(required_document)
          .set({
            IsDocumentUpload: true,
            DocumentUploadURL: docUrl,
            UploadedByID: email,
            UploadedOnDate: new Date(),
            UploadedIPAddress: ipAddress,
            // Reset verification status on new upload?
            IsVerified: false,
            EVerificationStatus: 'P', // Pending? Or null. Leaving as is if not needed.
          })
          .where(
            and(
              eq(required_document.CandidateID, candidateId),
              eq(required_document.DocumentID, input.documentId)
            )
          );
      } else {
        // Insert
        await db.insert(required_document).values({
          CandidateID: candidateId,
          DocumentID: input.documentId,
          IsDocumentUpload: true,
          DocumentUploadURL: docUrl,
          UploadedByID: email,
          UploadedOnDate: new Date(),
          UploadedIPAddress: ipAddress,
          IsVerified: false,
          EVerificationStatus: 'P',
        });
      }

      return { success: true, docUrl };
    }),
});
