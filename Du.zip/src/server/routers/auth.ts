import { z } from 'zod';
import { TRPCError } from '@trpc/server';
import bcrypt from 'bcryptjs';
import { createTRPCRouter, publicProcedure } from '../trpc';
import { db } from '@/lib/drizzle';
import { user_master, verification_tokens } from '@/db/schema';
import { eq, and } from 'drizzle-orm';
import nodemailer from 'nodemailer';

// Email transporter setup
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

export const authRouter = createTRPCRouter({
  // Sign up
  signup: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        password: z.string().min(6),
        name: z.string().min(1),
        mobile: z.string().optional(),
        securityQuestionId: z.number(),
        securityAnswer: z.string().min(1),
      })
    )
    .mutation(async ({ input, ctx }) => {
      const { email, password, name, mobile, securityQuestionId, securityAnswer } = input;

      // Get IP address from headers
      const ipAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] ||
        ctx.headers.get('x-real-ip') ||
        'unknown';

      // Check if user exists
      const [existingUser] = await db
        .select()
        .from(user_master)
        .where(eq(user_master.UserEmailID, email))
        .limit(1);

      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      if (existingUser) {
        // If user exists and is already active, throw error
        if (existingUser.IsActive) {
          throw new TRPCError({
            code: 'CONFLICT',
            message: 'Email already registered and verified. Please login.',
          });
        }

        // If user exists but not active (unverified), update their info and resend OTP
        const hashedPassword = await bcrypt.hash(password, 10);

        await db
          .update(user_master)
          .set({
            UserLoginID: email,
            UserName: name,
            UserPassword: hashedPassword,
            UserMobileNo: mobile || null,
            SecurityQuestionID: securityQuestionId,
            SecurityQuestionAnswer: securityAnswer.toLowerCase(),
            CreatedOnDate: new Date(),
            CreatedIPAddress: ipAddress,
          })
          .where(eq(user_master.UserEmailID, email));

        // Store new OTP
        await db.insert(verification_tokens).values({
          Email: email,
          TokenType: 'EMAIL_VERIFICATION',
          Token: otp,
          ExpiresAt: expiresAt,
          IsUsed: false,
          CreatedAt: new Date(),
        });
      } else {
        // New user - create account
        const hashedPassword = await bcrypt.hash(password, 10);

        const [newUser] = await db
          .insert(user_master)
          .values({
            UserTypeID: 91, // Default to student/candidate type
            UserLoginID: email,
            UserName: name,
            UserEmailID: email,
            UserPassword: hashedPassword,
            UserMobileNo: mobile || null,
            SecurityQuestionID: securityQuestionId,
            SecurityQuestionAnswer: securityAnswer.toLowerCase(),
            IsActive: false,
            CreatedByID: 'SELF_REGISTRATION',
            CreatedOnDate: new Date(),
            CreatedIPAddress: ipAddress,
          })
          .returning();

        // Store OTP
        await db.insert(verification_tokens).values({
          Email: email,
          TokenType: 'EMAIL_VERIFICATION',
          Token: otp,
          ExpiresAt: expiresAt,
          IsUsed: false,
          CreatedAt: new Date(),
        });
      }

      // Send verification email
      console.log('='.repeat(80));
      console.log('📧 EMAIL VERIFICATION OTP');
      console.log('Email:', email);
      console.log('OTP:', otp);
      console.log('Expires:', expiresAt.toISOString());
      console.log('='.repeat(80));

      try {
        await transporter.sendMail({
          from: process.env.SMTP_FROM,
          to: email,
          subject: 'Verify Your Email - VNMKV Portal',
          html: `
            <h2>Email Verification</h2>
            <p>Your verification code is: <strong>${otp}</strong></p>
            <p>This code will expire in 10 minutes.</p>
          `,
        });
        console.log('✅ Verification email sent successfully to:', email);
      } catch (error) {
        console.error('❌ Failed to send verification email:', error);
        console.log('⚠️  IMPORTANT: Use the OTP logged above for verification');
      }

      return {
        success: true,
        message: existingUser
          ? 'A new verification code has been sent to your email.'
          : 'Registration successful. Please verify your email.',
        userId: existingUser?.UserID?.toString() || undefined,
        email: email,
      };
    }),

  // Verify email
  verifyEmail: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        otp: z.string().length(6),
      })
    )
    .mutation(async ({ input }) => {
      const { email, otp } = input;

      // Find valid OTP
      const [token] = await db
        .select()
        .from(verification_tokens)
        .where(
          and(
            eq(verification_tokens.Email, email),
            eq(verification_tokens.TokenType, 'EMAIL_VERIFICATION'),
            eq(verification_tokens.Token, otp),
            eq(verification_tokens.IsUsed, false)
          )
        )
        .limit(1);

      if (!token) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Invalid OTP',
        });
      }

      if (new Date() > token.ExpiresAt) {
        console.log('='.repeat(80));
        console.log('⚠️  OTP EXPIRED - Email Verification');
        console.log('Email:', email);
        console.log('Expired OTP:', otp);
        console.log('Expired at:', token.ExpiresAt.toISOString());
        console.log('Current time:', new Date().toISOString());
        console.log('💡 User needs to sign up again to get a new OTP');
        console.log('='.repeat(80));

        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'OTP has expired. Please sign up again to get a new verification code.',
        });
      }

      // Mark OTP as used
      await db
        .update(verification_tokens)
        .set({ IsUsed: true })
        .where(eq(verification_tokens.TokenID, token.TokenID));

      // Activate user
      await db
        .update(user_master)
        .set({ IsActive: true })
        .where(eq(user_master.UserEmailID, email));

      return {
        success: true,
        message: 'Email verified successfully',
      };
    }),

  // Send OTP for password reset
  sendResetOTP: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
      })
    )
    .mutation(async ({ input }) => {
      const { email } = input;

      // Check if user exists
      const [user] = await db
        .select()
        .from(user_master)
        .where(eq(user_master.UserEmailID, email))
        .limit(1);

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found',
        });
      }

      // Generate 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

      // Store OTP
      await db.insert(verification_tokens).values({
        Email: email,
        TokenType: 'PASSWORD_RESET',
        Token: otp,
        ExpiresAt: expiresAt,
        IsUsed: false,
        CreatedAt: new Date(),
      });

      // Send email
      console.log('='.repeat(80));
      console.log('🔐 PASSWORD RESET OTP');
      console.log('Email:', email);
      console.log('OTP:', otp);
      console.log('Expires:', expiresAt.toISOString());
      console.log('='.repeat(80));

      try {
        await transporter.sendMail({
          from: process.env.SMTP_FROM,
          to: email,
          subject: 'Password Reset OTP - VNMKV Portal',
          html: `
            <h2>Password Reset</h2>
            <p>Your OTP is: <strong>${otp}</strong></p>
            <p>This code will expire in 10 minutes.</p>
          `,
        });
        console.log('✅ Password reset email sent successfully to:', email);
      } catch (error) {
        console.error('❌ Failed to send password reset email:', error);
        console.log('⚠️  IMPORTANT: Use the OTP logged above for password reset');
        // Don't throw error - allow OTP to work even if email fails
      }

      return {
        success: true,
        message: 'OTP sent to your email',
      };
    }),

  // Verify OTP for password reset
  verifyResetOTP: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        otp: z.string().length(6),
      })
    )
    .mutation(async ({ input }) => {
      const { email, otp } = input;

      const [token] = await db
        .select()
        .from(verification_tokens)
        .where(
          and(
            eq(verification_tokens.Email, email),
            eq(verification_tokens.TokenType, 'PASSWORD_RESET'),
            eq(verification_tokens.Token, otp),
            eq(verification_tokens.IsUsed, false)
          )
        )
        .limit(1);

      if (!token) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Invalid OTP',
        });
      }

      if (new Date() > token.ExpiresAt) {
        console.log('='.repeat(80));
        console.log('⚠️  OTP EXPIRED - Password Reset');
        console.log('Email:', email);
        console.log('Expired OTP:', otp);
        console.log('Expired at:', token.ExpiresAt.toISOString());
        console.log('Current time:', new Date().toISOString());
        console.log('💡 User needs to request a new OTP');
        console.log('='.repeat(80));

        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'OTP has expired. Please request a new one.',
        });
      }

      // Mark as used
      await db
        .update(verification_tokens)
        .set({ IsUsed: true })
        .where(eq(verification_tokens.TokenID, token.TokenID));

      // Generate reset token
      const resetToken = Math.random().toString(36).substring(2, 15);
      const resetExpiresAt = new Date(Date.now() + 15 * 60 * 1000);

      await db.insert(verification_tokens).values({
        Email: email,
        TokenType: 'PASSWORD_RESET_TOKEN',
        Token: resetToken,
        ExpiresAt: resetExpiresAt,
        IsUsed: false,
        CreatedAt: new Date(),
      });

      return {
        success: true,
        resetToken,
        email,
      };
    }),

  // Verify security question
  verifySecurityQuestion: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        questionId: z.number(),
        answer: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const { email, questionId, answer } = input;

      // First check if user exists
      const [user] = await db
        .select()
        .from(user_master)
        .where(eq(user_master.UserEmailID, email))
        .limit(1);

      if (!user) {
        throw new TRPCError({
          code: 'NOT_FOUND',
          message: 'User not found with this email address',
        });
      }

      // Check if the security question matches
      if (user.SecurityQuestionID !== questionId) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'The selected security question does not match your registered question',
        });
      }

      // Verify the answer
      const isAnswerCorrect =
        user.SecurityQuestionAnswer?.toLowerCase() === answer.toLowerCase();

      if (!isAnswerCorrect) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Incorrect answer to security question',
        });
      }

      // Generate reset token
      const resetToken = Math.random().toString(36).substring(2, 15);
      const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

      await db.insert(verification_tokens).values({
        Email: email,
        TokenType: 'PASSWORD_RESET_TOKEN',
        Token: resetToken,
        ExpiresAt: expiresAt,
        IsUsed: false,
        CreatedAt: new Date(),
      });

      return {
        success: true,
        resetToken,
        email,
      };
    }),

  // Reset password
  resetPassword: publicProcedure
    .input(
      z.object({
        resetToken: z.string(),
        email: z.string().email().optional(),
        newPassword: z.string().min(6),
      })
    )
    .mutation(async ({ input }) => {
      const { resetToken, newPassword } = input;

      // Validate reset token and get email from token
      const [token] = await db
        .select()
        .from(verification_tokens)
        .where(
          and(
            eq(verification_tokens.TokenType, 'PASSWORD_RESET_TOKEN'),
            eq(verification_tokens.Token, resetToken),
            eq(verification_tokens.IsUsed, false)
          )
        )
        .limit(1);

      if (!token) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Invalid or expired reset token',
        });
      }

      if (new Date() > token.ExpiresAt) {
        throw new TRPCError({
          code: 'BAD_REQUEST',
          message: 'Reset token has expired',
        });
      }

      const email = token.Email;

      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);

      // Update password
      await db
        .update(user_master)
        .set({ UserPassword: hashedPassword })
        .where(eq(user_master.UserEmailID, email));

      // Mark token as used
      await db
        .update(verification_tokens)
        .set({ IsUsed: true })
        .where(eq(verification_tokens.TokenID, token.TokenID));

      return {
        success: true,
        message: 'Password reset successfully',
      };
    }),
});
