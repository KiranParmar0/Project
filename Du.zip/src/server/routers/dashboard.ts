import { z } from 'zod';
import { createTRPCRouter, protectedProcedure } from '../trpc';
import { TRPCError } from '@trpc/server';
import { db } from '@/lib/drizzle';
import { registration_details, user_master } from '@/db/schema';
import { eq } from 'drizzle-orm';

export const dashboardRouter = createTRPCRouter({
  // Get user profile
  getProfile: protectedProcedure.query(async ({ ctx }) => {
    const email = ctx.session.user.email;

    if (!email) {
      throw new Error('Email not found in session');
    }

    // Get current IP address from headers
    const currentIpAddress = ctx.headers.get('x-forwarded-for')?.split(',')[0] ||
      ctx.headers.get('x-real-ip') ||
      'Unknown';

    // Get user from user_master
    const users = await db
      .select()
      .from(user_master)
      .where(eq(user_master.UserEmailID, email))
      .limit(1);

    if (!users || users.length === 0) {
      throw new Error('User not found');
    }

    const user = users[0];

    // Get registration details
    const registrations = await db
      .select()
      .from(registration_details)
      .where(eq(registration_details.CandidateEmailID, email))
      .limit(1);

    const registration = registrations && registrations.length > 0 ? registrations[0] : null;

    // Calculate profile completion percentage
    let completionPercentage = 0;
    if (registration) {
      completionPercentage = 30;
    }

    return {
      name: user.UserName || registration?.CandidateName || '--',
      email: user.UserEmailID || '--',
      mobileNumber: user.UserMobileNo || registration?.CandidateMobileNo || '--',
      ipAddress: currentIpAddress,
      courseName: '--',
      schoolName: '--',
      courseYear: '--',
      applicationStatus: 'Incomplete', // Fix as per actual status
      profileCompletion: completionPercentage,
      candidateId: registration?.CandidateID?.toString() || null,
    };
  }),
  // College: Get college overview (only for college role)
  getCollegeOverview: protectedProcedure.query(async ({ ctx }) => {
    const role = (ctx.session.user as any)?.role;
    if (!role || !role.toString().toLowerCase().includes('college')) {
      throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not a college user' });
    }

    // TODO: Replace with real DB queries for college data
    return {
      name: 'Test College (VNMKV affiliated)',
      collegeCode: (ctx.session.user as any)?.email || null,
      totalStudents: 123,
      pendingApplications: 5,
    };
  }),

  // College: list students (placeholder)
  getCollegeStudents: protectedProcedure.query(async ({ ctx }) => {
    const role = (ctx.session.user as any)?.role;
    if (!role || !role.toString().toLowerCase().includes('college')) {
      throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not a college user' });
    }

    // TODO: Query students for the college from DB
    return [
      { id: 's1', name: 'Student One', email: 's1@example.com', status: 'Enrolled' },
      { id: 's2', name: 'Student Two', email: 's2@example.com', status: 'Applied' },
    ];
  }),

  // College: list applications (placeholder)
  getCollegeApplications: protectedProcedure.query(async ({ ctx }) => {
    const role = (ctx.session.user as any)?.role;
    if (!role || !role.toString().toLowerCase().includes('college')) {
      throw new TRPCError({ code: 'UNAUTHORIZED', message: 'Not a college user' });
    }

    // TODO: Query applications for the college from DB
    return [
      { id: 'a1', applicant: 'Student One', programme: 'MSc Agriculture', status: 'Pending' },
      { id: 'a2', applicant: 'Student Two', programme: 'BSc Horticulture', status: 'Approved' },
    ];
  }),
});
