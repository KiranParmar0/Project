import { initTRPC, TRPCError } from '@trpc/server';
import { getServerSession } from 'next-auth';
import { createAuthOptions } from '@/lib/auth';
import { db } from '@/lib/drizzle';
import superjson from 'superjson';

/**
 * Creates context for tRPC
 */
export const createTRPCContext = async (opts: { headers: Headers }) => {
  const session = await getServerSession(createAuthOptions());

  return {
    session,
    headers: opts.headers,
    db,
  };
};

/**
 * Initialization of tRPC backend
 */
const t = initTRPC.context<typeof createTRPCContext>().create({
  transformer: superjson,
  errorFormatter({ shape }) {
    return shape;
  },
});

/**
 * Export reusable router and procedure helpers
 */
export const createTRPCRouter = t.router;
export const publicProcedure = t.procedure;

/**
 * Protected procedure - requires authentication
 */
export const protectedProcedure = t.procedure.use(async ({ ctx, next }) => {
  if (!ctx.session || !ctx.session.user) {
    throw new TRPCError({ code: 'UNAUTHORIZED' });
  }
  return next({
    ctx: {
      // infers the `session` as non-nullable
      session: { ...ctx.session, user: ctx.session.user },
    },
  });
});
