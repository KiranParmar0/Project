import { createTRPCRouter } from './trpc';
import { authRouter } from './routers/auth';
import { dashboardRouter } from './routers/dashboard';
import { masterRouter } from './routers/master';
import { studentRouter } from './routers/student';
import { collegeRouter } from './routers/college';

/**
 * This is the primary router for your server.
 *
 * All routers added in /server/routers should be manually added here.
 */
export const appRouter = createTRPCRouter({
  auth: authRouter,
  dashboard: dashboardRouter,
  master: masterRouter,
  student: studentRouter,
  college: collegeRouter,
});

// export type definition of API
export type AppRouter = typeof appRouter;
