"use client";
import React, { createContext, useContext, useState, ReactNode } from "react";

interface PopupState {
  isOpen: boolean;
  type: "success" | "error";
  title: string;
  message: string;
  showCancel: boolean;
  onConfirm: () => void;
  onCancel?: () => void;
  componentName?: string;
}

interface PopupContextType {
  showPopup: (config: Omit<PopupState, "isOpen">) => void;
  hidePopup: () => void;
  popupState: PopupState;
}

const defaultPopupState: PopupState = {
  isOpen: false,
  type: "success",
  title: "",
  message: "",
  showCancel: false,
  onConfirm: () => {},
  onCancel: undefined,
  componentName: undefined,
};

const PopupContext = createContext<PopupContextType | undefined>(undefined);

export function PopupProvider({ children }: { children: ReactNode }) {
  const [popupState, setPopupState] = useState<PopupState>(defaultPopupState);

  const showPopup = (config: Omit<PopupState, "isOpen">) => {
    setPopupState({
      ...config,
      isOpen: true,
    });
  };

  const hidePopup = () => {
    setPopupState(defaultPopupState);
  };

  return (
    <PopupContext.Provider value={{ showPopup, hidePopup, popupState }}>
      {children}
    </PopupContext.Provider>
  );
}

export function usePopup() {
  const context = useContext(PopupContext);
  if (!context) {
    throw new Error("usePopup must be used within a PopupProvider");
  }
  return context;
}
