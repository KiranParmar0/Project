import React from 'react'
import './App.css';
import DoughnutChart from './DoughnutChart/Doughnut';
import PieChartGraph from './DoughnutChart/PieChart';
import { Chart, ArcElement } from 'chart.js'
import DoughnutChartLabal from "./DoughnutChart/labaloutside"
Chart.register(ArcElement)
function App() {
  return (
    <div className="App">
      <div className="container">
        <DoughnutChart />
        {/* {<PieChartGraph /> } */}
        {/* <DoughnutChartLabal /> */}
      </div>

    </div>
  );
}

export default App;