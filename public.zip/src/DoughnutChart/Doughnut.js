import React from 'react';
import { Doughnut } from 'react-chartjs-2';
import 'chartjs-plugin-datalabels';
import { Chart as ChartJs, ArcElement, Tooltip, Legend } from 'chart.js'
ChartJs.register(
    ArcElement, Tooltip, Legend
);
function DoughnutChart() {
    const data = {
        labels: ['Critical', 'High', 'Medium', 'Low', 'Inforamtion'],
        datasets: [
            {
                label: 'Attendance for Week 1',
                data: [20, 93, 229, 73, 6],
                borderColor: ['rgba(255,206,86,0.2)'],
                backgroundColor: [
                    'rgba(31, 154, 0, 1)',
                    'rgba(255, 92, 0, 1)',
                    'rgba(56, 96, 198, 1)',
                    'rgba(255, 184, 0, 1)',
                    'rgba(153,102,255,1)'
                ],
                pointBackgroundColor: 'rgba(255,206,86,0.2)',
                backgroundImage: 'lightblue url("https://www.chartjs.org/img/chartjs-logo.svgf") no-repeat fixed center',
                cutout: '75%',
                // borderRadius: 30,
                // offSet: 20,

            }

        ]

    };
    const dataArray = data.datasets[0].data;
    const ArraySum = dataArray.reduce((acc, currentValue) => acc + currentValue, 0);

    const urls = [
        'https://www.google.com',
        'https://www.microsoft.com',
        'https://www.apple.com',
        'https://www.amazon.com',
        'https://www.facebook.com'
    ];


    const options = {
        layout: {
            pading: 30,
        },
        plugins: {
            title: {
                display: true,
                text: 'Doughnut Chart',
                color: 'blue',
                font: {
                    size: 34
                },
                padding: {
                    top: 30,
                    bottom: 30
                }
            },
            datalabels: {
                color: 'red', // Color of the labels
                display: true,
                formatter: (value, context) => { // Custom formatter function
                    return value + '%'; // You can customize the formatting as needed
                }
            }
        },


        onClick: (event, elements) => {
            if (elements.length > 0) {
                const index = elements[0].index;
                if (index >= 0 && index < urls.length) {
                    // Open the corresponding URL in a new tab
                    window.open(urls[index], '_blank');
                }
            }
        }
    }
    const doughnutLabal = {
        id: "doughnutLabal",
        afterDatasetsDraw(chart, args, plugins) {
            const { ctx, data } = chart;
            const centerX = chart.getDatasetMeta(0).data[0].x;
            const centerY = chart.getDatasetMeta(0).data[0].y;
            //text
            ctx.save();
            ctx.font = 'bold 40px sans-serif';
            ctx.fillStyle = 'black';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle'
            ctx.fillText(ArraySum, centerX, centerY);
        }
    }
    //doughnutLabalLine plugin   
    const doughnutLabalLine = {
        id: 'doughnutLabalLine',
        afterDraw(chart, args, options) {
            const { ctx, chartArea: { top, bottom, left, right, width, height } } = chart;

            chart.data.datasets.forEach((dataset, i) => {
                const meta = chart.getDatasetMeta(i);
                if (meta) {
                    meta.data.forEach((datapoint, index) => {
                        const { x, y } = datapoint.tooltipPosition();
                        ctx.fillStyle = "black"; // Corrected spelling
                        // ctx.fill(); // No need to fill any shape here

                        // draw line
                        const halfwidth = width / 2;
                        const halfheight = height / 2;

                        const xLine = x >= halfwidth ? x + 35 : x - 35;
                        const yLine = y >= halfheight ? y + 65 : y - 65;
                        const extraLineX = x >= halfwidth ? 15 : -15;

                        //line 
                        ctx.beginPath();
                        ctx.moveTo(x, y);
                        ctx.lineTo(xLine, yLine);
                        ctx.lineTo(xLine + extraLineX, yLine);
                        ctx.strokeStyle = 'black'//dataset.borderColor[index];
                        ctx.stroke();

                        //text in the line 

                        // console.log (chart.data.labels[index]);
                        const testWidth = ctx.measureText(chart.data.datasets[i].data).width;
                        ctx.font = '12px Arial'
                        //console.log(testWidth)


                        //control the position 
                        const textPosition = x >= halfwidth ? 'left' : 'right';
                        const plusFivePx = x >= halfwidth ? 5 : -5;

                        ctx.textBaseline = 'middle';
                        //   ctx.fillStyle= dataset.borderColor[index];
                        ctx.textAlign = textPosition;
                        ctx.fillText(" " + chart.data.labels[index] + " ", xLine + extraLineX + plusFivePx, yLine);




                    });
                }
            });
        }
    };


    return (
        <div style={{ position: 'relative' }}>
            <Doughnut data={data} options={options}
                plugins={[doughnutLabal, doughnutLabalLine]} />

        </div>
    )
}

export default DoughnutChart;
