import React, { useEffect } from 'react';
import { Doughnut } from 'react-chartjs-2';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import Chart from 'chart.js/auto'; // Import Chart.js (auto) to access the Chart.pluginService

function DoughnutChart() {
    const data = {
        labels: ['Mon', 'Tue', 'Wed', 'Thurs', 'Fri'],
        datasets: [
            {
                label: 'Attendance for Week 1',
                data: [25, 24, 25, 25, 23],
                borderColor: ['rgba(255,206,86,0.2)'],
                backgroundColor: [
                    'rgba(232,99,132,1)',
                    'rgba(232,211,6,1)',
                    'rgba(54,162,235,1)',
                    'rgba(255,159,64,1)',
                    'rgba(153,102,255,1)'
                ]
            }
        ]
    };

    const options = {
        plugins: {
            title: {
                display: true,
                text: 'Doughnut Chart',
                color: 'blue',
                font: {
                    size: 34
                },
                padding: {
                    top: 30,
                    bottom: 30
                }
            },
            datalabels: {
                color: 'red',
                display: true,
                formatter: (value, context) => {
                    return value + '%';
                }
            }
        },
        onClick: (event, elements) => {
            // Your onClick logic here
        }
    };

    useEffect(() => {
        // Define a Chart.js plugin to display text in the middle of the pie chart
        const centerTextPlugin = {
            afterDraw: chart => {
                const ctx = chart.ctx;
                const width = chart.width,
                    height = chart.height;

                // Calculate the total count
                const total = data.datasets[0].data.reduce((acc, value) => acc + value, 0);

                // Display total count in the middle
                ctx.save();
                ctx.fillStyle = '#333';
                ctx.font = '20px Arial';
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.fillText(total, width / 2, height / 2);
                ctx.restore();
            }
        };

        // eslint-disable-next-line no-undef
        Chart.pluginService.register(centerTextPlugin);

        return () => {
            // Unregister the plugin when the component unmounts
            Chart.pluginService.unregister(centerTextPlugin);
        };
    }, []); // Only run once on component mount

    return (
        <div>
            <Doughnut data={data} options={options} />
        </div>
    );
}

export default DoughnutChart;
