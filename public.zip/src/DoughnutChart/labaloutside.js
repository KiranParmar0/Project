import React, { useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const DoughnutChartLabal = () => {
  const chartRef = useRef(null);

  useEffect(() => {
    const ctx = chartRef.current.getContext('2d');

    const chartData = {
      labels: ['Label 1', 'Label 2', 'Label 3'],
      datasets: [{
        label: 'Dataset',
        data: [300, 200, 100],
        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56']
      }]
    };

    const doughnutChart = new Chart(ctx, {
      type: 'doughnut',
      data: chartData,
      options: {
        plugins: {
          legend: {
            display: false
          },
          tooltip: {
            callbacks: {
              label: function(context) {
                let label = context.label || '';
                if (context.parsed) {
                  label += ': ' + context.parsed.toLocaleString();
                }
                return label;
              }
            }
          }
        }
      }
    });

    return () => {
      doughnutChart.destroy();
    };
  }, []);

  return (
    <div style={{ position: 'relative' }}>
      <canvas ref={chartRef}></canvas>
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', textAlign: 'center' }}>
        <span>Total Count</span>
      </div>
    </div>
  );
};

export default DoughnutChartLabal;
